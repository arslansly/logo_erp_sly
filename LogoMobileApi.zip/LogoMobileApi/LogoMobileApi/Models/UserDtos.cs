using System.ComponentModel.DataAnnotations;

namespace LogoMobileApi.Models;

// Kullanıcı listesi/detay — PasswordHash asla dışarı verilmez.
public class UserListItem
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "User";
    public bool IsActive { get; set; }
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; }
}

// Yeni kullanıcı oluşturma isteği (Admin)
public class CreateUserRequest
{
    [Required(ErrorMessage = "Kullanıcı adı zorunlu")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "Şifre zorunlu")]
    [MinLength(4, ErrorMessage = "Şifre en az 4 karakter olmalı")]
    public string Password { get; set; } = "";

    [Required(ErrorMessage = "Ad Soyad zorunlu")]
    public string FullName { get; set; } = "";

    public string Email { get; set; } = "";
    public string Role { get; set; } = "User";
}

// Kullanıcı güncelleme isteği (Admin). Password boşsa değiştirilmez.
public class UpdateUserRequest
{
    [Required(ErrorMessage = "Ad Soyad zorunlu")]
    public string FullName { get; set; } = "";

    public string Email { get; set; } = "";
    public string Role { get; set; } = "User";
    public bool IsActive { get; set; } = true;

    // Boş/null ise şifre değiştirilmez.
    public string? Password { get; set; }
}

// ─── İnce yetki (hibrit: rol varsayılanı + kullanıcı override) DTO'ları ───

// GET /api/users/{id}/permissions yanıt satırı
public class PermissionItem
{
    public string Key { get; set; } = "";
    public bool Default { get; set; }   // rolün varsayılanı
    public bool? Override { get; set; }  // kullanıcı istisnası (null = yok)
    public bool Effective { get; set; }  // sonuç (override ?? default)
}

public class UserPermissionsResponse
{
    public string Role { get; set; } = "";
    public List<PermissionItem> Items { get; set; } = new();
}

// PUT /api/users/{id}/permissions isteği — yalnızca varsayılandan FARKLI kararlar
public class SetUserPermissionsRequest
{
    public List<PermissionOverrideDto> Overrides { get; set; } = new();
}

public class PermissionOverrideDto
{
    public string Key { get; set; } = "";
    public bool Granted { get; set; }
}
