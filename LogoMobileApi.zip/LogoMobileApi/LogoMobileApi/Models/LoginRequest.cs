﻿using System.ComponentModel.DataAnnotations;

namespace LogoMobileApi.Models;

public class LoginRequest
{
    [Required(ErrorMessage = "Kullanıcı adı zorunlu")]
    public string Username { get; set; } = "";

    [Required(ErrorMessage = "Şifre zorunlu")]
    public string Password { get; set; } = "";

    // İstemcinin ayarlardan seçtiği firma/dönem. Boş gelirse backend
    // appsettings'teki varsayılanı kullanır. JWT claim'ine gömülür.
    public string? FirmaNo { get; set; }
    public string? DonemNo { get; set; }
}