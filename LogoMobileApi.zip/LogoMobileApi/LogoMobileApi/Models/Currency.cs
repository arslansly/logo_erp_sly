namespace LogoMobileApi.Models;

// L_CURRENCYLIST projection — döviz tanımları
public class Currency
{
    public int CurType { get; set; }     // 1=USD, 2=DEM, ...
    public string CurCode { get; set; } = ""; // "USD", "EUR" vb.
    public string CurName { get; set; } = ""; // "ABD Doları"
}

// L_DAILYEXCHANGES projection — en son kur
public class ExchangeRate
{
    public int CurType { get; set; }
    public string CurCode { get; set; } = "";
    // RATES1=banknot alış, RATES2=banknot satış, RATES3=döviz alış, RATES4=döviz satış.
    // Form'da varsayılan "banknot satış" (Rates2) — kullanıcı override edebilir.
    public decimal Rates1 { get; set; }
    public decimal Rates2 { get; set; }
    public decimal Rates3 { get; set; }
    public decimal Rates4 { get; set; }
    public bool HasData { get; set; }    // hiç kayıt yoksa false döner, mobil manuel girer
}
