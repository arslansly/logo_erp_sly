namespace LogoMobileApi.Models;

// Liste için yalın DTO — LG_xxx_yy_INVOICE üstünden çekilir.
// Taslaklar için aynı şekil ama IsDraft = true ve DraftId dolu gelir.
public class Fatura
{
    public int Id { get; set; }                        // INVOICE.LOGICALREF veya DraftId (IsDraft=true ise)
    public string FicheNo { get; set; } = "";          // INVOICE.FICHENO
    public string DocCode { get; set; } = "";          // INVOICE.DOCODE
    public DateTime Date { get; set; }                 // INVOICE.DATE_
    public int TrCode { get; set; }                    // INVOICE.TRCODE (31..56)
    public string TrCodeName { get; set; } = "";       // TrCodeMapper.GetName(TrCode)
    public int ClientRef { get; set; }                 // INVOICE.CLIENTREF
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";
    public decimal NetTotal { get; set; }              // INVOICE.NETTOTAL
    public decimal GrossTotal { get; set; }            // INVOICE.GROSSTOTAL
    public decimal TotalVat { get; set; }              // INVOICE.TOTALVAT
    public decimal TotalDiscounts { get; set; }        // INVOICE.TOTALDISCOUNTS
    public int Cancelled { get; set; }                 // INVOICE.CANCELLED (0=aktif)
    public int CurrencyType { get; set; }              // 0=TL, >0 ise L_CURRENCYLIST.CURTYPE
    public decimal ExchangeRate { get; set; } = 1m;

    // Taslak akışı için
    public bool IsDraft { get; set; }                  // dbo.InvoiceDrafts'ten geliyorsa true
    public string DraftStatus { get; set; } = "";      // 'Draft' | 'Transferred' | 'Failed' (taslaksa)
    public string? LastError { get; set; }             // hata mesajı (Failed durumunda)
    public string? ApprovalStatus { get; set; }        // 'Pending' | 'Approved' | 'Rejected' (taslaksa)
}
