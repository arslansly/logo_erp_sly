namespace LogoMobileApi.Models;

public class AmbarStok
{
    public int AmbarNo { get; set; }
    public string AmbarAdi { get; set; } = string.Empty;
    public double FiiliStok { get; set; }
    public double GercekStok { get; set; }
}
