namespace LogoMobileApi.Models;

// Taslak sipariş başlığı — dbo.OrderDrafts tablosu.
// Aktarımda LOGO LG_xxx_yy_ORFICHE'ye INSERT edilir, kayıt 'Transferred' olur.
public class OrderDraft
{
    public int Id { get; set; }
    public int TrCode { get; set; }                     // 1=Satış, 2=Satınalma
    public string? FicheNo { get; set; }
    public string? DocCode { get; set; }
    public DateTime Date { get; set; }

    // Fiş bazlı varsayılan termin tarihi (satırlara default olarak uygulanır)
    public DateTime? DueDate { get; set; }

    // Cari snapshot
    public int ClientRef { get; set; }
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";

    // Toplamlar
    public decimal GrossTotal { get; set; }
    public decimal TotalDiscounts { get; set; }
    public decimal TotalVat { get; set; }
    public decimal NetTotal { get; set; }

    // Döviz — CurrencyType=0 ise TL (ExchangeRate=1). >0 ise L_CURRENCYLIST.CURTYPE.
    public int CurrencyType { get; set; } = 0;
    public decimal ExchangeRate { get; set; } = 1m;

    // Opsiyonel referans alanları (LOGO ORFICHE'ye aktarımda kullanılır)
    public int? SalesmanRef { get; set; }               // LG_SLSMAN.LOGICALREF
    public int? PayDefRef { get; set; }                 // LG_xxx_PAYPLANS.LOGICALREF

    // ORFICHE.STATUS — yeni taslak hep 1 (Öneri)
    public int LogoStatus { get; set; } = 1;

    // Açıklamalar
    public string? GenExp1 { get; set; }
    public string? GenExp2 { get; set; }

    // Durum
    public string Status { get; set; } = "Draft";       // 'Draft' | 'Transferred' | 'Failed'
    public int? TransferredOrderId { get; set; }
    public DateTime? TransferredAt { get; set; }
    public string? LastError { get; set; }

    // Metadata
    public string CreatedBy { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    // Satırlar — DB'den ayrı çekilip set edilir, request'te birlikte gelir
    public List<OrderDraftLine> Lines { get; set; } = new();
}
