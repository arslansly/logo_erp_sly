﻿namespace LogoMobileApi.Models;

public class LoginResponse
{
    public string Token { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public AppUserInfo User { get; set; } = new();
}

public class AppUserInfo
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";

    // Kullanıcının effective yetkileri (rol varsayılanı + override). İstemci UI gizlemesi bunu kullanır.
    public string[] Permissions { get; set; } = Array.Empty<string>();
}