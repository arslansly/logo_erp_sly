namespace LogoMobileApi.Models;

// Ayrıntılı stok raporu satırı — malzeme + ambar bazlı stok dökümü
public class StokAmbarRapor
{
    public int Id { get; set; }
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";
    public string Birim { get; set; } = "";
    public string Tur { get; set; } = "";
    public double ToplamFiili { get; set; }
    public double ToplamGercek { get; set; }
    public List<AmbarStok> Ambarlar { get; set; } = new();
}
