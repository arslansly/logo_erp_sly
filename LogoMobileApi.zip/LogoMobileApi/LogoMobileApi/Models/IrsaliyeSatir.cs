namespace LogoMobileApi.Models;

// İrsaliye satırı — LG_xxx_yy_STLINE projection (STFICHEREF dolu, INVOICEREF NULL veya dolu).
public class IrsaliyeSatir
{
    public int Id { get; set; }
    public int LineNo { get; set; }
    public int LineType { get; set; }
    public string LineTypeName { get; set; } = "";
    public int? StockRef { get; set; }
    public string StockCode { get; set; } = "";
    public string StockName { get; set; } = "";
    public string UomCode { get; set; } = "";
    public decimal Amount { get; set; }
    public decimal Price { get; set; }
    public decimal VatRate { get; set; }
    public decimal Total { get; set; }
    public decimal VatAmount { get; set; }
    public decimal LineNet { get; set; }
    public decimal Discount { get; set; }
    public string LineDescription { get; set; } = "";
}

public class IrsaliyeDetay
{
    public Irsaliye Baslik { get; set; } = new();
    public List<IrsaliyeSatir> Satirlar { get; set; } = new();
    public string GenExp1 { get; set; } = "";
    public string GenExp2 { get; set; } = "";
}
