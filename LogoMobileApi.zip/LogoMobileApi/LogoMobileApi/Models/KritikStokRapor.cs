namespace LogoMobileApi.Models;

// Kritik stok raporu satırı — fiili stoğu asgari (MINLEVEL) seviyesinin altında kalan malzemeler
public class KritikStokRapor
{
    public int Id { get; set; }
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";
    public string Birim { get; set; } = "";
    public double FiiliStok { get; set; }
    public double AsgariStok { get; set; }
    public double Fark { get; set; }   // FiiliStok - AsgariStok (negatif = eksik)
}
