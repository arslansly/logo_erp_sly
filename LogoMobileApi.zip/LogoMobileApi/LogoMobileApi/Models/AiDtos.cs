namespace LogoMobileApi.Models;

// ─── Yapay zeka asistanı (sohbet) DTO'ları ───
// Flutter sadece düz metin mesajları gönderir/alır; tool-use döngüsü tamamen
// backend içinde döner. "Fatura kes / sat / sipariş oluştur" gibi komutlarda
// asistan kayıt OLUŞTURMAZ; sadece formu ön-doldurmak için yapılandırılmış bir
// AiAction döner. Kullanıcı formu görüp onaylar.

/// Sohbetteki tek bir mesaj (kullanıcı veya asistan).
public class AiMessage
{
    /// "user" veya "assistant"
    public string Role { get; set; } = "user";
    public string Text { get; set; } = "";
}

/// Flutter → backend istek gövdesi.
public class AiChatRequest
{
    /// Kullanıcının yeni mesajı.
    public string Message { get; set; } = "";

    /// Önceki sohbet geçmişi (yalnızca düz metin turları).
    public List<AiMessage> History { get; set; } = new();
}

/// Backend → Flutter cevabı.
public class AiChatResponse
{
    /// Asistanın kullanıcıya gösterilecek metin cevabı.
    public string Reply { get; set; } = "";

    /// Doluysa, kullanıcı bir formu ön-dolu açabilir (fatura/sipariş).
    public AiAction? Action { get; set; }
}

/// Asistanın önerdiği aksiyon — Flutter bunu kullanarak ilgili formu ön-dolu açar.
public class AiAction
{
    /// "fatura" | "siparis" | "none"
    public string Type { get; set; } = "none";

    /// Belge alt türü (LOGO TRCODE). Fatura: 38=Toptan Satış, 37=Perakende Satış,
    /// 31=Satınalma. Sipariş: 1=Satış, 2=Satınalma. Form bu kodla doğru türü seçer.
    public int? TrCode { get; set; }

    public AiCariRef? Cari { get; set; }

    public List<AiLine> Lines { get; set; } = new();

    /// Sipariş için opsiyonel vade tarihi.
    public DateTime? Vade { get; set; }
}

/// Aksiyondaki cari referansı (forma cari önceden seçilir).
public class AiCariRef
{
    public int Id { get; set; }
    public string Kod { get; set; } = "";
    public string Unvan { get; set; } = "";
}

/// Aksiyondaki tek bir satır (forma kalem önceden eklenir).
public class AiLine
{
    public int StokRef { get; set; }
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";
    public string Birim { get; set; } = "";
    public decimal Miktar { get; set; } = 1m;

    /// Fiyat belirtilmediyse null → form malzemenin tanımlı fiyatını kullanır.
    public decimal? Fiyat { get; set; }
}
