namespace LogoMobileApi.Models;

/// <summary>
/// Patron paneli özeti — tüm finansal göstergeler tek çağrıda döner.
/// Kaynak tablolar (firma 126 / dönem 01 üzerinde doğrulandı):
///   - Net alacak/borç : LV_{F}_{D}_GNTOTCL (TOTTYP=1, per-cari DEBIT-CREDIT)
///   - Yaşlandırma      : LG_{F}_{D}_PAYTRANS (SIGN=0, vadesi geçen taksitler)
///   - Banka            : LG_{F}_{D}_GNTOTBN  (TOTTYP=-1) ⋈ LG_{F}_BNCARD
///   - Kasa             : LG_{F}_{D}_GNTOTCSH (TOTTYPE=-1) ⋈ LG_{F}_KSCARD
///   - Çek/senet        : LG_{F}_{D}_CSCARD   (DOC + CURRSTAT + DUEDATE)
///   - Trend            : LG_{F}_{D}_CLFLINE  (bu ay net hareket)
/// </summary>
public class PatronOzet
{
    // ── Net alacak / borç (firma geneli) ──
    public decimal ToplamAlacak { get; set; }      // alacaklı carilerin toplamı (bizden alacaklı = bize borçlu)
    public decimal ToplamBorc { get; set; }        // borçlu olduğumuz carilerin toplamı (pozitif gösterilir)
    public decimal NetBakiye { get; set; }         // ToplamAlacak - ToplamBorc
    public int AlacakliCariSayisi { get; set; }
    public int BorcluCariSayisi { get; set; }

    // ── Yaşlandırma (vadesi geçen alacak, gün kovaları) ──
    public decimal Yaslandirma0_30 { get; set; }
    public decimal Yaslandirma31_60 { get; set; }
    public decimal Yaslandirma61_90 { get; set; }
    public decimal Yaslandirma90Plus { get; set; }
    public decimal ToplamVadesiGecen { get; set; }

    // ── Nakit & banka ──
    public decimal KasaBakiye { get; set; }
    public int KasaHesapSayisi { get; set; }
    public decimal BankaBakiye { get; set; }
    public int BankaHesapSayisi { get; set; }
    public decimal NakitToplam { get; set; }       // kasa + banka

    // ── Çek / senet ──
    public decimal CekTahsilTutar { get; set; }    // tahsil edilecek (müşteri çek/senet, elimizde/bankada)
    public int CekTahsilAdet { get; set; }
    public decimal CekOdemeTutar { get; set; }     // ödenecek (kendi çek/senedimiz)
    public int CekOdemeAdet { get; set; }
    public decimal CekKarsiliksizTutar { get; set; } // karşılıksız çıkan müşteri çekleri (kırmızı bayrak)
    public int CekKarsiliksizAdet { get; set; }
    // tahsil edilecek çek vade kovaları
    public decimal CekVadesiGecmis { get; set; }
    public decimal CekBuHafta { get; set; }
    public decimal CekBuAy { get; set; }
    public decimal CekSonra { get; set; }

    // ── Trend (geçen aya göre net değişim) ──
    public decimal BuAyNetDegisim { get; set; }
    public decimal? TrendYuzde { get; set; }       // null = veri yok / hesaplanamadı → UI rozeti gizler
}

/// <summary>Banka (BNCARD) + altındaki hesapların toplam bakiyesi (drill-down 1. seviye).</summary>
public class BankaKayit
{
    public int Id { get; set; }                    // BNCARD.LOGICALREF
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";           // BNCARD.DEFINITION_ (banka adı)
    public int HesapSayisi { get; set; }           // bu bankanın aktif hesap sayısı (BANKACC)
    public decimal Bakiye { get; set; }            // hesapların toplamı (BNFLINE'dan)
}

/// <summary>Banka hesabı (BANKACC) + güncel bakiye (drill-down 2. seviye).</summary>
public class BankaHesap
{
    public int Id { get; set; }                    // BANKACC.LOGICALREF
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";           // BANKACC.DEFINITION_ (ör. "AKBANK (USD)")
    public decimal Bakiye { get; set; }            // BNFLINE: SUM(SIGN=0? +AMOUNT : -AMOUNT)
    public int Currency { get; set; }              // BANKACC.CURRENCY (0=TL,1=USD,17=GBP,20=EUR)
    public string CurrencyKod { get; set; } = "";  // "TL"/"USD"/... (servis doldurur)
    public string Iban { get; set; } = "";
}

/// <summary>Tek bir çek/senet kaydı (drill-down listesi).</summary>
public class CekKayit
{
    public int Id { get; set; }
    public int Doc { get; set; }                   // 1=müşteri çeki, 2=müşteri senedi, 3=kendi çekimiz, 4=kendi senedimiz
    public string Tur { get; set; } = "";          // "Çek" / "Senet"
    public int CurrStat { get; set; }
    public string Durum { get; set; } = "";        // Türkçe durum etiketi
    public DateTime? Vade { get; set; }
    public decimal Tutar { get; set; }
    public string Banka { get; set; } = "";        // BANKNAME
    public string Kesideci { get; set; } = "";     // OWING (borçlu / keşideci)
    public string CariAd { get; set; } = "";       // çekin bağlı olduğu cari (CSTRANS.CARDMD=5 → CLCARD)
}
