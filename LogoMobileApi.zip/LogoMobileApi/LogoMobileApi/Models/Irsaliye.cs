namespace LogoMobileApi.Models;

// İrsaliye başlığı — LG_xxx_yy_STFICHE projection.
public class Irsaliye
{
    public int Id { get; set; }                       // STFICHE.LOGICALREF
    public string FicheNo { get; set; } = "";         // STFICHE.FICHENO
    public string DocCode { get; set; } = "";         // STFICHE.DOCODE
    public DateTime Date { get; set; }                // STFICHE.DATE_
    public int TrCode { get; set; }                   // 1=satınalma irsaliyesi, 8=toptan satış irs vb.
    public string TrCodeName { get; set; } = "";
    public int ClientRef { get; set; }                // STFICHE.CLIENTREF
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";
    public decimal NetTotal { get; set; }
    public int? InvoiceRef { get; set; }              // STFICHE.INVOICEREF (faturalandıysa)
    public string InvNo { get; set; } = "";           // STFICHE.INVNO
    public int Billed { get; set; }                   // STFICHE.BILLED (1=faturalandı)
    public int Cancelled { get; set; }

    // Taslak akışı için — dbo.ShipmentDrafts'ten geliyorsa doldurulur (Fatura ile paralel)
    public bool IsDraft { get; set; }                  // dbo.ShipmentDrafts'ten geliyorsa true
    public string DraftStatus { get; set; } = "";      // 'Draft' | 'Transferred' | 'Failed' (taslaksa)
    public string? LastError { get; set; }             // hata mesajı (Failed durumunda)
    public string? ApprovalStatus { get; set; }        // 'Pending' | 'Approved' | 'Rejected' (taslaksa)
}
