namespace LogoMobileApi.Models;

// Stok durum raporu satırı — malzeme ad/açıklama + fiili ve gerçek (kullanılabilir) stok
public class StokRapor
{
    public int Id { get; set; }
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";
    public string Aciklama { get; set; } = "";   // ITEMS.NAME2
    public string Birim { get; set; } = "";
    public string Tur { get; set; } = "";        // CARDTYPE → Türkçe ad
    public double FiiliStok { get; set; }        // SUM(ONHAND)
    public double GercekStok { get; set; }       // SUM(ONHAND - RESERVED)
}
