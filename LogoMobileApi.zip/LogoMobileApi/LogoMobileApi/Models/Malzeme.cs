namespace LogoMobileApi.Models;

public class Malzeme
{
    public int Id { get; set; }
    public string Kod { get; set; } = string.Empty;
    public string Ad { get; set; } = string.Empty;
    public string GrupKodu { get; set; } = string.Empty;
    public string Birim { get; set; } = string.Empty;
    public string Tur { get; set; } = string.Empty;
    public double FiiliStok { get; set; }
    public double GercekStok { get; set; }
}
