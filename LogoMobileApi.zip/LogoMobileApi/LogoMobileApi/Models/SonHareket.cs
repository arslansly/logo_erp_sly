﻿namespace LogoMobileApi.Models;

public class SonHareket
{
    public int Id { get; set; }
    public int CariId { get; set; }
    public string CariCode { get; set; } = "";
    public string CariTitle { get; set; } = "";
    public DateTime Date { get; set; }
    public int TransactionType { get; set; }
    public string TransactionTypeName { get; set; } = "";
    public decimal Debit { get; set; }
    public decimal Credit { get; set; }
}