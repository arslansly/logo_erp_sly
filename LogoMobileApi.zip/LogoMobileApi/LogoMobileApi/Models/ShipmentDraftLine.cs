namespace LogoMobileApi.Models;

// Taslak irsaliye satırı — dbo.ShipmentDraftLines tablosu.
public class ShipmentDraftLine
{
    public int Id { get; set; }
    public int DraftId { get; set; }
    public int LineNo { get; set; }
    public int LineType { get; set; } = 0;              // 0=Malzeme,1=Hizmet,2=Masraf,4=İskonto

    public int? StockRef { get; set; }
    public string? StockCode { get; set; }
    public string? StockName { get; set; }
    public int? UomRef { get; set; }
    public string? UomCode { get; set; }

    public decimal Amount { get; set; }
    public decimal Price { get; set; }
    public decimal VatRate { get; set; }
    public decimal Discount { get; set; }
    public decimal Total { get; set; }
    public decimal VatAmount { get; set; }
    public decimal LineNet { get; set; }
    public string? LineDescription { get; set; }
}
