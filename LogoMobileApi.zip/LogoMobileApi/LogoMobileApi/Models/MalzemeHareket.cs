namespace LogoMobileApi.Models;

public class MalzemeHareket
{
    public int Id { get; set; }
    public DateTime Tarih { get; set; }
    public int IslemTipi { get; set; }
    public string IslemTipiAdi { get; set; } = string.Empty;
    public string FisNo { get; set; } = string.Empty;
    public string CariAdi { get; set; } = string.Empty;
    public string Aciklama { get; set; } = string.Empty;
    public double Miktar { get; set; }
    public double BirimFiyat { get; set; }
    public double Tutar { get; set; }
    public bool Giris { get; set; }
    public bool Fatura { get; set; }
    public string Ambar { get; set; } = string.Empty;
}
