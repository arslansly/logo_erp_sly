namespace LogoMobileApi.Models;

// LG_xxx_yy_STLINE projection — fatura satırı.
// LINETYPE: 0=Malzeme, 1=Hizmet, 2=Masraf, 4=İskonto
public class FaturaSatir
{
    public int Id { get; set; }                        // STLINE.LOGICALREF
    public int LineNo { get; set; }                    // STLINE.GLINENO (sıra)
    public int LineType { get; set; }                  // STLINE.LINETYPE
    public string LineTypeName { get; set; } = "";     // "Malzeme" / "Hizmet" / "Masraf" / "İskonto"

    public int? StockRef { get; set; }                 // STLINE.STOCKREF → ITEMS.LOGICALREF
    public string StockCode { get; set; } = "";        // ITEMS.CODE
    public string StockName { get; set; } = "";        // ITEMS.NAME

    public string UomCode { get; set; } = "";          // UNITSETL.CODE (birim)

    public decimal Amount { get; set; }                // STLINE.AMOUNT
    public decimal Price { get; set; }                 // STLINE.PRICE
    public decimal VatRate { get; set; }               // STLINE.VAT
    public decimal Total { get; set; }                 // STLINE.TOTAL (brüt: amount*price)
    public decimal VatAmount { get; set; }             // STLINE.VATAMNT
    public decimal LineNet { get; set; }               // STLINE.LINENET
    public decimal Discount { get; set; }              // STLINE.DISTDISC
    public string LineDescription { get; set; } = ""; // STLINE.LINEEXP
}
