﻿namespace LogoMobileApi.Models;

public class VadesiGecenCari
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string City { get; set; } = "";
    public string Phone { get; set; } = "";
    public decimal VadesiGecenTutar { get; set; }
    public int EnEskiGunFarki { get; set; }
    public DateTime EnEskiVadeTarihi { get; set; }
    public int VadeSayisi { get; set; }  // kaç tane vadesi geçmiş vade var
}