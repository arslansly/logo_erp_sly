namespace LogoMobileApi.Models;

/// <summary>
/// Onay iş akışı modelleri — satışçının kestiği taslaklar (fatura/sipariş/irsaliye)
/// patron/muhasebe onayına düşer. Üç belge türü tek birleşik listede gösterilir.
/// </summary>
public class OnayBekleyen
{
    public string Tip { get; set; } = "";        // "fatura" | "siparis" | "irsaliye"
    public int Id { get; set; }
    public int TrCode { get; set; }
    public string TrCodeAd { get; set; } = "";   // okunabilir tür adı (mapper'dan)
    public string? FicheNo { get; set; }
    public string? DocCode { get; set; }
    public DateTime Date { get; set; }
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";
    public decimal NetTotal { get; set; }
    public string CreatedBy { get; set; } = "";  // taslağı oluşturan (satışçı)
    public DateTime CreatedAt { get; set; }
}

// Onay bekleyen sayıları (Patron paneli rozet/banner için).
public class OnayOzet
{
    public int Fatura { get; set; }
    public int Siparis { get; set; }
    public int Irsaliye { get; set; }
    public int Toplam => Fatura + Siparis + Irsaliye;
}

// Reddetme gerekçesi (opsiyonel).
public class OnayKararRequest
{
    public string? Reason { get; set; }
}
