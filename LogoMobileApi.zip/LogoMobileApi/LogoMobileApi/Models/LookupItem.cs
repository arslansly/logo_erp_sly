namespace LogoMobileApi.Models;

// Lookup tablolarının ortak hafif projection'ı (SLSMAN/PAYPLANS/SHIPINFO vb.)
public class LookupItem
{
    public int Id { get; set; }              // LOGICALREF
    public string Code { get; set; } = "";   // CODE
    public string Name { get; set; } = "";   // DEFINITION_
}
