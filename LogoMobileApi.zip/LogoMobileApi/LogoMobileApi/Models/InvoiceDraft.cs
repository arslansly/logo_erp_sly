namespace LogoMobileApi.Models;

// Taslak fatura başlığı — dbo.InvoiceDrafts tablosu.
// Aktarımda LOGO LG_xxx_yy_INVOICE'a INSERT edilir, kayıt 'Transferred' olur.
public class InvoiceDraft
{
    public int Id { get; set; }
    public int TrCode { get; set; }
    public string? FicheNo { get; set; }
    public string? DocCode { get; set; }
    public DateTime Date { get; set; }

    // Cari snapshot
    public int ClientRef { get; set; }
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";

    // Ambar (opsiyonel)
    public int? SourceIndex { get; set; }
    public int? DestIndex { get; set; }

    // Toplamlar
    public decimal GrossTotal { get; set; }
    public decimal TotalDiscounts { get; set; }
    public decimal TotalVat { get; set; }
    public decimal NetTotal { get; set; }

    // Döviz — CurrencyType=0 ise TL (ExchangeRate=1). >0 ise L_CURRENCYLIST.CURTYPE.
    public int CurrencyType { get; set; } = 0;
    public decimal ExchangeRate { get; set; } = 1m;

    // Opsiyonel referans alanları (LOGO INVOICE'a aktarımda kullanılır)
    public int? SalesmanRef { get; set; }       // LG_SLSMAN.LOGICALREF
    public int? PayDefRef { get; set; }         // LG_xxx_PAYPLANS.LOGICALREF

    // Açıklamalar
    public string? GenExp1 { get; set; }
    public string? GenExp2 { get; set; }

    // Durum
    public string Status { get; set; } = "Draft";       // 'Draft' | 'Transferred' | 'Failed'
    public int? TransferredInvoiceId { get; set; }
    public DateTime? TransferredAt { get; set; }
    public string? LastError { get; set; }

    // Metadata
    public string CreatedBy { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    // Satırlar — DB'den ayrı çekilip set edilir, request'te birlikte gelir
    public List<InvoiceDraftLine> Lines { get; set; } = new();
}
