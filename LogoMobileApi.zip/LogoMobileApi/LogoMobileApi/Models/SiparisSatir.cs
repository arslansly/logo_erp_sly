namespace LogoMobileApi.Models;

// Sipariş satırı — LG_xxx_yy_ORFLINE projection.
public class SiparisSatir
{
    public int Id { get; set; }                  // ORFLINE.LOGICALREF
    public int LineNo { get; set; }
    public int LineType { get; set; }            // 0=Malzeme, 1=Hizmet, 2=Masraf, 4=İskonto
    public string LineTypeName { get; set; } = "";
    public int? StockRef { get; set; }
    public string StockCode { get; set; } = "";
    public string StockName { get; set; } = "";
    public string UomCode { get; set; } = "";
    public decimal Amount { get; set; }          // Sipariş miktarı
    public decimal ShippedAmount { get; set; }   // Sevk edilen miktar
    public decimal Price { get; set; }
    public decimal VatRate { get; set; }
    public decimal Total { get; set; }
    public decimal VatAmount { get; set; }
    public decimal LineNet { get; set; }
    public decimal Discount { get; set; }
    public DateTime? DueDate { get; set; }       // Termin tarihi
    public int Closed { get; set; }              // 0=Açık, 1=Kapalı
    public int Status { get; set; }              // ORFICHE.STATUS ile aynı kod tablosu
    public string LineDescription { get; set; } = "";
}

public class SiparisDetay
{
    public Siparis Baslik { get; set; } = new();
    public List<SiparisSatir> Satirlar { get; set; } = new();
    // Bu siparişe bağlı sevkiyatlar (irsaliyeler) — STLINE.ORDFICHEREF üzerinden
    public List<BagliBelge> Irsaliyeler { get; set; } = new();
    public string GenExp1 { get; set; } = "";
    public string GenExp2 { get; set; } = "";
}
