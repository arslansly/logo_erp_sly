namespace LogoMobileApi.Models;

/// <summary>
/// Satış performans / ciro raporu — özet KPI + aylık ciro trendi + satışçı kırılımı
/// + en çok satış yapılan müşteriler. Ciro = satış faturalarının KDV hariç net tutarı
/// (NETTOTAL - TOTALVAT), LOGO'nun standart satış raporlarıyla tutarlı olsun diye.
/// Satış faturası = INVOICE.TRCODE IN (7,8,9), CANCELLED=0 (bu kurulumun kodlaması).
/// </summary>
public class SatisPerformansRapor
{
    public decimal ToplamCiro { get; set; }
    public int FaturaSayisi { get; set; }
    public decimal OrtalamaFatura { get; set; }
    public List<AylikCiro> AylikTrend { get; set; } = new();
    public List<SatisciPerformans> Satiscilar { get; set; } = new();
    public List<MusteriCiro> TopMusteriler { get; set; } = new();
}

// Bir aya ait ciro + fatura adedi (trend grafiği için, kronolojik sıralı döner).
public class AylikCiro
{
    public int Yil { get; set; }
    public int Ay { get; set; }
    public decimal Ciro { get; set; }
    public int Adet { get; set; }
}

// Satışçı bazında ciro performansı (leaderboard — cirosu azalan).
public class SatisciPerformans
{
    public int Id { get; set; }
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";
    public decimal Ciro { get; set; }
    public int Adet { get; set; }
}

// Müşteri bazında ciro (en çok satış yapılan ilk N müşteri).
public class MusteriCiro
{
    public int CariId { get; set; }
    public string Kod { get; set; } = "";
    public string Ad { get; set; } = "";
    public decimal Ciro { get; set; }
    public int Adet { get; set; }
}
