namespace LogoMobileApi.Models;

// Vade raporu satırı — vadesi geçmiş bakiyesi olan cariler, yaşlandırma kovalarıyla
public class VadeRapor
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string City { get; set; } = "";
    public string Phone { get; set; } = "";

    public decimal ToplamVadesiGecen { get; set; }
    public DateTime EnEskiVadeTarihi { get; set; }
    public int EnEskiGunFarki { get; set; }
    public int VadeSayisi { get; set; }

    // Yaşlandırma kovaları (gün)
    public decimal Vadesi_0_30 { get; set; }
    public decimal Vadesi_31_60 { get; set; }
    public decimal Vadesi_61_90 { get; set; }
    public decimal Vadesi_90Plus { get; set; }
}
