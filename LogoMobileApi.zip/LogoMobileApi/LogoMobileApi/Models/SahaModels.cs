namespace LogoMobileApi.Models;

/// <summary>
/// Saha (satışçı) paneli modelleri. Satışçı boyutu belgelerdeki SALESMANREF üzerinden
/// kurulur (bu kurulumda LG_SLSCLREL boş; kredi limiti DBSLIMIT alanları kullanılmıyor).
/// Kaynak (firma 126 / dönem 01 üzerinde doğrulandı):
///   - Satışçılar / açık sipariş : LG_{F}_{D}_ORFICHE (TRCODE=1, STATUS IN (3,4)) ⋈ ORFLINE (CLOSED=0) ⋈ LG_SLSMAN
///   - Riskli müşteri / vade     : LG_{F}_{D}_PAYTRANS (SIGN=0, vadesi geçmiş taksit)
/// "Açık sipariş tutarı" = sevki bekleyen (CLOSED=0) satırların LINENET toplamı.
/// </summary>

/// <summary>Satışçı + açık iş özeti (leaderboard / seçici kaynağı).</summary>
public class SahaSatisci
{
    public int Id { get; set; }                 // LG_SLSMAN.LOGICALREF
    public string Kod { get; set; } = "";       // CODE (SO.001 = satış, PO.001 = satınalma)
    public string Ad { get; set; } = "";        // DEFINITION_
    public int AcikSiparisAdet { get; set; }    // sevki bekleyen sipariş sayısı
    public decimal AcikSiparisTutar { get; set; }
    public int MusteriSayisi { get; set; }      // açık siparişi olan farklı müşteri
}

/// <summary>Seçili kapsam (satışçı ya da "tümü") için saha özeti.</summary>
public class SahaOzet
{
    public int? SatisciRef { get; set; }        // null = tümü
    public string SatisciAd { get; set; } = "Tüm satışçılar";
    public decimal AcikSiparisTutar { get; set; }
    public int AcikSiparisAdet { get; set; }
    public int MusteriSayisi { get; set; }
    // Risk (vadesi geçen alacak — bu satışçının müşterileri)
    public int RiskliCariSayisi { get; set; }
    public decimal VadesiGecenToplam { get; set; }
    // Kredi limitini aşan müşteri sayısı (kapsamda). Limit kullanmayan firmalarda 0 → UI rozeti gizler.
    public int LimitAsanSayisi { get; set; }
}

/// <summary>Açık (sevk bekleyen) sipariş satırı — drill-down listesi.</summary>
public class SahaAcikSiparis
{
    public int Id { get; set; }                 // ORFICHE.LOGICALREF (detay için)
    public string FicheNo { get; set; } = "";
    public DateTime Tarih { get; set; }
    public int CariId { get; set; }
    public string CariAd { get; set; } = "";
    public string SatisciAd { get; set; } = "";
    public decimal BekleyenTutar { get; set; }  // CLOSED=0 satırların LINENET toplamı
    public int GunGecti { get; set; }           // sipariş tarihinden bugüne gün (sahada "ne kadar bekledi")
}

/// <summary>Riskli müşteri — vadesi geçen alacağı + açık siparişi olan cari.</summary>
public class SahaRiskliCari
{
    public int CariId { get; set; }
    public string CariKod { get; set; } = "";
    public string CariAd { get; set; } = "";
    public decimal Bakiye { get; set; }         // güncel bakiye (borç +)
    public decimal VadesiGecen { get; set; }    // vadesi geçmiş alacak
    public int EnEskiGun { get; set; }          // en eski geçen vadenin gün farkı
    public decimal AcikSiparis { get; set; }    // sevk bekleyen sipariş tutarı
    public decimal KrediLimiti { get; set; }    // kredi/risk limiti (0 = tanımsız → UI rozet göstermez)
}
