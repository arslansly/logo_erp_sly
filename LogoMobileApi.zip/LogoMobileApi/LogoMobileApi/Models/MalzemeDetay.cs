namespace LogoMobileApi.Models;

public class MalzemeDetay : Malzeme
{
    public string Aciklama2 { get; set; } = string.Empty;
    public string Aciklama3 { get; set; } = string.Empty;
    public string OzelKod1 { get; set; } = string.Empty;
    public string OzelKod2 { get; set; } = string.Empty;
    public string OzelKod3 { get; set; } = string.Empty;
    public string OzelKod4 { get; set; } = string.Empty;
    public string OzelKod5 { get; set; } = string.Empty;
    public double SatinalmaFiyati { get; set; }
    public string SatinalmaDoviz { get; set; } = "TL";
    public double SatisFiyati { get; set; }
    public string SatisDoviz { get; set; } = "TL";
    public double SonAlisFiyati { get; set; }
    public double SonSatisFiyati { get; set; }
    public List<AmbarStok> AmbarStoklar { get; set; } = new();
}
