namespace LogoMobileApi.Models;

// Sipariş başlığı — LG_xxx_yy_ORFICHE projection.
// Fatura yapısına paralel; tek fark STATUS alanı (sipariş durumu) + CLOSED.
public class Siparis
{
    public int Id { get; set; }                       // ORFICHE.LOGICALREF
    public string FicheNo { get; set; } = "";         // ORFICHE.FICHENO
    public string DocCode { get; set; } = "";         // ORFICHE.DOCODE
    public DateTime Date { get; set; }                // ORFICHE.DATE_
    public int TrCode { get; set; }                   // 1=Satış (alınan), 2=Satınalma (verilen)
    public string TrCodeName { get; set; } = "";
    public int ClientRef { get; set; }                // ORFICHE.CLIENTREF
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";
    public decimal NetTotal { get; set; }
    public int Status { get; set; }                   // 1=Öneri 2=Sevkedilemez 3=Sevkedilebilir 4=Sevkedildi
    public string StatusName { get; set; } = "";
    public int Cancelled { get; set; }
    public int Closed { get; set; }

    // Satırlardan (ORFLINE) türetilen sevk durumu — kapanış-duyarlı.
    // Kapalı satır tamamı sevkedilmiş sayılır (SHIPPEDAMOUNT güncellenmese de).
    public decimal ToplamMiktar { get; set; }    // SUM(AMOUNT)
    public decimal SevkMiktar { get; set; }      // SUM(kapalı ? AMOUNT : SHIPPEDAMOUNT)
    public decimal BekleyenMiktar { get; set; }  // SUM(kapalı ? 0 : max(0, AMOUNT-SHIPPEDAMOUNT))

    // Taslak akışı için — dbo.OrderDrafts'ten geliyorsa doldurulur (Fatura ile paralel)
    public bool IsDraft { get; set; }                  // dbo.OrderDrafts'ten geliyorsa true
    public string DraftStatus { get; set; } = "";      // 'Draft' | 'Transferred' | 'Failed' (taslaksa)
    public string? LastError { get; set; }             // hata mesajı (Failed durumunda)
    public string? ApprovalStatus { get; set; }        // 'Pending' | 'Approved' | 'Rejected' (taslaksa)
}
