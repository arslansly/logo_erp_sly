﻿namespace LogoMobileApi.Models;

public class CariHareket
{
    public int Id { get; set; }
    public DateTime Date { get; set; }
    public int TransactionType { get; set; }            // TRCODE sayısal değeri
    public string TransactionTypeName { get; set; } = ""; // Türkçe açıklaması
    public string Description { get; set; } = "";       // LINEEXP - hareket açıklaması
    public decimal Debit { get; set; }                  // Borç
    public decimal Credit { get; set; }                 // Alacak
    public string DocumentNo { get; set; } = "";        // Belge numarası (DOCODE)
    public string TransactionNo { get; set; } = "";     // Hareket numarası (TRANNO)
}