﻿namespace LogoMobileApi.Models;

public class CariVadeAnalizi
{
    public int CariId { get; set; }

    // Yaşlandırma bucket'ları
    public decimal VadesiGelmemis { get; set; }   // Henüz vadesi gelmedi
    public decimal Vadesi_0_30 { get; set; }      // 1-30 gün geçti
    public decimal Vadesi_31_60 { get; set; }     // 31-60 gün geçti
    public decimal Vadesi_61_90 { get; set; }     // 61-90 gün geçti
    public decimal Vadesi_90Plus { get; set; }    // 90+ gün geçti (kritik)

    // Hesaplanan özetler
    public decimal ToplamVadesiGecen =>
        Vadesi_0_30 + Vadesi_31_60 + Vadesi_61_90 + Vadesi_90Plus;

    public decimal Bakiye =>
        VadesiGelmemis + ToplamVadesiGecen;

    // En eski vade ne kadar geride
    public int? EnEskiVadeGunFarki { get; set; }
    public DateTime? EnEskiVadeTarihi { get; set; }

    // En son tahsilatın tarihi (mobilde "Son tahsilat: 3 hafta önce" için)
    public DateTime? SonTahsilatTarihi { get; set; }
}