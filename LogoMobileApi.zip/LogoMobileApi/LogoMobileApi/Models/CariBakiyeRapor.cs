namespace LogoMobileApi.Models;

// Cari hesap/bakiye raporu satırı — kod, ad, konum, iletişim ve borç/alacak/bakiye
public class CariBakiyeRapor
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string City { get; set; } = "";
    public string Country { get; set; } = "";
    public string Phone { get; set; } = "";
    public decimal ToplamBorc { get; set; }
    public decimal ToplamAlacak { get; set; }
    public decimal Bakiye { get; set; }   // ToplamBorc - ToplamAlacak (>0 borçlu, <0 alacaklı)
}
