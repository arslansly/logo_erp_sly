namespace LogoMobileApi.Models;

// Detay ekranı için header + satırlar + bağlı belgeler bundle'ı.
public class FaturaDetay
{
    public Fatura Baslik { get; set; } = new();
    public List<FaturaSatir> Satirlar { get; set; } = new();

    // İlişkili belgeler (sadece ID listesi — detayı ayrıca çekilir)
    public List<BagliBelge> Irsaliyeler { get; set; } = new();
    public List<BagliBelge> Siparisler { get; set; } = new();

    // LOGO INVOICE.GENEXP1..4 — boş olanları UI gizler
    public string GenExp1 { get; set; } = "";
    public string GenExp2 { get; set; } = "";
    public string GenExp3 { get; set; } = "";
    public string GenExp4 { get; set; } = "";
}

public class BagliBelge
{
    public int Id { get; set; }
    public string FicheNo { get; set; } = "";
    public DateTime Date { get; set; }
    public int TrCode { get; set; }
    public string TrCodeName { get; set; } = "";
    public decimal Total { get; set; }
}
