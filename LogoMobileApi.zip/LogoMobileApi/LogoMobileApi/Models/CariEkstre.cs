namespace LogoMobileApi.Models;

public class CariEkstreSatir
{
    public int Id { get; set; }
    public DateTime Tarih { get; set; }
    public int IslemTipi { get; set; }
    public string IslemTipiAdi { get; set; } = "";
    public string DocumentNo { get; set; } = "";
    public string Aciklama { get; set; } = "";
    public decimal Borc { get; set; }
    public decimal Alacak { get; set; }
    public decimal YurutulenBakiye { get; set; }
}

public class CariEkstre
{
    public int CariId { get; set; }
    public DateTime BaslangicTarihi { get; set; }
    public DateTime BitisTarihi { get; set; }
    public decimal DevirBakiyesi { get; set; }
    public decimal ToplamBorc { get; set; }
    public decimal ToplamAlacak { get; set; }
    public decimal KapanisBakiyesi { get; set; }
    public List<CariEkstreSatir> Hareketler { get; set; } = new();
}
