namespace LogoMobileApi.Models;

// Taslak irsaliye başlığı — dbo.ShipmentDrafts tablosu.
// Aktarımda LOGO LG_xxx_yy_STFICHE'ye INSERT edilir, kayıt 'Transferred' olur.
public class ShipmentDraft
{
    public int Id { get; set; }
    public int TrCode { get; set; }                     // 1=Satınalma, 7/8=Satış, 2/3/6=İade
    public string? FicheNo { get; set; }
    public string? DocCode { get; set; }
    public DateTime Date { get; set; }

    // Cari snapshot
    public int ClientRef { get; set; }
    public string ClientCode { get; set; } = "";
    public string ClientTitle { get; set; } = "";

    // Ambar (L_CAPIWHOUSE.NR ile eşleşir)
    public int? SourceIndex { get; set; }
    public int? DestIndex { get; set; }

    // Taşıyıcı kodu (serbest metin)
    public string? ShipInfoCode { get; set; }

    // Toplamlar
    public decimal GrossTotal { get; set; }
    public decimal TotalDiscounts { get; set; }
    public decimal TotalVat { get; set; }
    public decimal NetTotal { get; set; }

    // Döviz — CurrencyType=0 ise TL (ExchangeRate=1). >0 ise L_CURRENCYLIST.CURTYPE.
    public int CurrencyType { get; set; } = 0;
    public decimal ExchangeRate { get; set; } = 1m;

    // Açıklamalar
    public string? GenExp1 { get; set; }
    public string? GenExp2 { get; set; }

    // Durum
    public string Status { get; set; } = "Draft";       // 'Draft' | 'Transferred' | 'Failed'
    public int? TransferredShipmentId { get; set; }
    public DateTime? TransferredAt { get; set; }
    public string? LastError { get; set; }

    // Metadata
    public string CreatedBy { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }

    // Satırlar — DB'den ayrı çekilip set edilir, request'te birlikte gelir
    public List<ShipmentDraftLine> Lines { get; set; } = new();
}
