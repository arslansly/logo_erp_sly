﻿namespace LogoMobileApi.Models;

public class VadeOzeti
{
    public decimal ToplamAlacak { get; set; }       // Tüm carilerin net bakiyesi (alacak)
    public decimal ToplamVadesiGecen { get; set; }  // Tüm vadesi geçen toplam
    public int VadesiGecenCariSayisi { get; set; }  // Kaç müşterinin vadesi geçmiş
}