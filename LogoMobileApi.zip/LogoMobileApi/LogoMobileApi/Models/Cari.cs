﻿namespace LogoMobileApi.Models;

public class Cari
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public decimal Balance { get; set; }
    public string City { get; set; } = "";
    public string Phone { get; set; } = "";

    // ── Yeni eklenenler ──
    public string TaxNumber { get; set; } = "";
    public string Address { get; set; } = "";
    public string Email { get; set; } = "";
    public string Country { get; set; } = "";

    // CLCARD.EINVOICE → 0: yok, 1: e-Fatura mükellefi, 2: e-Arşiv mükellefi
    public int EInvoiceType { get; set; }

    // Açık (sevk bekleyen) satış siparişi tutarı — yalnızca detay (GetById) çağrısında dolu.
    // Risk göstergesi: müşterinin ödenecek bakiyesine ek olarak ileride doğacak borç.
    public decimal AcikSiparis { get; set; }

    // Kredi / risk limiti — CLCARD.DBSLIMIT1..7'nin en yükseği (firma kullanmıyorsa 0 = "tanımsız").
    // Yalnızca detay (GetById) çağrısında dolu. Çok-firma: limiti olan firmalarda gerçek değer gelir.
    public decimal KrediLimiti { get; set; }
    // Firma bu cari için risk kontrolü açmış mı (DBSRISKCNTRL1..7'den herhangi biri).
    public bool RiskKontrolVar { get; set; }
}