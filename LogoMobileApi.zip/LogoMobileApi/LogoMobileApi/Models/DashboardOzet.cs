﻿namespace LogoMobileApi.Models;

public class DashboardOzet
{
    public decimal ToplamAlacak { get; set; }
    public decimal VadesiGecen { get; set; }
    public decimal BugunTahsilat { get; set; }
    public int VadesiGecenCariSayisi { get; set; }

    // Gerçek trend — geçen aya göre net cari değişim (CLFLINE bu ay).
    // null = veri yok / hesaplanamadı → UI trend rozetini gizler (sahte yüzde göstermez).
    public decimal? TrendYuzde { get; set; }
}