-- =============================================================================
-- 004_AddMoreLookups.sql
-- InvoiceDrafts'a 4 opsiyonel lookup referans alanı ekler:
--   ShipAgentRef     → L_SHPAGENT.LOGICALREF      (sevkiyat/taşıyıcı firma)
--   ShipTypeRef      → L_SHPTYPES.LOGICALREF      (sevkiyat türü / taşıma şekli)
--   FreightTypeRef   → L_FRGTYPES.LOGICALREF      (taşıma tipi)
--   TradingGroupRef  → L_TRADGRP.LOGICALREF       (ticari işlem grubu)
-- =============================================================================

USE LOGOMBL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'ShipAgentRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
    ALTER TABLE dbo.InvoiceDrafts ADD ShipAgentRef INT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'ShipTypeRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
    ALTER TABLE dbo.InvoiceDrafts ADD ShipTypeRef INT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'FreightTypeRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
    ALTER TABLE dbo.InvoiceDrafts ADD FreightTypeRef INT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'TradingGroupRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
    ALTER TABLE dbo.InvoiceDrafts ADD TradingGroupRef INT NULL;
GO

PRINT 'InvoiceDrafts: ShipAgentRef + ShipTypeRef + FreightTypeRef + TradingGroupRef eklendi.';
GO
