-- =============================================================================
-- 005_OrderDrafts.sql
-- Taslak sipariş tabloları — LOGO ORFICHE/ORFLINE'a yazılmadan önce mobil
-- uygulamadan gelen siparişlerin geçici depolandığı yer.
-- LOGOMBL DB'sinde dbo schema'sında oluşur. LOGO LG_* tablolarına dokunmaz.
-- Fatura taslakları (001_InvoiceDrafts.sql) ile birebir paralel; ek olarak:
--   DueDate     → fiş bazlı varsayılan termin (ORFLINE.DUEDATE'e satır bazlı yazılır)
--   LogoStatus  → ORFICHE.STATUS (yeni taslak hep 1 = Öneri)
--   satır DueDate → satır bazlı termin override
-- Çalıştırma: SSMS'te LOGOMBL DB'sine bağlanıp tek seferlik çalıştır.
-- =============================================================================

USE LOGOMBL;
GO

-- ----------------------------------------------------------------------------
-- 1) Başlık tablosu
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.OrderDrafts', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.OrderDrafts (
        Id                     INT IDENTITY(1,1) PRIMARY KEY,
        -- LOGO ORFICHE.TRCODE: 1 = Satış (alınan), 2 = Satınalma (verilen)
        TrCode                 INT NOT NULL,
        FicheNo                NVARCHAR(32)  NULL,         -- LOGO fiş no (taslakta boş; aktarımda doldurulur)
        DocCode                NVARCHAR(32)  NULL,         -- Belge no
        [Date]                 DATE NOT NULL,
        -- Fiş bazlı varsayılan termin tarihi (ORFLINE.DUEDATE'e satır bazlı yazılır)
        DueDate                DATE NULL,
        -- Cari snapshot
        ClientRef              INT NOT NULL,               -- LG_xxx_CLCARD.LOGICALREF
        ClientCode             NVARCHAR(32) NOT NULL,
        ClientTitle            NVARCHAR(256) NOT NULL,
        -- Toplamlar (canlı hesap, UI'dan gelir)
        GrossTotal             DECIMAL(18,4) NOT NULL DEFAULT 0,
        TotalDiscounts         DECIMAL(18,4) NOT NULL DEFAULT 0,
        TotalVat               DECIMAL(18,4) NOT NULL DEFAULT 0,
        NetTotal               DECIMAL(18,4) NOT NULL DEFAULT 0,
        -- Döviz — CurrencyType=0 ise TL (ExchangeRate=1). >0 ise L_CURRENCYLIST.CURTYPE.
        CurrencyType           INT NOT NULL DEFAULT 0,
        ExchangeRate           DECIMAL(18,6) NOT NULL DEFAULT 1,
        -- Opsiyonel referans alanları (LOGO ORFICHE'ye aktarımda kullanılır)
        SalesmanRef            INT NULL,                   -- LG_SLSMAN.LOGICALREF (ORFICHE.SALESMANREF)
        PayDefRef              INT NULL,                   -- LG_xxx_PAYPLANS.LOGICALREF (ORFICHE.PAYDEFREF)
        -- ORFICHE.STATUS — yeni taslak hep 1 (Öneri). Aktarımda kullanılır.
        LogoStatus             INT NOT NULL DEFAULT 1,
        -- Açıklamalar (LOGO GENEXP1..4 karşılığı)
        GenExp1                NVARCHAR(256) NULL,
        GenExp2                NVARCHAR(256) NULL,
        -- Aktarım durumu
        [Status]               NVARCHAR(20) NOT NULL DEFAULT 'Draft',
                               -- 'Draft' | 'Transferred' | 'Failed'
        TransferredOrderId     INT NULL,                   -- Aktarıldıktan sonra LOGO ORFICHE.LOGICALREF
        TransferredAt          DATETIME NULL,
        LastError              NVARCHAR(MAX) NULL,
        -- Metadata
        CreatedBy              NVARCHAR(100) NOT NULL,     -- AppUser.UserName
        CreatedAt              DATETIME NOT NULL DEFAULT GETDATE(),
        UpdatedAt              DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT CK_OrderDrafts_Status
            CHECK ([Status] IN ('Draft', 'Transferred', 'Failed'))
    );

    CREATE INDEX IX_OrderDrafts_Status_CreatedAt
        ON dbo.OrderDrafts ([Status], CreatedAt DESC);
    CREATE INDEX IX_OrderDrafts_CreatedBy
        ON dbo.OrderDrafts (CreatedBy);
    CREATE INDEX IX_OrderDrafts_ClientRef
        ON dbo.OrderDrafts (ClientRef);
END
GO

-- ----------------------------------------------------------------------------
-- 2) Satır tablosu
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.OrderDraftLines', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.OrderDraftLines (
        Id              INT IDENTITY(1,1) PRIMARY KEY,
        DraftId         INT NOT NULL,
        [LineNo]        INT NOT NULL,
        -- LOGO ORFLINE.LINETYPE: 0=Malzeme, 1=Hizmet, 2=Masraf, 4=İskonto
        LineType        INT NOT NULL DEFAULT 0,
        -- Malzeme/Hizmet snapshot
        StockRef        INT NULL,                          -- LG_xxx_ITEMS.LOGICALREF
        StockCode       NVARCHAR(64) NULL,
        StockName       NVARCHAR(256) NULL,
        UomRef          INT NULL,
        UomCode         NVARCHAR(16) NULL,
        -- Miktarlar
        Amount          DECIMAL(18,4) NOT NULL DEFAULT 0,
        Price           DECIMAL(18,6) NOT NULL DEFAULT 0,
        VatRate         DECIMAL(5,2)  NOT NULL DEFAULT 0,
        Discount        DECIMAL(18,4) NOT NULL DEFAULT 0,
        Total           DECIMAL(18,4) NOT NULL DEFAULT 0,  -- Amount * Price (brüt)
        VatAmount       DECIMAL(18,4) NOT NULL DEFAULT 0,
        LineNet         DECIMAL(18,4) NOT NULL DEFAULT 0,  -- Total - Discount + VatAmount
        -- Satır bazlı termin (boşsa fiş bazlı DueDate uygulanır) → ORFLINE.DUEDATE
        DueDate         DATE NULL,
        LineDescription NVARCHAR(512) NULL,
        CONSTRAINT FK_OrderDraftLines_Draft
            FOREIGN KEY (DraftId) REFERENCES dbo.OrderDrafts(Id) ON DELETE CASCADE
    );

    CREATE INDEX IX_OrderDraftLines_DraftId
        ON dbo.OrderDraftLines (DraftId, [LineNo]);
END
GO

PRINT 'OrderDrafts + OrderDraftLines tabloları hazır.';
GO
