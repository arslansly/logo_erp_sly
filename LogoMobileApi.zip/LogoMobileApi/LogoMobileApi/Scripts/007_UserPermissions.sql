-- Kullanıcıya özel yetki istisnaları (override).
-- Effective yetki = rolün varsayılan seti + bu tablodaki istisnalar.
-- Bir satır = belirli kullanıcı + yetki anahtarı için açık karar (Granted 1/0).
-- Satır yoksa rol varsayılanı geçerlidir.
USE LOGOMBL;
GO

IF OBJECT_ID('dbo.UserPermissions') IS NULL
BEGIN
    CREATE TABLE dbo.UserPermissions (
        UserId        INT          NOT NULL,
        PermissionKey NVARCHAR(64) NOT NULL,
        Granted       BIT          NOT NULL,
        CONSTRAINT PK_UserPermissions PRIMARY KEY (UserId, PermissionKey),
        CONSTRAINT FK_UserPermissions_AppUsers FOREIGN KEY (UserId)
            REFERENCES dbo.AppUsers(Id) ON DELETE CASCADE
    );
END
GO
