-- =============================================================================
-- 003_AddExtraFields.sql
-- InvoiceDrafts'a 3 opsiyonel referans alanı ekler:
--   SalesmanRef → LG_SLSMAN.LOGICALREF     (INVOICE.SALESMANREF)
--   PayDefRef   → LG_xxx_PAYPLANS.LOGICALREF (INVOICE.PAYDEFREF)
--   ShipInfoRef → LG_xxx_SHIPINFO.LOGICALREF (INVOICE.SHIPINFOREF)
-- =============================================================================

USE LOGOMBL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'SalesmanRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
BEGIN
    ALTER TABLE dbo.InvoiceDrafts ADD SalesmanRef INT NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'PayDefRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
BEGIN
    ALTER TABLE dbo.InvoiceDrafts ADD PayDefRef INT NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'ShipInfoRef' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
BEGIN
    ALTER TABLE dbo.InvoiceDrafts ADD ShipInfoRef INT NULL;
END
GO

PRINT 'InvoiceDrafts.SalesmanRef + PayDefRef + ShipInfoRef kolonlari eklendi.';
GO
