-- =============================================================================
-- 006_ShipmentDrafts.sql
-- Taslak irsaliye tabloları — LOGO STFICHE/STLINE'a yazılmadan önce mobil
-- uygulamadan gelen irsaliyelerin geçici depolandığı yer.
-- LOGOMBL DB'sinde dbo schema'sında oluşur. LOGO LG_* tablolarına dokunmaz.
-- Fatura taslakları (001_InvoiceDrafts.sql) ile birebir paralel; ek olarak:
--   SourceIndex / DestIndex → ambar (STFICHE.SOURCEINDEX/DESTINDEX, L_CAPIWHOUSE.NR)
--   ShipInfoCode            → taşıyıcı kodu (serbest metin)
-- Çalıştırma: SSMS'te LOGOMBL DB'sine bağlanıp tek seferlik çalıştır.
-- =============================================================================

USE LOGOMBL;
GO

-- ----------------------------------------------------------------------------
-- 1) Başlık tablosu
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.ShipmentDrafts', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ShipmentDrafts (
        Id                     INT IDENTITY(1,1) PRIMARY KEY,
        -- LOGO STFICHE.TRCODE: 1=Satınalma, 7=Perakende Satış, 8=Toptan Satış,
        --   2=Perakende Satış İade, 3=Toptan Satış İade, 6=Satınalma İade
        TrCode                 INT NOT NULL,
        FicheNo                NVARCHAR(32)  NULL,         -- LOGO fiş no (taslakta boş; aktarımda doldurulur)
        DocCode                NVARCHAR(32)  NULL,         -- Belge no
        [Date]                 DATE NOT NULL,
        -- Cari snapshot
        ClientRef              INT NOT NULL,               -- LG_xxx_CLCARD.LOGICALREF
        ClientCode             NVARCHAR(32) NOT NULL,
        ClientTitle            NVARCHAR(256) NOT NULL,
        -- Ambar (STFICHE.SOURCEINDEX/DESTINDEX, L_CAPIWHOUSE.NR ile eşleşir)
        SourceIndex            INT NULL,
        DestIndex              INT NULL,
        -- Taşıyıcı kodu (serbest metin; LOGO SHIPINFO eşleştirmesi aktarımda yapılır)
        ShipInfoCode           NVARCHAR(32) NULL,
        -- Toplamlar (canlı hesap, UI'dan gelir)
        GrossTotal             DECIMAL(18,4) NOT NULL DEFAULT 0,
        TotalDiscounts         DECIMAL(18,4) NOT NULL DEFAULT 0,
        TotalVat               DECIMAL(18,4) NOT NULL DEFAULT 0,
        NetTotal               DECIMAL(18,4) NOT NULL DEFAULT 0,
        -- Döviz — CurrencyType=0 ise TL (ExchangeRate=1). >0 ise L_CURRENCYLIST.CURTYPE.
        CurrencyType           INT NOT NULL DEFAULT 0,
        ExchangeRate           DECIMAL(18,6) NOT NULL DEFAULT 1,
        -- Açıklamalar (LOGO GENEXP1..4 karşılığı)
        GenExp1                NVARCHAR(256) NULL,
        GenExp2                NVARCHAR(256) NULL,
        -- Aktarım durumu
        [Status]               NVARCHAR(20) NOT NULL DEFAULT 'Draft',
                               -- 'Draft' | 'Transferred' | 'Failed'
        TransferredShipmentId  INT NULL,                   -- Aktarıldıktan sonra LOGO STFICHE.LOGICALREF
        TransferredAt          DATETIME NULL,
        LastError              NVARCHAR(MAX) NULL,
        -- Metadata
        CreatedBy              NVARCHAR(100) NOT NULL,     -- AppUser.UserName
        CreatedAt              DATETIME NOT NULL DEFAULT GETDATE(),
        UpdatedAt              DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT CK_ShipmentDrafts_Status
            CHECK ([Status] IN ('Draft', 'Transferred', 'Failed'))
    );

    CREATE INDEX IX_ShipmentDrafts_Status_CreatedAt
        ON dbo.ShipmentDrafts ([Status], CreatedAt DESC);
    CREATE INDEX IX_ShipmentDrafts_CreatedBy
        ON dbo.ShipmentDrafts (CreatedBy);
    CREATE INDEX IX_ShipmentDrafts_ClientRef
        ON dbo.ShipmentDrafts (ClientRef);
END
GO

-- ----------------------------------------------------------------------------
-- 2) Satır tablosu
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.ShipmentDraftLines', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ShipmentDraftLines (
        Id              INT IDENTITY(1,1) PRIMARY KEY,
        DraftId         INT NOT NULL,
        [LineNo]        INT NOT NULL,
        -- LOGO STLINE.LINETYPE: 0=Malzeme, 1=Hizmet, 2=Masraf, 4=İskonto
        LineType        INT NOT NULL DEFAULT 0,
        -- Malzeme/Hizmet snapshot
        StockRef        INT NULL,                          -- LG_xxx_ITEMS.LOGICALREF
        StockCode       NVARCHAR(64) NULL,
        StockName       NVARCHAR(256) NULL,
        UomRef          INT NULL,
        UomCode         NVARCHAR(16) NULL,
        -- Miktarlar
        Amount          DECIMAL(18,4) NOT NULL DEFAULT 0,
        Price           DECIMAL(18,6) NOT NULL DEFAULT 0,
        VatRate         DECIMAL(5,2)  NOT NULL DEFAULT 0,
        Discount        DECIMAL(18,4) NOT NULL DEFAULT 0,
        Total           DECIMAL(18,4) NOT NULL DEFAULT 0,  -- Amount * Price (brüt)
        VatAmount       DECIMAL(18,4) NOT NULL DEFAULT 0,
        LineNet         DECIMAL(18,4) NOT NULL DEFAULT 0,  -- Total - Discount + VatAmount
        LineDescription NVARCHAR(512) NULL,
        CONSTRAINT FK_ShipmentDraftLines_Draft
            FOREIGN KEY (DraftId) REFERENCES dbo.ShipmentDrafts(Id) ON DELETE CASCADE
    );

    CREATE INDEX IX_ShipmentDraftLines_DraftId
        ON dbo.ShipmentDraftLines (DraftId, [LineNo]);
END
GO

PRINT 'ShipmentDrafts + ShipmentDraftLines tabloları hazır.';
GO
