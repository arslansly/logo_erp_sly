-- =============================================================================
-- 001_InvoiceDrafts.sql
-- Taslak fatura tabloları — LOGO INVOICE/STLINE'a yazılmadan önce mobil
-- uygulamadan gelen faturaların geçici depolandığı yer.
-- LOGOMBL DB'sinde dbo schema'sında oluşur. LOGO LG_* tablolarına dokunmaz.
-- Çalıştırma: SSMS'te LOGOMBL DB'sine bağlanıp tek seferlik çalıştır.
-- =============================================================================

USE LOGOMBL;
GO

-- ----------------------------------------------------------------------------
-- 1) Başlık tablosu
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.InvoiceDrafts', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.InvoiceDrafts (
        Id                     INT IDENTITY(1,1) PRIMARY KEY,
        -- LOGO INVOICE.TRCODE ile aynı (31..56 fatura kodları)
        TrCode                 INT NOT NULL,
        FicheNo                NVARCHAR(32)  NULL,         -- LOGO fiş no (taslakta boş; aktarımda doldurulur)
        DocCode                NVARCHAR(32)  NULL,         -- Belge no
        [Date]                 DATE NOT NULL,
        -- Cari snapshot
        ClientRef              INT NOT NULL,               -- LG_xxx_CLCARD.LOGICALREF
        ClientCode             NVARCHAR(32) NOT NULL,
        ClientTitle            NVARCHAR(256) NOT NULL,
        -- Ambar
        SourceIndex            INT NULL,
        DestIndex              INT NULL,
        -- Toplamlar (canlı hesap, UI'dan gelir)
        GrossTotal             DECIMAL(18,4) NOT NULL DEFAULT 0,
        TotalDiscounts         DECIMAL(18,4) NOT NULL DEFAULT 0,
        TotalVat               DECIMAL(18,4) NOT NULL DEFAULT 0,
        NetTotal               DECIMAL(18,4) NOT NULL DEFAULT 0,
        -- Açıklamalar (LOGO GENEXP1..4 karşılığı)
        GenExp1                NVARCHAR(256) NULL,
        GenExp2                NVARCHAR(256) NULL,
        -- Aktarım durumu
        [Status]               NVARCHAR(20) NOT NULL DEFAULT 'Draft',
                               -- 'Draft' | 'Transferred' | 'Failed'
        TransferredInvoiceId   INT NULL,                   -- Aktarıldıktan sonra LOGO INVOICE.LOGICALREF
        TransferredAt          DATETIME NULL,
        LastError              NVARCHAR(MAX) NULL,
        -- Metadata
        CreatedBy              NVARCHAR(100) NOT NULL,     -- AppUser.UserName
        CreatedAt              DATETIME NOT NULL DEFAULT GETDATE(),
        UpdatedAt              DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT CK_InvoiceDrafts_Status
            CHECK ([Status] IN ('Draft', 'Transferred', 'Failed'))
    );

    CREATE INDEX IX_InvoiceDrafts_Status_CreatedAt
        ON dbo.InvoiceDrafts ([Status], CreatedAt DESC);
    CREATE INDEX IX_InvoiceDrafts_CreatedBy
        ON dbo.InvoiceDrafts (CreatedBy);
    CREATE INDEX IX_InvoiceDrafts_ClientRef
        ON dbo.InvoiceDrafts (ClientRef);
END
GO

-- ----------------------------------------------------------------------------
-- 2) Satır tablosu
-- ----------------------------------------------------------------------------
IF OBJECT_ID('dbo.InvoiceDraftLines', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.InvoiceDraftLines (
        Id              INT IDENTITY(1,1) PRIMARY KEY,
        DraftId         INT NOT NULL,
        [LineNo]        INT NOT NULL,
        -- LOGO STLINE.LINETYPE: 0=Malzeme, 1=Hizmet, 2=Masraf, 4=İskonto
        LineType        INT NOT NULL DEFAULT 0,
        -- Malzeme/Hizmet snapshot
        StockRef        INT NULL,                          -- LG_xxx_ITEMS.LOGICALREF
        StockCode       NVARCHAR(64) NULL,
        StockName       NVARCHAR(256) NULL,
        UomRef          INT NULL,
        UomCode         NVARCHAR(16) NULL,
        -- Miktarlar
        Amount          DECIMAL(18,4) NOT NULL DEFAULT 0,
        Price           DECIMAL(18,6) NOT NULL DEFAULT 0,
        VatRate         DECIMAL(5,2)  NOT NULL DEFAULT 0,
        Discount        DECIMAL(18,4) NOT NULL DEFAULT 0,
        Total           DECIMAL(18,4) NOT NULL DEFAULT 0,  -- Amount * Price (brüt)
        VatAmount       DECIMAL(18,4) NOT NULL DEFAULT 0,
        LineNet         DECIMAL(18,4) NOT NULL DEFAULT 0,  -- Total - Discount + VatAmount
        LineDescription NVARCHAR(512) NULL,
        CONSTRAINT FK_InvoiceDraftLines_Draft
            FOREIGN KEY (DraftId) REFERENCES dbo.InvoiceDrafts(Id) ON DELETE CASCADE
    );

    CREATE INDEX IX_InvoiceDraftLines_DraftId
        ON dbo.InvoiceDraftLines (DraftId, [LineNo]);
END
GO

PRINT 'InvoiceDrafts + InvoiceDraftLines tabloları hazır.';
GO
