-- =============================================================================
-- 008_ApprovalWorkflow.sql
-- Onay iş akışı — satışçının kestiği taslaklar (fatura/sipariş/irsaliye) patron
-- tarafından onaylanır/reddedilir. Üç taslak tablosuna onay kolonları ekler.
--
-- Mevcut [Status] (Draft/Transferred/Failed) AKTARIM yaşam döngüsüdür; bu kolonlar
-- AYRI bir ONAY yaşam döngüsüdür. Yeni taslaklar varsayılan 'Pending' olarak gelir
-- (mevcut kayıtlar da 'Pending' başlar). Onaylanan taslaklar LOGO'ya aktarılabilir.
--
-- Çalıştırma: SSMS'te LOGOMBL DB'sine bağlanıp tek seferlik çalıştır. Idempotent.
-- =============================================================================

USE LOGOMBL;
GO

DECLARE @tablolar TABLE (Ad SYSNAME);
INSERT INTO @tablolar (Ad) VALUES
    ('dbo.InvoiceDrafts'),
    ('dbo.OrderDrafts'),
    ('dbo.ShipmentDrafts');

DECLARE @t SYSNAME;
DECLARE cur CURSOR FOR SELECT Ad FROM @tablolar;
OPEN cur;
FETCH NEXT FROM cur INTO @t;

WHILE @@FETCH_STATUS = 0
BEGIN
    IF OBJECT_ID(@t, 'U') IS NOT NULL
    BEGIN
        -- ApprovalStatus
        IF COL_LENGTH(@t, 'ApprovalStatus') IS NULL
        BEGIN
            DECLARE @sql1 NVARCHAR(MAX) =
                'ALTER TABLE ' + @t + ' ADD ApprovalStatus NVARCHAR(20) NOT NULL ' +
                'CONSTRAINT DF_' + REPLACE(@t, 'dbo.', '') + '_ApprovalStatus DEFAULT ''Pending'';';
            EXEC sp_executesql @sql1;

            DECLARE @sql2 NVARCHAR(MAX) =
                'ALTER TABLE ' + @t + ' ADD CONSTRAINT CK_' + REPLACE(@t, 'dbo.', '') +
                '_ApprovalStatus CHECK (ApprovalStatus IN (''Pending'', ''Approved'', ''Rejected''));';
            EXEC sp_executesql @sql2;
        END

        -- ApprovedBy
        IF COL_LENGTH(@t, 'ApprovedBy') IS NULL
        BEGIN
            DECLARE @sql3 NVARCHAR(MAX) = 'ALTER TABLE ' + @t + ' ADD ApprovedBy NVARCHAR(100) NULL;';
            EXEC sp_executesql @sql3;
        END

        -- ApprovedAt
        IF COL_LENGTH(@t, 'ApprovedAt') IS NULL
        BEGIN
            DECLARE @sql4 NVARCHAR(MAX) = 'ALTER TABLE ' + @t + ' ADD ApprovedAt DATETIME NULL;';
            EXEC sp_executesql @sql4;
        END

        -- RejectReason
        IF COL_LENGTH(@t, 'RejectReason') IS NULL
        BEGIN
            DECLARE @sql5 NVARCHAR(MAX) = 'ALTER TABLE ' + @t + ' ADD RejectReason NVARCHAR(500) NULL;';
            EXEC sp_executesql @sql5;
        END

        PRINT @t + ' → onay kolonları hazır.';
    END
    FETCH NEXT FROM cur INTO @t;
END

CLOSE cur;
DEALLOCATE cur;
GO

-- Onay bekleyenleri hızlı listelemek için index (her tabloda)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_InvoiceDrafts_Approval')
    CREATE INDEX IX_InvoiceDrafts_Approval ON dbo.InvoiceDrafts(ApprovalStatus, [Status]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_OrderDrafts_Approval')
    CREATE INDEX IX_OrderDrafts_Approval ON dbo.OrderDrafts(ApprovalStatus, [Status]);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_ShipmentDrafts_Approval')
    CREATE INDEX IX_ShipmentDrafts_Approval ON dbo.ShipmentDrafts(ApprovalStatus, [Status]);
GO
