-- =============================================================================
-- 002_AddCurrency.sql
-- InvoiceDrafts'a döviz kolonları ekler.
-- CurrencyType = 0 → TL (varsayılan), >0 → L_CURRENCYLIST.CURTYPE ile eşli.
-- ExchangeRate = işlem dövizi → TL kuru (TL ise 1).
-- =============================================================================

USE LOGOMBL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'CurrencyType' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
BEGIN
    ALTER TABLE dbo.InvoiceDrafts ADD CurrencyType INT NOT NULL DEFAULT 0;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE Name = N'ExchangeRate' AND Object_ID = OBJECT_ID(N'dbo.InvoiceDrafts'))
BEGIN
    ALTER TABLE dbo.InvoiceDrafts ADD ExchangeRate DECIMAL(18,6) NOT NULL DEFAULT 1;
END
GO

PRINT 'InvoiceDrafts.CurrencyType + ExchangeRate kolonlari eklendi.';
GO
