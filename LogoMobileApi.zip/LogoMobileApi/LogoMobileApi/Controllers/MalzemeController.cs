using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class MalzemeController : ControllerBase
{
    private readonly MalzemeService _malzemeService;

    public MalzemeController(MalzemeService malzemeService)
    {
        _malzemeService = malzemeService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] int offset = 0,
        [FromQuery] int limit = 50,
        [FromQuery] string? search = null,
        [FromQuery] string? stokDurumu = null,
        [FromQuery] int? tur = null)
    {
        try
        {
            var malzemeler = await _malzemeService.GetAllAsync(offset, limit, search, stokDurumu, tur);
            return Ok(malzemeler);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        try
        {
            var malzeme = await _malzemeService.GetByIdAsync(id);
            if (malzeme == null) return NotFound();
            return Ok(malzeme);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    [HttpGet("{id}/hareketler")]
    public async Task<IActionResult> GetHareketler(
        int id,
        [FromQuery] DateTime? baslangic = null,
        [FromQuery] DateTime? bitis = null,
        [FromQuery] bool? giris = null)
    {
        try
        {
            var hareketler = await _malzemeService.GetHareketlerAsync(id, baslangic, bitis, giris);
            return Ok(hareketler);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // Malzeme kart resmi — LG_XXX_FIRMDOC.LDATA (INFOTYPE=20, DOCTYPE=0, DOCNR=11)
    [HttpGet("{id}/resim")]
    public async Task<IActionResult> GetResim(int id)
    {
        try
        {
            var bytes = await _malzemeService.GetResimAsync(id);
            if (bytes == null || bytes.Length == 0) return NotFound();
            Response.Headers.CacheControl = "public, max-age=86400";
            return File(bytes, "image/png");
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // TEŞHİS: FIRMDOC tablosunda bu malzeme için hangi satırlar var?
    // Browser'dan /api/Malzeme/{id}/resim-debug ile çağır, INFOTYPE/DOCTYPE/DOCNR değerlerini gör.
    [HttpGet("{id}/resim-debug")]
    public async Task<IActionResult> GetResimDebug(int id)
    {
        try
        {
            var rows = await _malzemeService.GetFirmDocRowsAsync(id);
            return Ok(rows);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message, stack = ex.StackTrace });
        }
    }
}
