﻿using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;

using Microsoft.AspNetCore.Authorization;

namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly DashboardService _dashboardService;

    public DashboardController(DashboardService dashboardService)
    {
        _dashboardService = dashboardService;
    }

    // GET: api/dashboard/vadesi-gecen-cariler
    [HttpGet("vadesi-gecen-cariler")]
    public async Task<ActionResult<IEnumerable<VadesiGecenCari>>> GetVadesiGecenCariler()
    {
        var cariler = await _dashboardService.GetVadesiGecenCarilerAsync();
        return Ok(cariler);
    }

    // GET: api/dashboard/ozet
    [HttpGet("ozet")]
    public async Task<ActionResult<DashboardOzet>> GetOzet()
    {
        var ozet = await _dashboardService.GetOzetAsync();
        return Ok(ozet);
    }

    // GET: api/dashboard/son-hareketler?limit=10
    [HttpGet("son-hareketler")]
    public async Task<ActionResult<IEnumerable<SonHareket>>> GetSonHareketler(
        [FromQuery] int limit = 10)
    {
        var hareketler = await _dashboardService.GetSonHareketlerAsync(limit);
        return Ok(hareketler);
    }

    // GET: api/dashboard/bugun-tahsilatlar
    [HttpGet("bugun-tahsilatlar")]
    public async Task<ActionResult<IEnumerable<SonHareket>>> GetBugunTahsilatlar()
    {
        var tahsilatlar = await _dashboardService.GetBugunTahsilatlarAsync();
        return Ok(tahsilatlar);
    }


}