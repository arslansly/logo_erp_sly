using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

/// <summary>
/// Saha (satışçı) paneli uçları — açık siparişler, satışçı kırılımı, riskli müşteriler.
/// Tüm uçlar "view_saha_panel" yetkisi gerektirir (policy'ler Program.cs'de AppPermissions.All'dan kurulur).
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = AppPermissions.ViewSahaPanel)]
public class SahaController : ControllerBase
{
    private readonly SahaService _sahaService;

    public SahaController(SahaService sahaService)
    {
        _sahaService = sahaService;
    }

    // GET: api/saha/satiscilar  → satışçı kırılımı (leaderboard + seçici)
    [HttpGet("satiscilar")]
    public async Task<ActionResult<IEnumerable<SahaSatisci>>> GetSatiscilar()
    {
        var list = await _sahaService.GetSatiscilarAsync();
        return Ok(list);
    }

    // GET: api/saha/ozet?satisciRef=313  (satisciRef yok = tümü)
    [HttpGet("ozet")]
    public async Task<ActionResult<SahaOzet>> GetOzet([FromQuery] int? satisciRef = null)
    {
        var ozet = await _sahaService.GetOzetAsync(satisciRef);
        return Ok(ozet);
    }

    // GET: api/saha/acik-siparisler?satisciRef=313&limit=50
    [HttpGet("acik-siparisler")]
    public async Task<ActionResult<IEnumerable<SahaAcikSiparis>>> GetAcikSiparisler(
        [FromQuery] int? satisciRef = null,
        [FromQuery] int limit = 50)
    {
        var list = await _sahaService.GetAcikSiparislerAsync(satisciRef, limit);
        return Ok(list);
    }

    // GET: api/saha/riskli-cariler?satisciRef=313&limit=50
    [HttpGet("riskli-cariler")]
    public async Task<ActionResult<IEnumerable<SahaRiskliCari>>> GetRiskliCariler(
        [FromQuery] int? satisciRef = null,
        [FromQuery] int limit = 50)
    {
        var list = await _sahaService.GetRiskliCarilerAsync(satisciRef, limit);
        return Ok(list);
    }
}
