using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

/// <summary>
/// Bağlantı testi için hafif, kimlik doğrulaması gerektirmeyen uç nokta.
/// İstemci ayarlar ekranında "Bağlantıyı test et" için kullanır.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[AllowAnonymous]
public class HealthController : ControllerBase
{
    [HttpGet]
    public ActionResult Get() => Ok(new { status = "ok", time = DateTime.UtcNow });
}
