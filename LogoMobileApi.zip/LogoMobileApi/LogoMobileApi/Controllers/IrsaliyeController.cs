using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;

namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class IrsaliyeController : ControllerBase
{
    private readonly IrsaliyeService _service;

    public IrsaliyeController(IrsaliyeService service)
    {
        _service = service;
    }

    // GET: api/irsaliye?offset=0&limit=50&search=...&trCode=8&faturalandi=false
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Irsaliye>>> GetAll(
        [FromQuery] int offset = 0,
        [FromQuery] int limit = 50,
        [FromQuery] string? search = null,
        [FromQuery] DateTime? baslangic = null,
        [FromQuery] DateTime? bitis = null,
        [FromQuery] int? trCode = null,
        [FromQuery] bool? faturalandi = null,
        [FromQuery] int? cariId = null)
    {
        var list = await _service.GetAllAsync(
            offset, limit, search, baslangic, bitis, trCode, faturalandi, cariId);
        return Ok(list);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Irsaliye>> GetById(int id)
    {
        var i = await _service.GetByIdAsync(id);
        if (i == null) return NotFound();
        return Ok(i);
    }

    [HttpGet("{id}/satirlar")]
    public async Task<ActionResult<IEnumerable<IrsaliyeSatir>>> GetSatirlar(int id)
    {
        var lines = await _service.GetSatirlarAsync(id);
        return Ok(lines);
    }

    [HttpGet("{id}/detay")]
    public async Task<ActionResult<IrsaliyeDetay>> GetDetay(int id)
    {
        var detay = await _service.GetDetayAsync(id);
        if (detay == null) return NotFound();
        return Ok(detay);
    }
}
