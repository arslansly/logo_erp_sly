using System.Security.Claims;
using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

// Onay iş akışı — yalnızca "approve_belge" yetkisi olan (Patron/Muhasebe/Admin).
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = AppPermissions.ApproveBelge)]
public class OnayController : ControllerBase
{
    private readonly OnayService _service;

    public OnayController(OnayService service)
    {
        _service = service;
    }

    private string KullaniciAdi() =>
        User.Identity?.Name
        ?? User.FindFirstValue(ClaimTypes.Name)
        ?? "anonymous";

    // GET: api/onay/bekleyenler?tip=fatura|siparis|irsaliye
    [HttpGet("bekleyenler")]
    public async Task<IActionResult> GetBekleyenler([FromQuery] string? tip = null)
    {
        try
        {
            var liste = await _service.GetBekleyenlerAsync(tip);
            return Ok(liste);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // GET: api/onay/ozet
    [HttpGet("ozet")]
    public async Task<IActionResult> GetOzet()
    {
        try
        {
            var ozet = await _service.GetOzetAsync();
            return Ok(ozet);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // POST: api/onay/fatura/12/onayla
    [HttpPost("{tip}/{id:int}/onayla")]
    public async Task<IActionResult> Onayla(string tip, int id)
    {
        try
        {
            var ok = await _service.OnaylaAsync(tip, id, KullaniciAdi());
            if (!ok)
                return Conflict(new { mesaj = "Taslak onaylanamadı (bulunamadı ya da zaten işlenmiş)" });
            return Ok(new { mesaj = "Onaylandı" });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // POST: api/onay/fatura/12/reddet   body: { "reason": "..." }
    [HttpPost("{tip}/{id:int}/reddet")]
    public async Task<IActionResult> Reddet(string tip, int id, [FromBody] OnayKararRequest? req)
    {
        try
        {
            var ok = await _service.ReddetAsync(tip, id, KullaniciAdi(), req?.Reason);
            if (!ok)
                return Conflict(new { mesaj = "Taslak reddedilemedi (bulunamadı ya da zaten işlenmiş)" });
            return Ok(new { mesaj = "Reddedildi" });
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }
}
