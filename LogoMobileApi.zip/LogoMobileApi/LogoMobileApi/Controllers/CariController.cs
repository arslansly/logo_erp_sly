﻿using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class CariController : ControllerBase
{
    private readonly CariService _cariService;

    // .NET bize CariService'i otomatik geçirir (Dependency Injection)
    public CariController(CariService cariService)
    {
        _cariService = cariService;
    }

    // GET: api/cari?offset=0&limit=50&search=abc
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Cari>>> GetAll(
        [FromQuery] int offset = 0,
        [FromQuery] int limit = 50,
        [FromQuery] string? search = null)
    {
        var cariler = await _cariService.GetAllAsync(offset, limit, search);
        return Ok(cariler);
    }

    // GET: api/cari/3
    [HttpGet("{id}")]
    public async Task<ActionResult<Cari>> GetById(int id)
    {
        var cari = await _cariService.GetByIdAsync(id);
        if (cari == null) return NotFound();
        return Ok(cari);
    }

    // GET: api/cari/3/hareketler
    [HttpGet("{id}/hareketler")]
    public async Task<ActionResult<IEnumerable<CariHareket>>> GetHareketler(int id)
    {
        // Önce cari gerçekten var mı kontrol et
        var cari = await _cariService.GetByIdAsync(id);
        if (cari == null) return NotFound($"Cari bulunamadı: {id}");

        var hareketler = await _cariService.GetHareketlerAsync(id);
        return Ok(hareketler);
    }

    // GET: api/cari/3/vade-analizi
    [HttpGet("{id}/vade-analizi")]
    public async Task<ActionResult<CariVadeAnalizi>> GetVadeAnalizi(int id)
    {
        var cari = await _cariService.GetByIdAsync(id);
        if (cari == null) return NotFound($"Cari bulunamadı: {id}");

        var analiz = await _cariService.GetVadeAnaliziAsync(id);
        return Ok(analiz);
    }

    // GET: api/cari/3/ekstre?baslangic=2026-01-01&bitis=2026-05-25
    [HttpGet("{id}/ekstre")]
    public async Task<ActionResult<CariEkstre>> GetEkstre(
        int id,
        [FromQuery] DateTime? baslangic = null,
        [FromQuery] DateTime? bitis = null)
    {
        var cari = await _cariService.GetByIdAsync(id);
        if (cari == null) return NotFound($"Cari bulunamadı: {id}");

        var ekstre = await _cariService.GetEkstreAsync(id, baslangic, bitis);
        return Ok(ekstre);
    }

    // GET: api/cari/vade-ozeti  (dashboard için)
    [HttpGet("vade-ozeti")]
    public async Task<ActionResult<VadeOzeti>> GetVadeOzeti()
    {
        var ozet = await _cariService.GetVadeOzetiAsync();
        return Ok(ozet);
    }
}