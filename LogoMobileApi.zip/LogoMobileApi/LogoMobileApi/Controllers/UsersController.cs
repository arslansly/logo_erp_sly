using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

/// <summary>
/// Kullanıcı yönetimi — "manage_users" yetkisi olanlar (varsayılan Admin/Patron,
/// override ile değişebilir). AppUsers tablosu + ince yetki override'ları.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = AppPermissions.ManageUsers)]
public class UsersController : ControllerBase
{
    private readonly AuthService _authService;
    private readonly ILogger<UsersController> _logger;

    public UsersController(AuthService authService, ILogger<UsersController> logger)
    {
        _authService = authService;
        _logger = logger;
    }

    /// <summary>Tüm kullanıcıları listeler.</summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<UserListItem>>> GetAll()
    {
        var users = await _authService.ListUsersAsync();
        return Ok(users);
    }

    /// <summary>Yeni kullanıcı oluşturur.</summary>
    [HttpPost]
    public async Task<ActionResult> Create([FromBody] CreateUserRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var id = await _authService.CreateUserAsync(
                request.Username, request.Password, request.FullName,
                request.Email, request.Role);
            return Ok(new { id, message = "Kullanıcı oluşturuldu" });
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Kullanıcı oluşturulurken hata");
            return StatusCode(500, new { message = "Kullanıcı oluşturulamadı" });
        }
    }

    /// <summary>Kullanıcıyı günceller. Şifre boş bırakılırsa değişmez.</summary>
    [HttpPut("{id:int}")]
    public async Task<ActionResult> Update(int id, [FromBody] UpdateUserRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var ok = await _authService.UpdateUserAsync(id, request);
            if (!ok)
                return NotFound(new { message = "Kullanıcı bulunamadı" });

            return Ok(new { message = "Kullanıcı güncellendi" });
        }
        catch (InvalidOperationException ex)
        {
            // Son yönetici koruması vb. iş kuralı ihlali
            return Conflict(new { message = ex.Message });
        }
    }

    /// <summary>Kullanıcıyı siler. Kendi hesabını silemez.</summary>
    [HttpDelete("{id:int}")]
    public async Task<ActionResult> Delete(int id)
    {
        // Admin kendi hesabını silmesin (kilitlenmeyi önle)
        var currentId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value
            ?? User.FindFirst("sub")?.Value;
        if (currentId == id.ToString())
            return BadRequest(new { message = "Kendi hesabınızı silemezsiniz" });

        var ok = await _authService.DeleteUserAsync(id);
        if (!ok)
            return NotFound(new { message = "Kullanıcı bulunamadı" });

        return Ok(new { message = "Kullanıcı silindi" });
    }

    /// <summary>Kullanıcının yetki tablosu (rol varsayılanı + override + effective).</summary>
    [HttpGet("{id:int}/permissions")]
    public async Task<ActionResult<UserPermissionsResponse>> GetPermissions(int id)
    {
        var res = await _authService.GetUserPermissionsAsync(id);
        if (res == null)
            return NotFound(new { message = "Kullanıcı bulunamadı" });
        return Ok(res);
    }

    /// <summary>Kullanıcının yetki istisnalarını (override) topluca ayarlar.</summary>
    [HttpPut("{id:int}/permissions")]
    public async Task<ActionResult> SetPermissions(
        int id, [FromBody] SetUserPermissionsRequest request)
    {
        try
        {
            var ok = await _authService.SetUserPermissionsAsync(id, request);
            if (!ok)
                return NotFound(new { message = "Kullanıcı bulunamadı" });
            return Ok(new { message = "Yetkiler güncellendi" });
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
    }
}
