using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class FaturaController : ControllerBase
{
    private readonly FaturaService _faturaService;

    public FaturaController(FaturaService faturaService)
    {
        _faturaService = faturaService;
    }

    // GET: api/fatura?offset=0&limit=50&search=abc&baslangic=...&bitis=...&trCode=37&cariId=12
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Fatura>>> GetAll(
        [FromQuery] int offset = 0,
        [FromQuery] int limit = 50,
        [FromQuery] string? search = null,
        [FromQuery] DateTime? baslangic = null,
        [FromQuery] DateTime? bitis = null,
        [FromQuery] int? trCode = null,
        [FromQuery] int? cariId = null,
        [FromQuery] string? kategori = null)
    {
        var faturalar = await _faturaService.GetAllAsync(
            offset, limit, search, baslangic, bitis, trCode, cariId, kategori);
        return Ok(faturalar);
    }

    // GET: api/fatura/123  — header
    [HttpGet("{id}")]
    public async Task<ActionResult<Fatura>> GetById(int id)
    {
        var fatura = await _faturaService.GetByIdAsync(id);
        if (fatura == null) return NotFound();
        return Ok(fatura);
    }

    // GET: api/fatura/123/detay  — header + satırlar + bağlı belgeler
    [HttpGet("{id}/detay")]
    public async Task<ActionResult<FaturaDetay>> GetDetay(int id)
    {
        var detay = await _faturaService.GetDetayAsync(id);
        if (detay == null) return NotFound($"Fatura bulunamadı: {id}");
        return Ok(detay);
    }

    // GET: api/fatura/123/satirlar
    [HttpGet("{id}/satirlar")]
    public async Task<ActionResult<IEnumerable<FaturaSatir>>> GetSatirlar(int id)
    {
        var satirlar = await _faturaService.GetSatirlarAsync(id);
        return Ok(satirlar);
    }

    // GET: api/fatura/123/baglantili-irsaliyeler
    [HttpGet("{id}/baglantili-irsaliyeler")]
    public async Task<ActionResult<IEnumerable<BagliBelge>>> GetBaglantiliIrsaliyeler(int id)
    {
        var belgeler = await _faturaService.GetBaglantiliIrsaliyelerAsync(id);
        return Ok(belgeler);
    }

    // GET: api/fatura/123/baglantili-siparisler
    [HttpGet("{id}/baglantili-siparisler")]
    public async Task<ActionResult<IEnumerable<BagliBelge>>> GetBaglantiliSiparisler(int id)
    {
        var belgeler = await _faturaService.GetBaglantiliSiparislerAsync(id);
        return Ok(belgeler);
    }
}
