using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;

namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class SiparisDraftController : ControllerBase
{
    private readonly OrderDraftService _service;

    public SiparisDraftController(OrderDraftService service)
    {
        _service = service;
    }

    // GET: api/siparisdraft?status=Draft|Transferred|Failed&offset=0&limit=50&search=
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Siparis>>> GetAll(
        [FromQuery] string? status = null,
        [FromQuery] int offset = 0,
        [FromQuery] int limit = 50,
        [FromQuery] string? search = null)
    {
        var taslaklar = await _service.GetAllAsync(status, offset, limit, search);
        return Ok(taslaklar);
    }

    // GET: api/siparisdraft/12
    [HttpGet("{id}")]
    public async Task<ActionResult<OrderDraft>> GetById(int id)
    {
        var draft = await _service.GetByIdAsync(id);
        if (draft == null) return NotFound();
        return Ok(draft);
    }

    // POST: api/siparisdraft
    [HttpPost]
    public async Task<ActionResult<OrderDraft>> Create([FromBody] OrderDraft draft)
    {
        var userName = User.Identity?.Name
                       ?? User.FindFirstValue(ClaimTypes.Name)
                       ?? "anonymous";
        var newId = await _service.CreateAsync(draft, userName);
        var created = await _service.GetByIdAsync(newId);
        return CreatedAtAction(nameof(GetById), new { id = newId }, created);
    }

    // PUT: api/siparisdraft/12
    [HttpPut("{id}")]
    public async Task<ActionResult<OrderDraft>> Update(int id, [FromBody] OrderDraft draft)
    {
        try
        {
            var ok = await _service.UpdateAsync(id, draft);
            if (!ok) return NotFound();
            var updated = await _service.GetByIdAsync(id);
            return Ok(updated);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    // DELETE: api/siparisdraft/12
    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var ok = await _service.DeleteAsync(id);
        return ok ? NoContent() : NotFound();
    }

    // POST: api/siparisdraft/12/transfer
    [HttpPost("{id}/transfer")]
    public async Task<ActionResult> Transfer(int id)
    {
        var (ok, error, newOrderId) = await _service.TransferToLogoAsync(id);
        if (ok)
            return Ok(new { orderId = newOrderId, message = "Aktarım başarılı" });
        return StatusCode(StatusCodes.Status409Conflict, new { error });
    }

    // POST: api/siparisdraft/transfer-batch  body: [1, 2, 3]
    [HttpPost("transfer-batch")]
    public async Task<ActionResult<BatchTransferResult>> TransferBatch([FromBody] List<int> ids)
    {
        var result = await _service.TransferBatchAsync(ids);
        return Ok(result);
    }
}
