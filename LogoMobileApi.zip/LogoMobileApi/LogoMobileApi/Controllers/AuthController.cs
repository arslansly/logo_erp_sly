﻿using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AuthService _authService;
    private readonly ILogger<AuthController> _logger;

    public AuthController(AuthService authService, ILogger<AuthController> logger)
    {
        _authService = authService;
        _logger = logger;
    }

    /// <summary>
    /// Kullanıcı adı + şifre ile giriş yapar, JWT token döner
    /// </summary>
    [HttpPost("login")]
    public async Task<ActionResult<LoginResponse>> Login([FromBody] LoginRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        try
        {
            var response = await _authService.LoginAsync(
                request.Username, request.Password, request.FirmaNo, request.DonemNo);

            if (response == null)
            {
                _logger.LogWarning("Başarısız giriş denemesi: {Username}", request.Username);
                return Unauthorized(new { message = "Kullanıcı adı veya şifre hatalı" });
            }

            _logger.LogInformation("Başarılı giriş: {Username}", request.Username);
            return Ok(response);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Giriş sırasında hata");
            return StatusCode(500, new { message = "Sunucu hatası" });
        }
    }

    /// <summary>
    /// İLK KURULUM İÇİN: Admin kullanıcısı yaratır.
    /// Production'da bu endpoint kaldırılmalı veya korunmalı.
    /// </summary>
    [HttpPost("seed-admin")]
    public async Task<ActionResult> SeedAdmin([FromQuery] string masterKey)
    {
        // Basit koruma: master key bilenler kullanabilir
        if (masterKey != "LOGO-2026-SEED")
            return Unauthorized();

        try
        {
            var id = await _authService.CreateUserAsync(
                username: "admin",
                password: "admin123",
                fullName: "Sistem Yöneticisi",
                email: "admin@logomobile.com",
                role: "Admin");

            return Ok(new { message = "Admin yaratıldı", id, username = "admin", password = "admin123" });
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(new { message = ex.Message });
        }
    }
}