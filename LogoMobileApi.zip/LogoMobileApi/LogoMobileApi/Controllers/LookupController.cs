using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;

namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class LookupController : ControllerBase
{
    private readonly LookupService _service;

    public LookupController(LookupService service)
    {
        _service = service;
    }

    // GET: api/lookup/currencies
    [HttpGet("currencies")]
    public async Task<ActionResult<IEnumerable<Currency>>> GetCurrencies()
    {
        var currencies = await _service.GetCurrenciesAsync();
        return Ok(currencies);
    }

    // GET: api/lookup/salesmen
    [HttpGet("salesmen")]
    public async Task<ActionResult<IEnumerable<LookupItem>>> GetSalesmen() =>
        Ok(await _service.GetSalesmenAsync());

    // GET: api/lookup/payplans
    [HttpGet("payplans")]
    public async Task<ActionResult<IEnumerable<LookupItem>>> GetPayPlans() =>
        Ok(await _service.GetPayPlansAsync());

    // GET: api/lookup/warehouses
    [HttpGet("warehouses")]
    public async Task<ActionResult<IEnumerable<LookupItem>>> GetWarehouses() =>
        Ok(await _service.GetWarehousesAsync());

    // GET: api/lookup/carriers
    [HttpGet("carriers")]
    public async Task<ActionResult<IEnumerable<LookupItem>>> GetCarriers() =>
        Ok(await _service.GetCarriersAsync());

    // GET: api/lookup/exchange-rate?currencyType=1
    [HttpGet("exchange-rate")]
    public async Task<ActionResult<ExchangeRate>> GetExchangeRate(
        [FromQuery] int currencyType)
    {
        var rate = await _service.GetExchangeRateAsync(currencyType);
        if (rate == null)
        {
            // TL veya kur kaydı yok — mobil manuel girer
            return Ok(new ExchangeRate { CurType = currencyType, HasData = false });
        }
        return Ok(rate);
    }
}
