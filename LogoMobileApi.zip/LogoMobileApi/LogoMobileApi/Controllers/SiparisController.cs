using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using LogoMobileApi.Models;
using LogoMobileApi.Services;

namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class SiparisController : ControllerBase
{
    private readonly SiparisService _service;

    public SiparisController(SiparisService service)
    {
        _service = service;
    }

    // GET: api/siparis?offset=0&limit=50&search=abc&trCode=1&status=3&cariId=42
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Siparis>>> GetAll(
        [FromQuery] int offset = 0,
        [FromQuery] int limit = 50,
        [FromQuery] string? search = null,
        [FromQuery] DateTime? baslangic = null,
        [FromQuery] DateTime? bitis = null,
        [FromQuery] int? trCode = null,
        [FromQuery] int? status = null,
        [FromQuery] int? cariId = null)
    {
        var list = await _service.GetAllAsync(
            offset, limit, search, baslangic, bitis, trCode, status, cariId);
        return Ok(list);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Siparis>> GetById(int id)
    {
        var s = await _service.GetByIdAsync(id);
        if (s == null) return NotFound();
        return Ok(s);
    }

    [HttpGet("{id}/satirlar")]
    public async Task<ActionResult<IEnumerable<SiparisSatir>>> GetSatirlar(int id)
    {
        var lines = await _service.GetSatirlarAsync(id);
        return Ok(lines);
    }

    [HttpGet("{id}/detay")]
    public async Task<ActionResult<SiparisDetay>> GetDetay(int id)
    {
        var detay = await _service.GetDetayAsync(id);
        if (detay == null) return NotFound();
        return Ok(detay);
    }
}
