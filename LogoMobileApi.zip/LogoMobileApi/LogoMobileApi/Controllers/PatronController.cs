using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

/// <summary>
/// Patron paneli uçları — net alacak/borç, yaşlandırma, nakit/banka, çek-senet.
/// Tüm uçlar "view_patron_panel" yetkisi gerektirir (Program.cs policy'leri AppPermissions.All'dan kurulur).
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = AppPermissions.ViewPatronPanel)]
public class PatronController : ControllerBase
{
    private readonly PatronService _patronService;

    public PatronController(PatronService patronService)
    {
        _patronService = patronService;
    }

    // GET: api/patron/ozet
    [HttpGet("ozet")]
    public async Task<ActionResult<PatronOzet>> GetOzet()
    {
        var ozet = await _patronService.GetOzetAsync();
        return Ok(ozet);
    }

    // GET: api/patron/bankalar  (drill-down 1. seviye: bankalar + toplam bakiye)
    [HttpGet("bankalar")]
    public async Task<ActionResult<IEnumerable<BankaKayit>>> GetBankalar()
    {
        var bankalar = await _patronService.GetBankalarAsync();
        return Ok(bankalar);
    }

    // GET: api/patron/banka-hesaplar?bankaRef=5  (drill-down 2. seviye: bankanın hesapları)
    [HttpGet("banka-hesaplar")]
    public async Task<ActionResult<IEnumerable<BankaHesap>>> GetBankaHesaplar([FromQuery] int bankaRef)
    {
        var hesaplar = await _patronService.GetBankaHesaplarAsync(bankaRef);
        return Ok(hesaplar);
    }

    // GET: api/patron/cekler?tip=tahsil|odeme
    [HttpGet("cekler")]
    public async Task<ActionResult<IEnumerable<CekKayit>>> GetCekler([FromQuery] string tip = "tahsil")
    {
        var cekler = await _patronService.GetCeklerAsync(tip);
        return Ok(cekler);
    }
}
