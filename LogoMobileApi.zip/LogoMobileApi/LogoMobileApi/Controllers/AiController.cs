using LogoMobileApi.Models;
using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class AiController : ControllerBase
{
    private readonly AiService _aiService;

    public AiController(AiService aiService)
    {
        _aiService = aiService;
    }

    // POST: api/ai/chat
    // Kullanıcının doğal dil mesajını alır; metin cevabı + (varsa) form aksiyonu döner.
    [HttpPost("chat")]
    public async Task<ActionResult<AiChatResponse>> Chat([FromBody] AiChatRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Message))
            return BadRequest("Mesaj boş olamaz.");

        var cevap = await _aiService.ChatAsync(request);
        return Ok(cevap);
    }
}
