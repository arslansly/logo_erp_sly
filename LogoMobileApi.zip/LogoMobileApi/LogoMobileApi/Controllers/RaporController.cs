using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogoMobileApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class RaporController : ControllerBase
{
    private readonly RaporService _raporService;

    public RaporController(RaporService raporService)
    {
        _raporService = raporService;
    }

    // GET: api/rapor/cari-bakiye?search=&tur=&bakiyeDurumu=borclu
    // Finansal rapor — "view_financial_reports" yetkisi gerektirir.
    [HttpGet("cari-bakiye")]
    [Authorize(Policy = AppPermissions.ViewFinancialReports)]
    public async Task<IActionResult> GetCariBakiye(
        [FromQuery] string? search = null,
        [FromQuery] int? tur = null,
        [FromQuery] string? bakiyeDurumu = null)
    {
        try
        {
            var rapor = await _raporService.GetCariBakiyeAsync(search, tur, bakiyeDurumu);
            return Ok(rapor);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // GET: api/rapor/vade?minGun=30
    // Finansal rapor — "view_financial_reports" yetkisi gerektirir.
    [HttpGet("vade")]
    [Authorize(Policy = AppPermissions.ViewFinancialReports)]
    public async Task<IActionResult> GetVade([FromQuery] int? minGun = null)
    {
        try
        {
            var rapor = await _raporService.GetVadeAsync(minGun);
            return Ok(rapor);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // GET: api/rapor/stok?search=&tur=&stokDurumu=var
    [HttpGet("stok")]
    public async Task<IActionResult> GetStok(
        [FromQuery] string? search = null,
        [FromQuery] int? tur = null,
        [FromQuery] string? stokDurumu = null)
    {
        try
        {
            var rapor = await _raporService.GetStokAsync(search, tur, stokDurumu);
            return Ok(rapor);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // GET: api/rapor/stok-ambar?search=&tur=
    [HttpGet("stok-ambar")]
    public async Task<IActionResult> GetStokAmbar(
        [FromQuery] string? search = null,
        [FromQuery] int? tur = null)
    {
        try
        {
            var rapor = await _raporService.GetStokAmbarAsync(search, tur);
            return Ok(rapor);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // GET: api/rapor/kritik-stok?search=&tur=
    [HttpGet("kritik-stok")]
    public async Task<IActionResult> GetKritikStok(
        [FromQuery] string? search = null,
        [FromQuery] int? tur = null)
    {
        try
        {
            var rapor = await _raporService.GetKritikStokAsync(search, tur);
            return Ok(rapor);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }

    // GET: api/rapor/satis-performans?baslangic=&bitis=&satisciRef=
    // Satış performans / ciro raporu — finansal rapor, "view_financial_reports" gerektirir.
    [HttpGet("satis-performans")]
    [Authorize(Policy = AppPermissions.ViewFinancialReports)]
    public async Task<IActionResult> GetSatisPerformans(
        [FromQuery] DateTime? baslangic = null,
        [FromQuery] DateTime? bitis = null,
        [FromQuery] int? satisciRef = null)
    {
        try
        {
            var rapor = await _raporService.GetSatisPerformansAsync(baslangic, bitis, satisciRef);
            return Ok(rapor);
        }
        catch (Exception ex)
        {
            return BadRequest(new { mesaj = ex.Message });
        }
    }
}
