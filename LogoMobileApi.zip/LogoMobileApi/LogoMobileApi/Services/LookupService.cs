using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// Form dropdown'ları için lookup verileri (döviz tipleri, kur, satış elemanı vb).
public class LookupService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;

    public LookupService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
    }

    // Tüm tanımlı dövizler (firma bazlı)
    public async Task<IEnumerable<Currency>> GetCurrenciesAsync()
    {
        var sql = @"
            SELECT CURTYPE AS CurType, CURCODE AS CurCode, CURNAME AS CurName
            FROM L_CURRENCYLIST WITH(NOLOCK)
            WHERE FIRMNR = @Firma
            ORDER BY CURTYPE";
        try
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryAsync<Currency>(sql, new { Firma = int.Parse(_firmaNo) });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[LookupService.GetCurrenciesAsync] HATA: {ex.Message}");
            throw new Exception("Döviz listesi alınamadı");
        }
    }

    // Satış elemanları (LG_SLSMAN - firma bağımsız)
    public async Task<IEnumerable<LookupItem>> GetSalesmenAsync()
    {
        var sql = @"
            SELECT LOGICALREF AS Id, CODE AS Code, DEFINITION_ AS Name
            FROM LG_SLSMAN WITH(NOLOCK)
            WHERE FIRMNR = @Firma AND ACTIVE = 0
            ORDER BY CODE";
        using var c = new SqlConnection(_connectionString);
        return await c.QueryAsync<LookupItem>(sql, new { Firma = int.Parse(_firmaNo) });
    }

    // Ambarlar (L_CAPIWHOUSE - firma bazlı). Id = ambar numarası (NR);
    // STFICHE.SOURCEINDEX/DESTINDEX bu NR ile eşleşir.
    public async Task<IEnumerable<LookupItem>> GetWarehousesAsync()
    {
        var sql = @"
            SELECT WH.NR AS Id, CAST(WH.NR AS NVARCHAR(16)) AS Code, WH.NAME AS Name
            FROM L_CAPIWHOUSE WH WITH(NOLOCK)
            WHERE WH.FIRMNR = @Firma
            ORDER BY WH.NR";
        using var c = new SqlConnection(_connectionString);
        return await c.QueryAsync<LookupItem>(sql, new { Firma = int.Parse(_firmaNo) });
    }

    // Taşıyıcılar (L_SHPAGENT - firma bağımsız). Id=LOGICALREF, Code=CODE, Name=TITLE.
    // İrsaliye taslağında ShipInfoCode için CODE kullanılır.
    public async Task<IEnumerable<LookupItem>> GetCarriersAsync()
    {
        var sql = @"
            SELECT LOGICALREF AS Id, CODE AS Code, ISNULL(TITLE, '') AS Name
            FROM L_SHPAGENT WITH(NOLOCK)
            ORDER BY CODE";
        using var c = new SqlConnection(_connectionString);
        return await c.QueryAsync<LookupItem>(sql);
    }

    // Ödeme planları
    public async Task<IEnumerable<LookupItem>> GetPayPlansAsync()
    {
        var sql = $@"
            SELECT LOGICALREF AS Id, CODE AS Code, DEFINITION_ AS Name
            FROM LG_{_firmaNo}_PAYPLANS WITH(NOLOCK)
            WHERE ACTIVE = 0
            ORDER BY CODE";
        using var c = new SqlConnection(_connectionString);
        return await c.QueryAsync<LookupItem>(sql);
    }

    // Verilen döviz için en güncel kuru getir (APPROVE şartı esnek — varsa APPROVE=1 tercih,
    // yoksa en son kayıt). DATE_ kolonu LOGO native int olduğu için DATE_ DESC ile sıralanır.
    public async Task<ExchangeRate?> GetExchangeRateAsync(int currencyType)
    {
        if (currencyType <= 0) return null;

        var sql = @"
            SELECT TOP 1
                de.CRTYPE                                 AS CurType,
                ISNULL(cl.CURCODE, '')                    AS CurCode,
                ISNULL(de.RATES1, 0)                      AS Rates1,
                ISNULL(de.RATES2, 0)                      AS Rates2,
                ISNULL(de.RATES3, 0)                      AS Rates3,
                ISNULL(de.RATES4, 0)                      AS Rates4
            FROM L_DAILYEXCHANGES de WITH(NOLOCK)
            LEFT JOIN L_CURRENCYLIST cl WITH(NOLOCK)
                ON cl.CURTYPE = de.CRTYPE AND cl.FIRMNR = @Firma
            WHERE de.CRTYPE = @CurType
            ORDER BY de.DATE_ DESC, de.LREF DESC";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var rate = await connection.QueryFirstOrDefaultAsync<ExchangeRate>(
                sql, new { CurType = currencyType, Firma = int.Parse(_firmaNo) });
            if (rate != null) rate.HasData = true;
            return rate;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[LookupService.GetExchangeRateAsync] HATA: {ex.Message}");
            throw new Exception("Kur bilgisi alınamadı");
        }
    }
}
