using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

/// <summary>
/// Saha (satışçı) paneli verileri — açık (sevk bekleyen) siparişler, satışçı kırılımı,
/// riskli müşteriler. Tüm sorgular firma 126 / dönem 01 üzerinde canlı doğrulandı.
///
/// Tasarım notları (bu kurulumda doğrulanan gerçekler):
///   - Satışçı–müşteri ilişkisi belgelerin SALESMANREF alanından gelir (LG_SLSCLREL boş).
///   - Kredi limiti kullanılmıyor (CLCARD.DBSLIMIT* hepsi 0) → limit ekseni yok; risk = bakiye + açık iş + vade.
///   - Açık sipariş = satış siparişi (TRCODE=1), onaylı (STATUS IN (3,4)), sevki bekleyen (ORFLINE.CLOSED=0) satırların LINENET toplamı.
///     SHIPPEDAMOUNT güvenilmez olduğundan kapanış (CLOSED) esas alınır (bkz. ORFICHE sevk durumu kuralı).
/// </summary>
public class SahaService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public SahaService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // Açık (sevk bekleyen) satış siparişlerini fiş düzeyinde toplayan ortak CTE.
    private string OrdCte() => $@"
        WITH ord AS (
            SELECT o.LOGICALREF, o.FICHENO, o.DATE_, o.CLIENTREF, o.SALESMANREF,
                   SUM(CASE WHEN l.CLOSED = 0 THEN l.LINENET ELSE 0 END) AS Bekleyen
            FROM LG_{_firmaNo}_{_donemNo}_ORFICHE o WITH(NOLOCK)
            JOIN LG_{_firmaNo}_{_donemNo}_ORFLINE l WITH(NOLOCK)
                ON l.ORDFICHEREF = o.LOGICALREF AND l.LINETYPE = 0
            WHERE o.CANCELLED = 0 AND o.TRCODE = 1 AND o.STATUS IN (3, 4)
            GROUP BY o.LOGICALREF, o.FICHENO, o.DATE_, o.CLIENTREF, o.SALESMANREF
            HAVING SUM(CASE WHEN l.CLOSED = 0 THEN l.LINENET ELSE 0 END) > 0
        )";

    // ── Satışçı kırılımı (leaderboard + seçici kaynağı) ──
    // Sadece açık satış siparişi olan satışçılar döner; açık iş tutarına göre azalan.
    public async Task<IEnumerable<SahaSatisci>> GetSatiscilarAsync()
    {
        var sql = $@"
            {OrdCte()}
            SELECT s.LOGICALREF                AS Id,
                   s.CODE                      AS Kod,
                   s.DEFINITION_               AS Ad,
                   COUNT(*)                    AS AcikSiparisAdet,
                   SUM(ord.Bekleyen)           AS AcikSiparisTutar,
                   COUNT(DISTINCT ord.CLIENTREF) AS MusteriSayisi
            FROM ord
            JOIN LG_SLSMAN s WITH(NOLOCK)
                ON s.LOGICALREF = ord.SALESMANREF AND s.FIRMNR = {_firmaNo}
            GROUP BY s.LOGICALREF, s.CODE, s.DEFINITION_
            ORDER BY AcikSiparisTutar DESC;";
        using var connection = new SqlConnection(_connectionString);
        return (await connection.QueryAsync<SahaSatisci>(sql)).ToList();
    }

    // ── Seçili kapsam özeti (satışçı ya da "tümü") ──
    public async Task<SahaOzet> GetOzetAsync(int? satisciRef)
    {
        var ozet = new SahaOzet { SatisciRef = satisciRef };
        using var connection = new SqlConnection(_connectionString);

        // Satışçı adı (ref verilmişse)
        if (satisciRef.HasValue)
        {
            try
            {
                var ad = await connection.QueryFirstOrDefaultAsync<string>(
                    $"SELECT DEFINITION_ FROM LG_SLSMAN WITH(NOLOCK) WHERE LOGICALREF = @Ref AND FIRMNR = {_firmaNo}",
                    new { Ref = satisciRef.Value });
                if (!string.IsNullOrWhiteSpace(ad)) ozet.SatisciAd = ad;
            }
            catch (Exception ex) { Console.WriteLine($"❌ Saha.Ozet.Ad: {ex.Message}"); }
        }

        // 1) Açık sipariş (sevk bekleyen) — tutar / adet / müşteri
        try
        {
            var sql = $@"
                {OrdCte()}
                SELECT ISNULL(SUM(Bekleyen), 0)        AS AcikSiparisTutar,
                       COUNT(*)                        AS AcikSiparisAdet,
                       COUNT(DISTINCT CLIENTREF)       AS MusteriSayisi
                FROM ord
                WHERE (@Ref IS NULL OR SALESMANREF = @Ref);";
            var row = await connection.QueryFirstAsync(sql, new { Ref = satisciRef });
            ozet.AcikSiparisTutar = (decimal)row.AcikSiparisTutar;
            ozet.AcikSiparisAdet = (int)row.AcikSiparisAdet;
            ozet.MusteriSayisi = (int)row.MusteriSayisi;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Saha.Ozet.AcikSiparis: {ex.Message}"); }

        // 2) Risk — vadesi geçen alacağı olan müşteri sayısı + toplam (kapsama göre)
        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                SELECT COUNT(DISTINCT pt.CARDREF)            AS RiskliCariSayisi,
                       ISNULL(SUM(pt.TOTAL - pt.PAID), 0)    AS VadesiGecenToplam
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                WHERE pt.CANCELLED = 0 AND pt.SIGN = 0 AND pt.TOTAL > pt.PAID AND pt.DATE_ < @bugun
                  AND (@Ref IS NULL OR pt.CARDREF IN (
                        SELECT CLIENTREF FROM LG_{_firmaNo}_{_donemNo}_ORFICHE WITH(NOLOCK)
                          WHERE SALESMANREF = @Ref AND CANCELLED = 0 AND TRCODE = 1
                        UNION
                        SELECT CLIENTREF FROM LG_{_firmaNo}_{_donemNo}_INVOICE WITH(NOLOCK)
                          WHERE SALESMANREF = @Ref AND CANCELLED = 0
                  ));";
            var row = await connection.QueryFirstAsync(sql, new { Ref = satisciRef });
            ozet.RiskliCariSayisi = (int)row.RiskliCariSayisi;
            ozet.VadesiGecenToplam = (decimal)row.VadesiGecenToplam;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Saha.Ozet.Risk: {ex.Message}"); }

        // 3) Kredi limitini aşan müşteri sayısı (kapsamda). Limit kullanmayan firmalarda 0.
        //    Verimli: önce DBSLIMIT>0 (limitli) cariler süzülür, risk subquery'leri yalnızca onlar için çalışır.
        try
        {
            var sql = $@"
                SELECT COUNT(*) FROM (
                    SELECT c.LOGICALREF AS Ref,
                        (SELECT MAX(v) FROM (VALUES
                            (c.DBSLIMIT1),(c.DBSLIMIT2),(c.DBSLIMIT3),(c.DBSLIMIT4),
                            (c.DBSLIMIT5),(c.DBSLIMIT6),(c.DBSLIMIT7)) t(v)) AS Lim
                    FROM LG_{_firmaNo}_CLCARD c WITH(NOLOCK)
                    WHERE c.ACTIVE = 0 AND c.LOGICALREF <> 1
                      AND (@Ref IS NULL OR c.LOGICALREF IN (
                            SELECT CLIENTREF FROM LG_{_firmaNo}_{_donemNo}_ORFICHE WITH(NOLOCK)
                              WHERE SALESMANREF = @Ref AND CANCELLED = 0 AND TRCODE = 1
                            UNION
                            SELECT CLIENTREF FROM LG_{_firmaNo}_{_donemNo}_INVOICE WITH(NOLOCK)
                              WHERE SALESMANREF = @Ref AND CANCELLED = 0
                      ))
                ) lc
                WHERE lc.Lim > 0
                  AND (
                    (CASE WHEN ISNULL((SELECT SUM(gt.DEBIT - gt.CREDIT) FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL gt WITH(NOLOCK)
                                       WHERE gt.CARDREF = lc.Ref AND gt.TOTTYP = 1), 0) > 0
                          THEN ISNULL((SELECT SUM(gt.DEBIT - gt.CREDIT) FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL gt WITH(NOLOCK)
                                       WHERE gt.CARDREF = lc.Ref AND gt.TOTTYP = 1), 0)
                          ELSE 0 END)
                    + ISNULL((SELECT SUM(CASE WHEN l.CLOSED = 0 THEN l.LINENET ELSE 0 END)
                              FROM LG_{_firmaNo}_{_donemNo}_ORFICHE o WITH(NOLOCK)
                              JOIN LG_{_firmaNo}_{_donemNo}_ORFLINE l WITH(NOLOCK)
                                  ON l.ORDFICHEREF = o.LOGICALREF AND l.LINETYPE = 0
                              WHERE o.CLIENTREF = lc.Ref AND o.CANCELLED = 0 AND o.TRCODE = 1 AND o.STATUS IN (3,4)), 0)
                  ) > lc.Lim;";
            ozet.LimitAsanSayisi = await connection.ExecuteScalarAsync<int>(sql, new { Ref = satisciRef });
        }
        catch (Exception ex) { Console.WriteLine($"❌ Saha.Ozet.LimitAsan: {ex.Message}"); }

        return ozet;
    }

    // ── Açık (sevk bekleyen) siparişler listesi ──
    public async Task<IEnumerable<SahaAcikSiparis>> GetAcikSiparislerAsync(int? satisciRef, int limit = 50)
    {
        var sql = $@"
            {OrdCte()}
            SELECT TOP (@Limit)
                ord.LOGICALREF                                  AS Id,
                ord.FICHENO                                     AS FicheNo,
                ord.DATE_                                       AS Tarih,
                ord.CLIENTREF                                   AS CariId,
                c.DEFINITION_                                   AS CariAd,
                ISNULL(s.DEFINITION_, '')                       AS SatisciAd,
                ord.Bekleyen                                    AS BekleyenTutar,
                DATEDIFF(DAY, ord.DATE_, CAST(GETDATE() AS DATE)) AS GunGecti
            FROM ord
            JOIN LG_{_firmaNo}_CLCARD c WITH(NOLOCK) ON c.LOGICALREF = ord.CLIENTREF
            LEFT JOIN LG_SLSMAN s WITH(NOLOCK) ON s.LOGICALREF = ord.SALESMANREF AND s.FIRMNR = {_firmaNo}
            WHERE (@Ref IS NULL OR ord.SALESMANREF = @Ref)
            ORDER BY ord.DATE_ DESC;";
        using var connection = new SqlConnection(_connectionString);
        return (await connection.QueryAsync<SahaAcikSiparis>(sql, new { Ref = satisciRef, Limit = limit })).ToList();
    }

    // ── Riskli müşteriler — vadesi geçen alacağı olanlar (kapsama göre) ──
    public async Task<IEnumerable<SahaRiskliCari>> GetRiskliCarilerAsync(int? satisciRef, int limit = 50)
    {
        var sql = $@"
            DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
            WITH overdue AS (
                SELECT pt.CARDREF,
                       SUM(pt.TOTAL - pt.PAID)                  AS VadesiGecen,
                       MAX(DATEDIFF(DAY, pt.DATE_, @bugun))     AS EnEskiGun
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                WHERE pt.CANCELLED = 0 AND pt.SIGN = 0 AND pt.TOTAL > pt.PAID AND pt.DATE_ < @bugun
                GROUP BY pt.CARDREF
            ),
            acik AS (
                SELECT o.CLIENTREF,
                       SUM(CASE WHEN l.CLOSED = 0 THEN l.LINENET ELSE 0 END) AS AcikSiparis
                FROM LG_{_firmaNo}_{_donemNo}_ORFICHE o WITH(NOLOCK)
                JOIN LG_{_firmaNo}_{_donemNo}_ORFLINE l WITH(NOLOCK)
                    ON l.ORDFICHEREF = o.LOGICALREF AND l.LINETYPE = 0
                WHERE o.CANCELLED = 0 AND o.TRCODE = 1 AND o.STATUS IN (3, 4)
                GROUP BY o.CLIENTREF
            ),
            scope AS (
                SELECT CLIENTREF FROM LG_{_firmaNo}_{_donemNo}_ORFICHE WITH(NOLOCK)
                    WHERE SALESMANREF = @Ref AND CANCELLED = 0 AND TRCODE = 1
                UNION
                SELECT CLIENTREF FROM LG_{_firmaNo}_{_donemNo}_INVOICE WITH(NOLOCK)
                    WHERE SALESMANREF = @Ref AND CANCELLED = 0
            )
            SELECT TOP (@Limit)
                c.LOGICALREF   AS CariId,
                c.CODE         AS CariKod,
                c.DEFINITION_  AS CariAd,
                ISNULL((
                    SELECT SUM(gt.DEBIT - gt.CREDIT)
                    FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL gt WITH(NOLOCK)
                    WHERE gt.CARDREF = c.LOGICALREF AND gt.TOTTYP = 1
                ), 0)          AS Bakiye,
                o.VadesiGecen,
                o.EnEskiGun,
                ISNULL(a.AcikSiparis, 0) AS AcikSiparis,
                CAST((SELECT MAX(v) FROM (VALUES
                    (c.DBSLIMIT1),(c.DBSLIMIT2),(c.DBSLIMIT3),(c.DBSLIMIT4),
                    (c.DBSLIMIT5),(c.DBSLIMIT6),(c.DBSLIMIT7)) t(v)) AS decimal(18,2)) AS KrediLimiti
            FROM overdue o
            JOIN LG_{_firmaNo}_CLCARD c WITH(NOLOCK) ON c.LOGICALREF = o.CARDREF AND c.LOGICALREF <> 1
            LEFT JOIN acik a ON a.CLIENTREF = o.CARDREF
            WHERE (@Ref IS NULL OR o.CARDREF IN (SELECT CLIENTREF FROM scope))
            ORDER BY o.VadesiGecen DESC;";
        using var connection = new SqlConnection(_connectionString);
        return (await connection.QueryAsync<SahaRiskliCari>(sql, new { Ref = satisciRef, Limit = limit })).ToList();
    }
}
