using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

/// <summary>
/// Patron paneli verileri — net alacak/borç, yaşlandırma, nakit/banka, çek-senet, trend.
/// Tüm sorgular firma 126 / dönem 01 üzerinde canlı doğrulandı (bkz. PatronOzet özeti).
/// </summary>
public class PatronService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    // Çek/senet "bekleyen" durumu: terminal durumlar dışlanır.
    // Bu kurulumda doğrulanan CURRSTAT eşlemesi:
    //   2 = Cirolandı, 6 = Karşılıksız, 8 = Tahsil edildi/Ödendi  → terminal (dışla)
    //   1 = Portföyde, 4 = Bankada (tahsilde), 9 = Tedavülde       → bekleyen
    private const string CekBekleyenStat = "CURRSTAT NOT IN (2, 6, 8)";

    public PatronService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // ── Patron paneli özeti (tek çağrı) ──
    public async Task<PatronOzet> GetOzetAsync()
    {
        var ozet = new PatronOzet();
        using var connection = new SqlConnection(_connectionString);

        // 1) Net alacak / borç — GNTOTCL per-cari bakiye, pozitif=alacak / negatif=borç
        try
        {
            var sql = $@"
                WITH cari AS (
                    SELECT CARDREF, SUM(DEBIT - CREDIT) AS Bakiye
                    FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL WITH(NOLOCK)
                    WHERE TOTTYP = 1
                    GROUP BY CARDREF
                )
                SELECT
                    ISNULL(SUM(CASE WHEN Bakiye > 0 THEN Bakiye ELSE 0 END), 0)  AS ToplamAlacak,
                    ISNULL(SUM(CASE WHEN Bakiye < 0 THEN -Bakiye ELSE 0 END), 0) AS ToplamBorc,
                    ISNULL(SUM(Bakiye), 0)                                       AS NetBakiye,
                    SUM(CASE WHEN Bakiye > 0 THEN 1 ELSE 0 END)                  AS AlacakliCariSayisi,
                    SUM(CASE WHEN Bakiye < 0 THEN 1 ELSE 0 END)                  AS BorcluCariSayisi
                FROM cari;";
            var row = await connection.QueryFirstAsync(sql);
            ozet.ToplamAlacak = (decimal)row.ToplamAlacak;
            ozet.ToplamBorc = (decimal)row.ToplamBorc;
            ozet.NetBakiye = (decimal)row.NetBakiye;
            ozet.AlacakliCariSayisi = (int)row.AlacakliCariSayisi;
            ozet.BorcluCariSayisi = (int)row.BorcluCariSayisi;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Patron.NetAlacakBorc: {ex.Message}"); }

        // 2) Yaşlandırma — vadesi geçen alacak taksitleri (PAYTRANS), gün kovaları
        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                SELECT
                    ISNULL(SUM(CASE WHEN d BETWEEN 1 AND 30  THEN tutar ELSE 0 END), 0) AS K0_30,
                    ISNULL(SUM(CASE WHEN d BETWEEN 31 AND 60 THEN tutar ELSE 0 END), 0) AS K31_60,
                    ISNULL(SUM(CASE WHEN d BETWEEN 61 AND 90 THEN tutar ELSE 0 END), 0) AS K61_90,
                    ISNULL(SUM(CASE WHEN d > 90 THEN tutar ELSE 0 END), 0)              AS K90Plus,
                    ISNULL(SUM(tutar), 0)                                               AS Toplam
                FROM (
                    SELECT (pt.TOTAL - pt.PAID) AS tutar,
                           DATEDIFF(DAY, pt.DATE_, @bugun) AS d
                    FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                    WHERE pt.CANCELLED = 0 AND pt.SIGN = 0 AND pt.TOTAL > pt.PAID
                      AND pt.DATE_ < @bugun
                ) x;";
            var row = await connection.QueryFirstAsync(sql);
            ozet.Yaslandirma0_30 = (decimal)row.K0_30;
            ozet.Yaslandirma31_60 = (decimal)row.K31_60;
            ozet.Yaslandirma61_90 = (decimal)row.K61_90;
            ozet.Yaslandirma90Plus = (decimal)row.K90Plus;
            ozet.ToplamVadesiGecen = (decimal)row.Toplam;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Patron.Yaslandirma: {ex.Message}"); }

        // 3) Banka — gerçek bakiye BNFLINE'dan (GNTOTBN yanlış sonuç veriyordu).
        //    Hesap bakiyesi = SUM(SIGN=0 ? +AMOUNT : -AMOUNT); banka = hesaplarının toplamı.
        //    Sayım = aktif hesabı olan banka (BNCARD) sayısı.
        try
        {
            var sql = $@"
                SELECT
                    ISNULL((
                        SELECT SUM(CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE -f.AMOUNT END)
                        FROM LG_{_firmaNo}_{_donemNo}_BNFLINE f WITH(NOLOCK)
                        JOIN LG_{_firmaNo}_BANKACC a WITH(NOLOCK) ON a.LOGICALREF = f.BNACCREF AND a.ACTIVE = 0
                        WHERE f.CANCELLED = 0
                    ), 0) AS Bakiye,
                    (
                        SELECT COUNT(*) FROM LG_{_firmaNo}_BNCARD b WITH(NOLOCK)
                        WHERE b.ACTIVE = 0
                          AND EXISTS (SELECT 1 FROM LG_{_firmaNo}_BANKACC a WITH(NOLOCK)
                                      WHERE a.BANKREF = b.LOGICALREF AND a.ACTIVE = 0)
                    ) AS HesapSayisi;";
            var row = await connection.QueryFirstAsync(sql);
            ozet.BankaBakiye = (decimal)row.Bakiye;
            ozet.BankaHesapSayisi = (int)row.HesapSayisi;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Patron.Banka: {ex.Message}"); }

        // 4) Kasa — GNTOTCSH ⋈ KSCARD (NOT: kolon adı TOTTYPE, ACTIVE=0 aktif)
        try
        {
            var sql = $@"
                SELECT
                    ISNULL(SUM(g.DEBIT - g.CREDIT), 0) AS Bakiye,
                    COUNT(DISTINCT g.CARDREF)          AS HesapSayisi
                FROM LG_{_firmaNo}_{_donemNo}_GNTOTCSH g WITH(NOLOCK)
                JOIN LG_{_firmaNo}_KSCARD k ON k.LOGICALREF = g.CARDREF AND k.ACTIVE = 0
                WHERE g.TOTTYPE = -1;";
            var row = await connection.QueryFirstAsync(sql);
            ozet.KasaBakiye = (decimal)row.Bakiye;
            ozet.KasaHesapSayisi = (int)row.HesapSayisi;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Patron.Kasa: {ex.Message}"); }

        ozet.NakitToplam = ozet.KasaBakiye + ozet.BankaBakiye;

        // 5) Çek / senet — bekleyen tahsil/ödeme + karşılıksız + tahsil vade kovaları
        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                SELECT
                    ISNULL(SUM(CASE WHEN DOC IN (1,2) AND {CekBekleyenStat} THEN AMOUNT ELSE 0 END), 0) AS TahsilTutar,
                    SUM(CASE WHEN DOC IN (1,2) AND {CekBekleyenStat} THEN 1 ELSE 0 END) AS TahsilAdet,
                    ISNULL(SUM(CASE WHEN DOC IN (3,4) AND {CekBekleyenStat} THEN AMOUNT ELSE 0 END), 0) AS OdemeTutar,
                    SUM(CASE WHEN DOC IN (3,4) AND {CekBekleyenStat} THEN 1 ELSE 0 END) AS OdemeAdet,
                    ISNULL(SUM(CASE WHEN DOC IN (1,2) AND CURRSTAT = 6 THEN AMOUNT ELSE 0 END), 0) AS KarsiliksizTutar,
                    SUM(CASE WHEN DOC IN (1,2) AND CURRSTAT = 6 THEN 1 ELSE 0 END) AS KarsiliksizAdet,
                    ISNULL(SUM(CASE WHEN DOC IN (1,2) AND {CekBekleyenStat} AND DUEDATE <  @bugun THEN AMOUNT ELSE 0 END), 0) AS VadGecmis,
                    ISNULL(SUM(CASE WHEN DOC IN (1,2) AND {CekBekleyenStat} AND DUEDATE >= @bugun AND DUEDATE < DATEADD(DAY,8,@bugun)  THEN AMOUNT ELSE 0 END), 0) AS BuHafta,
                    ISNULL(SUM(CASE WHEN DOC IN (1,2) AND {CekBekleyenStat} AND DUEDATE >= DATEADD(DAY,8,@bugun) AND DUEDATE < DATEADD(DAY,31,@bugun) THEN AMOUNT ELSE 0 END), 0) AS BuAy,
                    ISNULL(SUM(CASE WHEN DOC IN (1,2) AND {CekBekleyenStat} AND DUEDATE >= DATEADD(DAY,31,@bugun) THEN AMOUNT ELSE 0 END), 0) AS Sonra
                FROM LG_{_firmaNo}_{_donemNo}_CSCARD WITH(NOLOCK)
                WHERE CANCELLED = 0;";
            var row = await connection.QueryFirstAsync(sql);
            ozet.CekTahsilTutar = (decimal)row.TahsilTutar;
            ozet.CekTahsilAdet = (int)row.TahsilAdet;
            ozet.CekOdemeTutar = (decimal)row.OdemeTutar;
            ozet.CekOdemeAdet = (int)row.OdemeAdet;
            ozet.CekKarsiliksizTutar = (decimal)row.KarsiliksizTutar;
            ozet.CekKarsiliksizAdet = (int)row.KarsiliksizAdet;
            ozet.CekVadesiGecmis = (decimal)row.VadGecmis;
            ozet.CekBuHafta = (decimal)row.BuHafta;
            ozet.CekBuAy = (decimal)row.BuAy;
            ozet.CekSonra = (decimal)row.Sonra;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Patron.CekSenet: {ex.Message}"); }

        // 6) Trend — bu ay net cari hareketi (CLFLINE); base=0 ise yüzde hesaplanamaz → null
        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                DECLARE @ayBasi DATE = DATEFROMPARTS(YEAR(@bugun), MONTH(@bugun), 1);
                SELECT ISNULL(SUM(CASE WHEN SIGN = 0 THEN AMOUNT ELSE -AMOUNT END), 0) AS BuAyNet
                FROM LG_{_firmaNo}_{_donemNo}_CLFLINE WITH(NOLOCK)
                WHERE CANCELLED = 0 AND DATE_ >= @ayBasi AND DATE_ <= @bugun;";
            ozet.BuAyNetDegisim = await connection.ExecuteScalarAsync<decimal>(sql);

            // Ay başı bakiye = güncel net - bu ay net hareket. Pozitif baz varsa yüzde anlamlı.
            var ayBasiBaz = ozet.NetBakiye - ozet.BuAyNetDegisim;
            if (ozet.BuAyNetDegisim != 0 && ayBasiBaz != 0)
                ozet.TrendYuzde = Math.Round(ozet.BuAyNetDegisim / Math.Abs(ayBasiBaz) * 100, 1);
            else
                ozet.TrendYuzde = null; // veri yok → UI rozeti gizler
        }
        catch (Exception ex) { Console.WriteLine($"❌ Patron.Trend: {ex.Message}"); }

        return ozet;
    }

    // ── Bankalar (drill-down 1. seviye): her banka + hesap sayısı + toplam bakiye ──
    public async Task<IEnumerable<BankaKayit>> GetBankalarAsync()
    {
        var sql = $@"
            SELECT b.LOGICALREF AS Id, b.CODE AS Kod, b.DEFINITION_ AS Ad,
                   (SELECT COUNT(*) FROM LG_{_firmaNo}_BANKACC a WITH(NOLOCK)
                    WHERE a.BANKREF = b.LOGICALREF AND a.ACTIVE = 0) AS HesapSayisi,
                   ISNULL((
                       SELECT SUM(CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE -f.AMOUNT END)
                       FROM LG_{_firmaNo}_{_donemNo}_BNFLINE f WITH(NOLOCK)
                       JOIN LG_{_firmaNo}_BANKACC a WITH(NOLOCK) ON a.LOGICALREF = f.BNACCREF AND a.ACTIVE = 0
                       WHERE a.BANKREF = b.LOGICALREF AND f.CANCELLED = 0
                   ), 0) AS Bakiye
            FROM LG_{_firmaNo}_BNCARD b WITH(NOLOCK)
            WHERE b.ACTIVE = 0
              AND EXISTS (SELECT 1 FROM LG_{_firmaNo}_BANKACC a WITH(NOLOCK)
                          WHERE a.BANKREF = b.LOGICALREF AND a.ACTIVE = 0)
            ORDER BY b.CODE;";
        using var connection = new SqlConnection(_connectionString);
        return (await connection.QueryAsync<BankaKayit>(sql)).ToList();
    }

    // ── Bir bankanın hesapları (drill-down 2. seviye): hesap + döviz + bakiye ──
    // Bakiye = LG_{F}_{D}_BNFLINE üzerinde SUM(SIGN=0 ? +AMOUNT : -AMOUNT) (LOGO ekstresiyle birebir).
    public async Task<IEnumerable<BankaHesap>> GetBankaHesaplarAsync(int bankaRef)
    {
        var sql = $@"
            SELECT a.LOGICALREF AS Id, a.CODE AS Kod, a.DEFINITION_ AS Ad,
                   a.CURRENCY AS Currency, ISNULL(a.IBAN, '') AS Iban,
                   ISNULL((
                       SELECT SUM(CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE -f.AMOUNT END)
                       FROM LG_{_firmaNo}_{_donemNo}_BNFLINE f WITH(NOLOCK)
                       WHERE f.BNACCREF = a.LOGICALREF AND f.CANCELLED = 0
                   ), 0) AS Bakiye
            FROM LG_{_firmaNo}_BANKACC a WITH(NOLOCK)
            WHERE a.BANKREF = @BankaRef AND a.ACTIVE = 0
            ORDER BY a.CODE;";
        using var connection = new SqlConnection(_connectionString);
        var list = (await connection.QueryAsync<BankaHesap>(sql, new { BankaRef = bankaRef })).ToList();
        foreach (var h in list) h.CurrencyKod = CurrencyKodu(h.Currency);
        return list;
    }

    // Döviz kodu → kısa etiket (LOGO CURRENCY: 0=yerel/TL). Bilinmeyen → boş.
    private static string CurrencyKodu(int currency) => currency switch
    {
        0 => "TL",
        1 => "USD",
        20 => "EUR",
        17 => "GBP",
        _ => "",
    };

    // ── Çek/senet listesi (drill-down). tip: "tahsil" (müşteri) | "odeme" (kendi) ──
    public async Task<IEnumerable<CekKayit>> GetCeklerAsync(string tip)
    {
        var docFiltre = tip == "odeme" ? "cs.DOC IN (3,4)" : "cs.DOC IN (1,2)";
        var sql = $@"
            SELECT
                cs.LOGICALREF AS Id,
                cs.DOC,
                cs.CURRSTAT AS CurrStat,
                cs.DUEDATE AS Vade,
                cs.AMOUNT AS Tutar,
                ISNULL(cs.BANKNAME, '') AS Banka,
                ISNULL(cs.OWING, '') AS Kesideci,
                -- Çekin bağlı olduğu cari (çek/senet hareketi CSTRANS, kart türü 5 = cari hesap)
                ISNULL((
                    SELECT TOP 1 cl.DEFINITION_
                    FROM LG_{_firmaNo}_{_donemNo}_CSTRANS t WITH(NOLOCK)
                    JOIN LG_{_firmaNo}_CLCARD cl WITH(NOLOCK)
                        ON cl.LOGICALREF = t.CARDREF AND cl.LOGICALREF <> 1
                    WHERE t.CSREF = cs.LOGICALREF AND t.CANCELLED = 0 AND t.CARDMD = 5
                    ORDER BY t.DATE_ DESC, t.LOGICALREF DESC
                ), '') AS CariAd
            FROM LG_{_firmaNo}_{_donemNo}_CSCARD cs WITH(NOLOCK)
            WHERE {docFiltre} AND cs.CANCELLED = 0 AND {CekBekleyenStat}
            ORDER BY cs.DUEDATE ASC;";
        using var connection = new SqlConnection(_connectionString);
        var list = (await connection.QueryAsync<CekKayit>(sql)).ToList();
        foreach (var c in list)
        {
            c.Tur = (c.Doc == 2 || c.Doc == 4) ? "Senet" : "Çek";
            c.Durum = CekDurumAdi(c.CurrStat);
        }
        return list;
    }

    // Çek/senet güncel durum kodu → Türkçe etiket (bu kurulumda doğrulanan değerler).
    private static string CekDurumAdi(int currStat) => currStat switch
    {
        1 => "Portföyde",
        2 => "Cirolandı",
        4 => "Bankada",
        6 => "Karşılıksız",
        8 => "Kapandı",
        9 => "Tedavülde",
        _ => "Diğer",
    };
}
