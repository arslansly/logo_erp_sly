namespace LogoMobileApi.Services;

/// <summary>
/// İnce yetki kataloğu — anahtarlar Flutter tarafıyla birebir aynı.
/// Effective yetki = rolün varsayılan seti + kullanıcıya özel override (istisna).
/// </summary>
public static class AppPermissions
{
    public const string ViewReports = "view_reports";                     // Şirket raporları (Raporlar sekmesi)
    public const string ViewFinancialReports = "view_financial_reports";  // Cari bakiye / vade raporu
    public const string ViewStokCost = "view_stok_cost";                  // Stok maliyet / alış fiyatı
    public const string ViewDashboardFinancials = "view_dashboard_financials"; // Ana sayfa toplam alacak/tahsilat
    public const string ViewPatronPanel = "view_patron_panel";            // Patron paneli (net alacak-borç, nakit/banka, çek-senet)
    public const string ViewSahaPanel = "view_saha_panel";                // Saha paneli (satışçı: açık siparişler, riskli müşteriler)
    public const string CreateBelge = "create_belge";                     // Fatura/sipariş/irsaliye taslağı oluştur
    public const string ApproveBelge = "approve_belge";                   // Satışçının kestiği taslağı onayla/reddet
    public const string TransferBelge = "transfer_belge";                 // Taslağı LOGO'ya aktar
    public const string DeleteBelge = "delete_belge";                     // Taslak/belge sil
    public const string ManageUsers = "manage_users";                     // Kullanıcı yönetimi
    public const string EditSettings = "edit_settings";                   // Sunucu/firma ayarları

    public static readonly string[] All =
    {
        ViewReports, ViewFinancialReports, ViewStokCost,
        ViewDashboardFinancials, ViewPatronPanel, ViewSahaPanel,
        CreateBelge, ApproveBelge, TransferBelge, DeleteBelge,
        ManageUsers, EditSettings,
    };

    public static bool IsValid(string? key) =>
        !string.IsNullOrWhiteSpace(key) && Array.IndexOf(All, key) >= 0;

    /// <summary>
    /// Rolün varsayılan yetki seti (sabit). Override yoksa bu geçerlidir.
    /// </summary>
    public static HashSet<string> DefaultsFor(string? role)
    {
        switch (RoleHelper.Normalize(role))
        {
            case RoleHelper.Admin:
                return new HashSet<string>(All); // her şey

            case RoleHelper.Patron:
                // Sunucu/firma ayarları hariç her şey
                return new HashSet<string>(All.Where(p => p != EditSettings));

            case RoleHelper.Muhasebe:
                return new HashSet<string>
                {
                    ViewReports, ViewFinancialReports, ViewStokCost,
                    ViewDashboardFinancials, ViewPatronPanel, ViewSahaPanel,
                    CreateBelge, ApproveBelge, TransferBelge, DeleteBelge,
                };

            case RoleHelper.Satisci:
            default:
                // Satışçı saha aracı: belge oluştur + saha paneli (açık siparişler, riskli müşteriler)
                return new HashSet<string> { CreateBelge, ViewSahaPanel };
        }
    }
}
