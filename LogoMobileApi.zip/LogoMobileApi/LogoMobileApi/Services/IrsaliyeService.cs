using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// LOGO STFICHE + STLINE üstünden irsaliye okuma servisi.
// Yazma akışı (taslak + LOGO'ya aktarım) faz 2'de — ShipmentDraftService.
public class IrsaliyeService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    // Listede gösterilecek TRCODE'lar: satış/satınalma + iadeler.
    // Sarf/üretim/sayım/transfer fişleri (11,12,13,14,25,26,50,51) hariç.
    private const string TRCODE_FILTER = "(1,2,3,6,7,8)";

    public IrsaliyeService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    public async Task<IEnumerable<Irsaliye>> GetAllAsync(
        int offset = 0,
        int limit = 50,
        string? search = null,
        DateTime? baslangic = null,
        DateTime? bitis = null,
        int? trCode = null,
        bool? faturalandi = null,
        int? cariId = null)
    {
        var sql = $@"
            SELECT
                sf.LOGICALREF                   AS Id,
                ISNULL(sf.FICHENO, '')          AS FicheNo,
                ISNULL(sf.DOCODE, '')           AS DocCode,
                sf.DATE_                        AS Date,
                sf.TRCODE                       AS TrCode,
                sf.CLIENTREF                    AS ClientRef,
                ISNULL(clc.CODE, '')            AS ClientCode,
                ISNULL(clc.DEFINITION_, '')     AS ClientTitle,
                ISNULL(sf.NETTOTAL, 0)          AS NetTotal,
                sf.INVOICEREF                   AS InvoiceRef,
                ISNULL(sf.INVNO, '')            AS InvNo,
                ISNULL(sf.BILLED, 0)            AS Billed,
                sf.CANCELLED                    AS Cancelled
            FROM LG_{_firmaNo}_{_donemNo}_STFICHE sf WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = sf.CLIENTREF
            WHERE sf.CANCELLED = 0
              AND sf.TRCODE IN {TRCODE_FILTER}
              AND (@TrCode IS NULL OR sf.TRCODE = @TrCode)
              AND (@CariId IS NULL OR sf.CLIENTREF = @CariId)
              AND (@Baslangic IS NULL OR sf.DATE_ >= @Baslangic)
              AND (@Bitis     IS NULL OR sf.DATE_ <= @Bitis)
              AND (@Faturalandi IS NULL
                   OR (@Faturalandi = 1 AND sf.BILLED = 1)
                   OR (@Faturalandi = 0 AND ISNULL(sf.BILLED, 0) = 0))
              AND (@Search IS NULL
                   OR sf.FICHENO LIKE '%' + @Search + '%'
                   OR sf.DOCODE  LIKE '%' + @Search + '%'
                   OR clc.CODE    LIKE '%' + @Search + '%'
                   OR clc.DEFINITION_ LIKE '%' + @Search + '%')
            ORDER BY sf.DATE_ DESC, sf.LOGICALREF DESC
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var list = (await connection.QueryAsync<Irsaliye>(sql, new
            {
                Search = search,
                Baslangic = baslangic?.Date,
                Bitis = bitis?.Date.AddDays(1).AddTicks(-1),
                TrCode = trCode,
                Faturalandi = faturalandi.HasValue ? (int?)(faturalandi.Value ? 1 : 0) : null,
                CariId = cariId,
                Offset = offset,
                Limit = limit
            })).ToList();

            foreach (var i in list)
            {
                i.TrCodeName = StokTrCodeMapper.GetName(i.TrCode, isInvoice: false);
            }
            return list;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[IrsaliyeService.GetAllAsync] Hata: {ex}");
            throw new Exception("İrsaliye listesi alınamadı");
        }
    }

    public async Task<Irsaliye?> GetByIdAsync(int id)
    {
        var sql = $@"
            SELECT
                sf.LOGICALREF                   AS Id,
                ISNULL(sf.FICHENO, '')          AS FicheNo,
                ISNULL(sf.DOCODE, '')           AS DocCode,
                sf.DATE_                        AS Date,
                sf.TRCODE                       AS TrCode,
                sf.CLIENTREF                    AS ClientRef,
                ISNULL(clc.CODE, '')            AS ClientCode,
                ISNULL(clc.DEFINITION_, '')     AS ClientTitle,
                ISNULL(sf.NETTOTAL, 0)          AS NetTotal,
                sf.INVOICEREF                   AS InvoiceRef,
                ISNULL(sf.INVNO, '')            AS InvNo,
                ISNULL(sf.BILLED, 0)            AS Billed,
                sf.CANCELLED                    AS Cancelled
            FROM LG_{_firmaNo}_{_donemNo}_STFICHE sf WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = sf.CLIENTREF
            WHERE sf.LOGICALREF = @Id";

        using var connection = new SqlConnection(_connectionString);
        var i = await connection.QueryFirstOrDefaultAsync<Irsaliye>(sql, new { Id = id });
        if (i != null)
        {
            i.TrCodeName = StokTrCodeMapper.GetName(i.TrCode, isInvoice: false);
        }
        return i;
    }

    public async Task<IEnumerable<IrsaliyeSatir>> GetSatirlarAsync(int shipmentId)
    {
        var sql = $@"
            SELECT
                stl.LOGICALREF                  AS Id,
                stl.STFICHELNNO                 AS [LineNo],
                stl.LINETYPE                    AS LineType,
                stl.STOCKREF                    AS StockRef,
                ISNULL(itm.CODE, '')            AS StockCode,
                ISNULL(itm.NAME, '')            AS StockName,
                ISNULL(usl.CODE, '')            AS UomCode,
                ISNULL(stl.AMOUNT, 0)           AS Amount,
                ISNULL(stl.PRICE, 0)            AS Price,
                ISNULL(stl.VAT, 0)              AS VatRate,
                ISNULL(stl.TOTAL, 0)            AS Total,
                ISNULL(stl.VATAMNT, 0)          AS VatAmount,
                ISNULL(stl.LINENET, 0)          AS LineNet,
                ISNULL(stl.DISTDISC, 0)         AS Discount,
                ISNULL(stl.LINEEXP, '')         AS LineDescription
            FROM LG_{_firmaNo}_{_donemNo}_STLINE stl WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_ITEMS itm WITH(NOLOCK)
                ON itm.LOGICALREF = stl.STOCKREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL usl WITH(NOLOCK)
                ON usl.LOGICALREF = stl.UOMREF
            WHERE stl.STFICHEREF = @Id
            -- INVOICEREF filtresi yok: irsaliyenin kendi satırları gösterilir
            -- (faturalanmamış satırlarda INVOICEREF NULL değil 0'dır; faturalansa
            --  da bu STLINE satırı irsaliyeye aittir).
            ORDER BY stl.STFICHELNNO, stl.LOGICALREF";

        using var connection = new SqlConnection(_connectionString);
        var lines = (await connection.QueryAsync<IrsaliyeSatir>(sql, new { Id = shipmentId })).ToList();
        foreach (var l in lines)
        {
            l.LineTypeName = LineTypeName(l.LineType);
        }
        return lines;
    }

    public async Task<IrsaliyeDetay?> GetDetayAsync(int id)
    {
        var baslik = await GetByIdAsync(id);
        if (baslik == null) return null;

        var expSql = $@"
            SELECT ISNULL(GENEXP1, '') AS GenExp1, ISNULL(GENEXP2, '') AS GenExp2
            FROM LG_{_firmaNo}_{_donemNo}_STFICHE WITH(NOLOCK)
            WHERE LOGICALREF = @Id";
        using var connection = new SqlConnection(_connectionString);
        // Concrete DTO ile oku (Dapper ValueTuple/dynamic mapping kırılgan).
        var exp = await connection.QueryFirstOrDefaultAsync<GenExpRow>(expSql, new { Id = id });

        var satirlar = (await GetSatirlarAsync(id)).ToList();

        return new IrsaliyeDetay
        {
            Baslik = baslik,
            Satirlar = satirlar,
            GenExp1 = exp?.GenExp1 ?? "",
            GenExp2 = exp?.GenExp2 ?? "",
        };
    }

    // GenExp okuma DTO'su (Dapper concrete mapping).
    private sealed class GenExpRow
    {
        public string? GenExp1 { get; set; }
        public string? GenExp2 { get; set; }
    }

    private static string LineTypeName(int lt) => lt switch
    {
        0 => "Malzeme",
        1 => "Hizmet",
        2 => "Masraf",
        3 => "Promosyon",
        4 => "İskonto",
        _ => $"Tip ({lt})"
    };
}
