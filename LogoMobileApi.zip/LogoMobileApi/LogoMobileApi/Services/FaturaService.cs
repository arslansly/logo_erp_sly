using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// LOGO LG_xxx_yy_INVOICE + STLINE üstünden fatura okuma servisi.
// Yazma akışı InvoiceDraftService'te (taslak + aktar pattern).
public class FaturaService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public FaturaService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // Fatura listesi — sayfalı, aranabilir, tarih/cari/tür filtreli.
    // CANCELLED=0 her zaman uygulanır. Sadece fatura TRCODE'ları (31..56).
    // INVOICE.TRCODE kategori eşlemesi (bu kurulumda 1-9 kodlaması).
    // Satış=7,8,9 / Satınalma(Alış)=1,4 / İade=2,3,6
    private static int[]? KategoriTrCodes(string? kategori) => kategori switch
    {
        "Satış"     => new[] { 7, 8, 9 },
        "Satınalma" => new[] { 1, 4 },
        "İade"      => new[] { 2, 3, 6 },
        _ => null,
    };

    public async Task<IEnumerable<Fatura>> GetAllAsync(
        int offset = 0,
        int limit = 50,
        string? search = null,
        DateTime? baslangic = null,
        DateTime? bitis = null,
        int? trCode = null,
        int? cariId = null,
        string? kategori = null)
    {
        var kategoriCodes = KategoriTrCodes(kategori);
        // Dapper, aynı parametreyi hem IN listesi hem skaler kullanamadığı için
        // kategori filtresini koşullu olarak ekliyoruz.
        var kategoriClause = kategoriCodes != null
            ? "AND inv.TRCODE IN @KategoriCodes"
            : "";
        var sql = $@"
            SELECT
                inv.LOGICALREF                    AS Id,
                ISNULL(inv.FICHENO, '')           AS FicheNo,
                ISNULL(inv.DOCODE, '')            AS DocCode,
                inv.DATE_                         AS Date,
                inv.TRCODE                        AS TrCode,
                inv.CLIENTREF                     AS ClientRef,
                ISNULL(clc.CODE, '')              AS ClientCode,
                ISNULL(clc.DEFINITION_, '')       AS ClientTitle,
                ISNULL(inv.NETTOTAL, 0)           AS NetTotal,
                ISNULL(inv.GROSSTOTAL, 0)         AS GrossTotal,
                ISNULL(inv.TOTALVAT, 0)           AS TotalVat,
                ISNULL(inv.TOTALDISCOUNTS, 0)     AS TotalDiscounts,
                inv.CANCELLED                     AS Cancelled
            FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = inv.CLIENTREF
            WHERE inv.CANCELLED = 0
              -- Bu LOGO'da INVOICE.TRCODE STFICHE ile aynı 1-10 kodlamasını kullanır
              -- (1=Satınalma, 7=Perakende Satış, 8=Toptan Satış, 4/9=Hizmet, 2/3/6=İade)
              AND inv.TRCODE IN (1,2,3,4,6,7,8,9)
              AND (@TrCode IS NULL OR inv.TRCODE = @TrCode)
              {kategoriClause}
              AND (@CariId IS NULL OR inv.CLIENTREF = @CariId)
              AND (@Baslangic IS NULL OR inv.DATE_ >= @Baslangic)
              AND (@Bitis     IS NULL OR inv.DATE_ <= @Bitis)
              AND (@Search IS NULL
                   OR inv.FICHENO LIKE '%' + @Search + '%'
                   OR inv.DOCODE  LIKE '%' + @Search + '%'
                   OR clc.CODE    LIKE '%' + @Search + '%'
                   OR clc.DEFINITION_ LIKE '%' + @Search + '%')
            ORDER BY inv.DATE_ DESC, inv.LOGICALREF DESC
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var faturalar = (await connection.QueryAsync<Fatura>(sql, new
            {
                Search = search,
                Baslangic = baslangic?.Date,
                Bitis = bitis?.Date.AddDays(1).AddTicks(-1),
                TrCode = trCode,
                KategoriCodes = kategoriCodes,
                CariId = cariId,
                Offset = offset,
                Limit = limit
            })).ToList();

            foreach (var f in faturalar)
            {
                f.TrCodeName = StokTrCodeMapper.GetName(f.TrCode, isInvoice: true);
                f.IsDraft = false;
            }

            return faturalar;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[FaturaService.GetAllAsync] Hata: {ex.Message}");
            throw new Exception("Fatura listesi alınamadı");
        }
    }

    // Tek fatura — header
    public async Task<Fatura?> GetByIdAsync(int id)
    {
        var sql = $@"
            SELECT
                inv.LOGICALREF                    AS Id,
                ISNULL(inv.FICHENO, '')           AS FicheNo,
                ISNULL(inv.DOCODE, '')            AS DocCode,
                inv.DATE_                         AS Date,
                inv.TRCODE                        AS TrCode,
                inv.CLIENTREF                     AS ClientRef,
                ISNULL(clc.CODE, '')              AS ClientCode,
                ISNULL(clc.DEFINITION_, '')       AS ClientTitle,
                ISNULL(inv.NETTOTAL, 0)           AS NetTotal,
                ISNULL(inv.GROSSTOTAL, 0)         AS GrossTotal,
                ISNULL(inv.TOTALVAT, 0)           AS TotalVat,
                ISNULL(inv.TOTALDISCOUNTS, 0)     AS TotalDiscounts,
                inv.CANCELLED                     AS Cancelled
            FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = inv.CLIENTREF
            WHERE inv.LOGICALREF = @Id";

        using var connection = new SqlConnection(_connectionString);
        var fatura = await connection.QueryFirstOrDefaultAsync<Fatura>(sql, new { Id = id });
        if (fatura != null)
        {
            fatura.TrCodeName = StokTrCodeMapper.GetName(fatura.TrCode, isInvoice: true);
            fatura.IsDraft = false;
        }
        return fatura;
    }

    // Fatura satırları — LINETYPE 0..4 hepsi (UI gerekirse filtreler)
    public async Task<IEnumerable<FaturaSatir>> GetSatirlarAsync(int invoiceId)
    {
        var sql = $@"
            SELECT
                stl.LOGICALREF                    AS Id,
                stl.INVOICELNNO                   AS [LineNo],
                stl.LINETYPE                      AS LineType,
                stl.STOCKREF                      AS StockRef,
                ISNULL(itm.CODE, '')              AS StockCode,
                ISNULL(itm.NAME, '')              AS StockName,
                ISNULL(uom.CODE, '')              AS UomCode,
                ISNULL(stl.AMOUNT, 0)             AS Amount,
                ISNULL(stl.PRICE, 0)              AS Price,
                ISNULL(stl.VAT, 0)                AS VatRate,
                ISNULL(stl.TOTAL, 0)              AS Total,
                ISNULL(stl.VATAMNT, 0)            AS VatAmount,
                ISNULL(stl.LINENET, 0)            AS LineNet,
                ISNULL(stl.DISTDISC, 0)           AS Discount,
                ISNULL(stl.LINEEXP, '')           AS LineDescription
            FROM LG_{_firmaNo}_{_donemNo}_STLINE stl WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_ITEMS itm WITH(NOLOCK)
                ON itm.LOGICALREF = stl.STOCKREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL uom WITH(NOLOCK)
                ON uom.LOGICALREF = stl.UOMREF
            WHERE stl.INVOICEREF = @InvoiceId
            ORDER BY stl.INVOICELNNO, stl.LOGICALREF";

        using var connection = new SqlConnection(_connectionString);
        var satirlar = (await connection.QueryAsync<FaturaSatir>(sql, new { InvoiceId = invoiceId })).ToList();

        foreach (var s in satirlar)
        {
            s.LineTypeName = s.LineType switch
            {
                0 => "Malzeme",
                1 => "Hizmet",
                2 => "Masraf",
                3 => "Promosyon",
                4 => "İskonto",
                _ => $"Tip {s.LineType}"
            };
        }
        return satirlar;
    }

    // Detay bundle — header + satırlar + bağlı irsaliye/sipariş + GENEXP'ler
    public async Task<FaturaDetay?> GetDetayAsync(int id)
    {
        var headerSql = $@"
            SELECT
                inv.LOGICALREF                    AS Id,
                ISNULL(inv.FICHENO, '')           AS FicheNo,
                ISNULL(inv.DOCODE, '')            AS DocCode,
                inv.DATE_                         AS Date,
                inv.TRCODE                        AS TrCode,
                inv.CLIENTREF                     AS ClientRef,
                ISNULL(clc.CODE, '')              AS ClientCode,
                ISNULL(clc.DEFINITION_, '')       AS ClientTitle,
                ISNULL(inv.NETTOTAL, 0)           AS NetTotal,
                ISNULL(inv.GROSSTOTAL, 0)         AS GrossTotal,
                ISNULL(inv.TOTALVAT, 0)           AS TotalVat,
                ISNULL(inv.TOTALDISCOUNTS, 0)     AS TotalDiscounts,
                inv.CANCELLED                     AS Cancelled,
                ISNULL(inv.GENEXP1, '')           AS GenExp1,
                ISNULL(inv.GENEXP2, '')           AS GenExp2,
                ISNULL(inv.GENEXP3, '')           AS GenExp3,
                ISNULL(inv.GENEXP4, '')           AS GenExp4
            FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = inv.CLIENTREF
            WHERE inv.LOGICALREF = @Id";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var row = await connection.QueryFirstOrDefaultAsync(headerSql, new { Id = id });
            if (row == null) return null;

            var baslik = new Fatura
            {
                Id = (int)row.Id,
                FicheNo = row.FicheNo ?? "",
                DocCode = row.DocCode ?? "",
                Date = (DateTime)row.Date,
                TrCode = (int)row.TrCode,
                ClientRef = (int)row.ClientRef,
                ClientCode = row.ClientCode ?? "",
                ClientTitle = row.ClientTitle ?? "",
                NetTotal = (decimal)row.NetTotal,
                GrossTotal = (decimal)row.GrossTotal,
                TotalVat = (decimal)row.TotalVat,
                TotalDiscounts = (decimal)row.TotalDiscounts,
                Cancelled = (int)row.Cancelled,
                IsDraft = false,
            };
            baslik.TrCodeName = StokTrCodeMapper.GetName(baslik.TrCode, isInvoice: true);

            var satirlar = (await GetSatirlarAsync(id)).ToList();
            var irsaliyeler = (await GetBaglantiliIrsaliyelerAsync(id)).ToList();
            var siparisler = (await GetBaglantiliSiparislerAsync(id)).ToList();

            return new FaturaDetay
            {
                Baslik = baslik,
                Satirlar = satirlar,
                Irsaliyeler = irsaliyeler,
                Siparisler = siparisler,
                GenExp1 = row.GenExp1 ?? "",
                GenExp2 = row.GenExp2 ?? "",
                GenExp3 = row.GenExp3 ?? "",
                GenExp4 = row.GenExp4 ?? "",
            };
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[FaturaService.GetDetayAsync] Hata: {ex.Message}");
            throw new Exception("Fatura detayı alınamadı");
        }
    }

    // Bu faturaya bağlı irsaliyeler — STFICHE.INVOICEREF üstünden
    public async Task<IEnumerable<BagliBelge>> GetBaglantiliIrsaliyelerAsync(int invoiceId)
    {
        var sql = $@"
            SELECT
                sf.LOGICALREF                AS Id,
                ISNULL(sf.FICHENO, '')       AS FicheNo,
                sf.DATE_                     AS Date,
                sf.TRCODE                    AS TrCode,
                ISNULL(sf.NETTOTAL, 0)       AS Total
            FROM LG_{_firmaNo}_{_donemNo}_STFICHE sf WITH(NOLOCK)
            WHERE sf.INVOICEREF = @InvoiceId
              AND sf.CANCELLED = 0
            ORDER BY sf.DATE_ DESC";

        using var connection = new SqlConnection(_connectionString);
        var belgeler = (await connection.QueryAsync<BagliBelge>(sql, new { InvoiceId = invoiceId })).ToList();
        foreach (var b in belgeler)
        {
            b.TrCodeName = StokTrCodeMapper.GetName(b.TrCode, isInvoice: false);
        }
        return belgeler;
    }

    // Bu faturaya bağlı siparişler — STLINE üstünden ORDFICHEREF distinct join
    public async Task<IEnumerable<BagliBelge>> GetBaglantiliSiparislerAsync(int invoiceId)
    {
        var sql = $@"
            SELECT DISTINCT
                orf.LOGICALREF               AS Id,
                ISNULL(orf.FICHENO, '')      AS FicheNo,
                orf.DATE_                    AS Date,
                orf.TRCODE                   AS TrCode,
                ISNULL(orf.NETTOTAL, 0)      AS Total
            FROM LG_{_firmaNo}_{_donemNo}_STLINE stl WITH(NOLOCK)
            INNER JOIN LG_{_firmaNo}_{_donemNo}_ORFICHE orf WITH(NOLOCK)
                ON orf.LOGICALREF = stl.ORDFICHEREF
            WHERE stl.INVOICEREF = @InvoiceId
              AND stl.ORDFICHEREF IS NOT NULL
              AND stl.ORDFICHEREF > 0
            ORDER BY orf.DATE_ DESC";

        using var connection = new SqlConnection(_connectionString);
        var belgeler = (await connection.QueryAsync<BagliBelge>(sql, new { InvoiceId = invoiceId })).ToList();
        foreach (var b in belgeler)
        {
            b.TrCodeName = OrderCodeMapper.GetTrCodeName(b.TrCode);
        }
        return belgeler;
    }
}
