namespace LogoMobileApi.Services;

// Sipariş TRCODE + STATUS adlandırması (ORFICHE/ORFLINE).
public static class OrderCodeMapper
{
    // ORFICHE.TRCODE → ad
    public static string GetTrCodeName(int trCode) => trCode switch
    {
        1 => "Satış Siparişi",       // alınan sipariş
        2 => "Satınalma Siparişi",   // verilen sipariş
        _ => $"Sipariş ({trCode})"
    };

    // ORFICHE.STATUS → ad (CANLI DOĞRULANMIŞ; LOGO_ERP_DATABASE_REFERENCE.md §14.1)
    public static string GetStatusName(int status) => status switch
    {
        1 => "Öneri",
        2 => "Sevkedilemez",
        3 => "Sevkedilebilir",
        4 => "Sevkedildi",
        _ => $"Durum ({status})"
    };
}
