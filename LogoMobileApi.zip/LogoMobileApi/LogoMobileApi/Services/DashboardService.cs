﻿using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

public class DashboardService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public DashboardService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    public async Task<DashboardOzet> GetOzetAsync()
    {
        var ozet = new DashboardOzet();
        using var connection = new SqlConnection(_connectionString);

        try
        {
            var sql = $@"
                SELECT ISNULL(SUM(DEBIT - CREDIT), 0)
                FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL WITH(NOLOCK)
                WHERE TOTTYP = 1";
            ozet.ToplamAlacak = await connection.ExecuteScalarAsync<decimal>(sql);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ ToplamAlacak: {ex.Message}");
        }

        try
        {
            var sql = $@"
                SELECT ISNULL(SUM(TOTAL - PAID), 0)
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS WITH(NOLOCK)
                WHERE CANCELLED = 0 AND SIGN = 0 AND TOTAL > PAID
                  AND DATE_ < CAST(GETDATE() AS DATE)";
            ozet.VadesiGecen = await connection.ExecuteScalarAsync<decimal>(sql);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ VadesiGecen: {ex.Message}");
        }

        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                DECLARE @yarin DATE = DATEADD(DAY, 1, @bugun);
                SELECT ISNULL(SUM(AMOUNT), 0)
                FROM LG_{_firmaNo}_{_donemNo}_CLFLINE WITH(NOLOCK)
                WHERE CANCELLED = 0
                  AND SIGN = 1
                  AND DATE_ >= @bugun
                  AND DATE_ < @yarin
                  AND TRCODE IN (1, 12, 70, 72)";
            ozet.BugunTahsilat = await connection.ExecuteScalarAsync<decimal>(sql);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ BugunTahsilat: {ex.Message}");
        }

        try
        {
            var sql = $@"
                SELECT COUNT(DISTINCT CARDREF)
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS WITH(NOLOCK)
                WHERE CANCELLED = 0 AND SIGN = 0 AND TOTAL > PAID
                  AND DATE_ < CAST(GETDATE() AS DATE)";
            ozet.VadesiGecenCariSayisi = await connection.ExecuteScalarAsync<int>(sql);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ VadesiGecenCariSayisi: {ex.Message}");
        }

        // Gerçek trend — bu ay net cari hareketi (CLFLINE). Ay başı bakiyeye oranla yüzde.
        // Hareket yoksa / baz 0 ise null bırakılır → UI rozeti gizler (hardcoded yüzde yerine).
        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                DECLARE @ayBasi DATE = DATEFROMPARTS(YEAR(@bugun), MONTH(@bugun), 1);
                SELECT ISNULL(SUM(CASE WHEN SIGN = 0 THEN AMOUNT ELSE -AMOUNT END), 0)
                FROM LG_{_firmaNo}_{_donemNo}_CLFLINE WITH(NOLOCK)
                WHERE CANCELLED = 0 AND DATE_ >= @ayBasi AND DATE_ <= @bugun";
            var buAyNet = await connection.ExecuteScalarAsync<decimal>(sql);
            var ayBasiBaz = ozet.ToplamAlacak - buAyNet;
            ozet.TrendYuzde = (buAyNet != 0 && ayBasiBaz != 0)
                ? Math.Round(buAyNet / Math.Abs(ayBasiBaz) * 100, 1)
                : (decimal?)null;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Trend: {ex.Message}");
        }

        return ozet;
    }

    public async Task<IEnumerable<SonHareket>> GetSonHareketlerAsync(int limit = 10)
    {
        try
        {
            var sql = $@"
                SELECT
                    t.Id,
                    t.CariId,
                    ISNULL(clc.CODE, '')         AS CariCode,
                    ISNULL(clc.DEFINITION_, '')  AS CariTitle,
                    t.Date,
                    t.TransactionType,
                    t.Debit,
                    t.Credit
                FROM (
                    SELECT TOP (@Limit)
                        f.LOGICALREF                                  AS Id,
                        f.CLIENTREF                                   AS CariId,
                        f.DATE_                                       AS Date,
                        f.TRCODE                                      AS TransactionType,
                        CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE 0 END AS Debit,
                        CASE WHEN f.SIGN = 1 THEN f.AMOUNT ELSE 0 END AS Credit
                    FROM LG_{_firmaNo}_{_donemNo}_CLFLINE f WITH(NOLOCK)
                    WHERE f.CANCELLED = 0
                    ORDER BY f.DATE_ DESC, f.LOGICALREF DESC
                ) t
                LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                    ON clc.LOGICALREF = t.CariId
                ORDER BY t.Date DESC, t.Id DESC";

            using var connection = new SqlConnection(_connectionString);
            var hareketler = await connection.QueryAsync<SonHareket>(
                sql, new { Limit = limit });

            var list = hareketler.ToList();
            foreach (var h in list)
            {
                h.TransactionTypeName = TrCodeMapper.GetName(h.TransactionType);
            }
            return list;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ GetSonHareketler: {ex.Message}");
            Console.WriteLine($"   StackTrace: {ex.StackTrace}");
            throw;
        }
    }

    // Bugün yapılan tahsilat fişleri — dashboard "Bugün tahsilat" KPI'ı ile aynı kriter
    public async Task<IEnumerable<SonHareket>> GetBugunTahsilatlarAsync()
    {
        try
        {
            var sql = $@"
                DECLARE @bugun DATE = CAST(GETDATE() AS DATE);
                DECLARE @yarin DATE = DATEADD(DAY, 1, @bugun);
                SELECT
                    t.Id,
                    t.CariId,
                    ISNULL(clc.CODE, '')         AS CariCode,
                    ISNULL(clc.DEFINITION_, '')  AS CariTitle,
                    t.Date,
                    t.TransactionType,
                    t.Debit,
                    t.Credit
                FROM (
                    SELECT
                        f.LOGICALREF                                  AS Id,
                        f.CLIENTREF                                   AS CariId,
                        f.DATE_                                       AS Date,
                        f.TRCODE                                      AS TransactionType,
                        CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE 0 END AS Debit,
                        CASE WHEN f.SIGN = 1 THEN f.AMOUNT ELSE 0 END AS Credit
                    FROM LG_{_firmaNo}_{_donemNo}_CLFLINE f WITH(NOLOCK)
                    WHERE f.CANCELLED = 0
                      AND f.SIGN = 1
                      AND f.DATE_ >= @bugun
                      AND f.DATE_ < @yarin
                      AND f.TRCODE IN (1, 12, 70, 72)
                ) t
                LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                    ON clc.LOGICALREF = t.CariId
                ORDER BY t.Date DESC, t.Id DESC";

            using var connection = new SqlConnection(_connectionString);
            var hareketler = await connection.QueryAsync<SonHareket>(sql);

            var list = hareketler.ToList();
            foreach (var h in list)
            {
                h.TransactionTypeName = TrCodeMapper.GetName(h.TransactionType);
            }
            return list;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ GetBugunTahsilatlar: {ex.Message}");
            throw;
        }
    }

    public async Task<IEnumerable<VadesiGecenCari>> GetVadesiGecenCarilerAsync()
    {
        try
        {
            var sql = $@"
                SELECT
                    clc.LOGICALREF       AS Id,
                    clc.CODE             AS Code,
                    clc.DEFINITION_      AS Title,
                    ISNULL(clc.CITY, '') AS City,
                    ISNULL(clc.TELNRS1, '') AS Phone,
                    ozet.VadesiGecenTutar,
                    ozet.EnEskiVadeTarihi,
                    DATEDIFF(DAY, ozet.EnEskiVadeTarihi, CAST(GETDATE() AS DATE)) AS EnEskiGunFarki,
                    ozet.VadeSayisi
                FROM (
                    SELECT
                        pt.CARDREF,
                        SUM(pt.TOTAL - pt.PAID)        AS VadesiGecenTutar,
                        MIN(pt.DATE_)                  AS EnEskiVadeTarihi,
                        COUNT(*)                       AS VadeSayisi
                    FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                    WHERE pt.CANCELLED = 0
                      AND pt.SIGN = 0
                      AND pt.TOTAL > pt.PAID
                      AND pt.DATE_ < CAST(GETDATE() AS DATE)
                    GROUP BY pt.CARDREF
                ) ozet
                INNER JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                    ON clc.LOGICALREF = ozet.CARDREF
                ORDER BY ozet.EnEskiVadeTarihi ASC";

            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();
            var result = await connection.QueryAsync<VadesiGecenCari>(
                new CommandDefinition(sql, commandTimeout: 30));

            return result.ToList();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ GetVadesiGecenCariler: {ex.Message}");
            throw;
        }
    }
}