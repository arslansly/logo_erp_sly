using System.Data;
using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// Taslak fatura CRUD'u — dbo.InvoiceDrafts + dbo.InvoiceDraftLines.
// LOGO INVOICE'a aktarım stub (TODO: gerçek transfer mantığı kullanıcı LOGO
// entegrasyon stratejisini belirleyince yazılır).
public class InvoiceDraftService
{
    private readonly string _connectionString;

    public InvoiceDraftService(IConfiguration configuration)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
    }

    // Taslak listesi — sadece durum + arama + sayfalama
    public async Task<IEnumerable<Fatura>> GetAllAsync(
        string? status = null,
        int offset = 0,
        int limit = 50,
        string? search = null)
    {
        var sql = @"
            SELECT
                d.Id, d.FicheNo, d.DocCode, d.[Date], d.TrCode,
                d.ClientRef, d.ClientCode, d.ClientTitle AS ClientTitle,
                d.NetTotal, d.GrossTotal, d.TotalVat, d.TotalDiscounts,
                d.CurrencyType, d.ExchangeRate,
                d.SalesmanRef, d.PayDefRef,
                d.[Status]              AS DraftStatus,
                d.LastError             AS LastError,
                d.ApprovalStatus        AS ApprovalStatus,
                0                       AS Cancelled
            FROM dbo.InvoiceDrafts d
            WHERE (@Status IS NULL OR d.[Status] = @Status)
              AND (@Search IS NULL
                   OR d.FicheNo    LIKE '%' + @Search + '%'
                   OR d.DocCode    LIKE '%' + @Search + '%'
                   OR d.ClientCode LIKE '%' + @Search + '%'
                   OR d.ClientTitle LIKE '%' + @Search + '%')
            ORDER BY d.CreatedAt DESC, d.Id DESC
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var taslaklar = (await connection.QueryAsync<Fatura>(sql, new
            {
                Status = status,
                Search = search,
                Offset = offset,
                Limit = limit
            })).ToList();

            foreach (var t in taslaklar)
            {
                t.TrCodeName = TrCodeMapper.GetName(t.TrCode);
                t.IsDraft = true;
            }
            return taslaklar;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[InvoiceDraftService.GetAllAsync] HATA: {ex}");
            throw new Exception($"Taslak listesi alınamadı: {ex.Message}");
        }
    }

    // Tek taslak — header + satırlar
    public async Task<InvoiceDraft?> GetByIdAsync(int id)
    {
        var headerSql = "SELECT * FROM dbo.InvoiceDrafts WHERE Id = @Id";
        var linesSql = @"SELECT * FROM dbo.InvoiceDraftLines
                         WHERE DraftId = @Id ORDER BY [LineNo]";

        using var connection = new SqlConnection(_connectionString);
        using var multi = await connection.QueryMultipleAsync(
            headerSql + "; " + linesSql, new { Id = id });

        var draft = await multi.ReadFirstOrDefaultAsync<InvoiceDraft>();
        if (draft == null) return null;
        draft.Lines = (await multi.ReadAsync<InvoiceDraftLine>()).ToList();
        return draft;
    }

    // Yeni taslak — header + satırlar tek transaction
    public async Task<int> CreateAsync(InvoiceDraft draft, string createdBy)
    {
        draft.CreatedBy = createdBy;
        draft.Status = "Draft";
        draft.CreatedAt = DateTime.Now;
        draft.UpdatedAt = DateTime.Now;

        var headerSql = @"
            INSERT INTO dbo.InvoiceDrafts
                (TrCode, FicheNo, DocCode, [Date],
                 ClientRef, ClientCode, ClientTitle,
                 SourceIndex, DestIndex,
                 GrossTotal, TotalDiscounts, TotalVat, NetTotal,
                 CurrencyType, ExchangeRate,
                 SalesmanRef, PayDefRef,
                 GenExp1, GenExp2,
                 [Status], CreatedBy, CreatedAt, UpdatedAt)
            VALUES
                (@TrCode, @FicheNo, @DocCode, @Date,
                 @ClientRef, @ClientCode, @ClientTitle,
                 @SourceIndex, @DestIndex,
                 @GrossTotal, @TotalDiscounts, @TotalVat, @NetTotal,
                 @CurrencyType, @ExchangeRate,
                 @SalesmanRef, @PayDefRef,
                 @GenExp1, @GenExp2,
                 @Status, @CreatedBy, @CreatedAt, @UpdatedAt);
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        using var tx = connection.BeginTransaction();
        try
        {
            var newId = await connection.QuerySingleAsync<int>(headerSql, draft, tx);
            await InsertLinesAsync(connection, tx, newId, draft.Lines);
            tx.Commit();
            return newId;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    // Güncelle — basit yaklaşım: tüm satırları sil + yeniden ekle
    public async Task<bool> UpdateAsync(int id, InvoiceDraft draft)
    {
        var existing = await GetByIdAsync(id);
        if (existing == null) return false;
        if (existing.Status == "Transferred")
            throw new InvalidOperationException("Aktarılmış taslak düzenlenemez");

        draft.UpdatedAt = DateTime.Now;

        var headerSql = @"
            UPDATE dbo.InvoiceDrafts SET
                TrCode = @TrCode,
                FicheNo = @FicheNo,
                DocCode = @DocCode,
                [Date] = @Date,
                ClientRef = @ClientRef,
                ClientCode = @ClientCode,
                ClientTitle = @ClientTitle,
                SourceIndex = @SourceIndex,
                DestIndex = @DestIndex,
                GrossTotal = @GrossTotal,
                TotalDiscounts = @TotalDiscounts,
                TotalVat = @TotalVat,
                NetTotal = @NetTotal,
                CurrencyType = @CurrencyType,
                ExchangeRate = @ExchangeRate,
                SalesmanRef = @SalesmanRef,
                PayDefRef = @PayDefRef,
                GenExp1 = @GenExp1,
                GenExp2 = @GenExp2,
                [Status] = 'Draft',
                LastError = NULL,
                UpdatedAt = @UpdatedAt
            WHERE Id = @Id";

        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        using var tx = connection.BeginTransaction();
        try
        {
            await connection.ExecuteAsync(headerSql, new
            {
                draft.TrCode, draft.FicheNo, draft.DocCode, draft.Date,
                draft.ClientRef, draft.ClientCode, draft.ClientTitle,
                draft.SourceIndex, draft.DestIndex,
                draft.GrossTotal, draft.TotalDiscounts, draft.TotalVat, draft.NetTotal,
                draft.CurrencyType, draft.ExchangeRate,
                draft.SalesmanRef, draft.PayDefRef,
                draft.GenExp1, draft.GenExp2,
                draft.UpdatedAt,
                Id = id
            }, tx);

            await connection.ExecuteAsync(
                "DELETE FROM dbo.InvoiceDraftLines WHERE DraftId = @Id",
                new { Id = id }, tx);
            await InsertLinesAsync(connection, tx, id, draft.Lines);

            tx.Commit();
            return true;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    // Sil — satırlar CASCADE ile gider
    public async Task<bool> DeleteAsync(int id)
    {
        using var connection = new SqlConnection(_connectionString);
        var affected = await connection.ExecuteAsync(
            "DELETE FROM dbo.InvoiceDrafts WHERE Id = @Id AND [Status] != 'Transferred'",
            new { Id = id });
        return affected > 0;
    }

    // -----------------------------------------------------------------------
    // LOGO'YA AKTARIM (TODO)
    //
    // Bu metod şu an STUB. LOGO'ya doğru ve güvenli yazma yöntemi netleşince
    // gerçek implementasyon eklenecek. Olası yöntemler:
    //   (1) Logo REST API / LRESTAPI (LOGO'nun resmi yazma servisi)
    //   (2) LOGO COM nesneleri (CSREF.dll) — masaüstü, ASP.NET'te zor
    //   (3) Manuel INSERT (INVOICE + STLINE + CLFLINE + STINVTOT) —
    //       bakiye/trigger güvenliği şüpheli, önerilmez
    //   (4) Logo-side custom Stored Procedure
    //
    // Şu an: durum 'Failed', LastError doldurulur. Mobil UI bunu Hatalı
    // sekmesinde gösterir, kullanıcı taslağı düzenleyip tekrar deneyebilir
    // (gerçek transfer aktif olunca).
    // -----------------------------------------------------------------------
    public async Task<(bool ok, string? error, int? newInvoiceId)> TransferToLogoAsync(int draftId)
    {
        var draft = await GetByIdAsync(draftId);
        if (draft == null)
            return (false, "Taslak bulunamadı", null);
        if (draft.Status == "Transferred")
            return (false, "Bu taslak zaten LOGO'ya aktarılmış", draft.TransferredInvoiceId);

        const string error = "LOGO aktarım modülü henüz aktif değil. " +
            "Taslak kaydedildi, aktarım stratejisi (REST API / SP / manuel INSERT) belirlenince devreye girecek.";

        using var connection = new SqlConnection(_connectionString);
        await connection.ExecuteAsync(@"
            UPDATE dbo.InvoiceDrafts SET
                [Status] = 'Failed',
                LastError = @Error,
                UpdatedAt = GETDATE()
            WHERE Id = @Id",
            new { Id = draftId, Error = error });

        return (false, error, null);
    }

    // Toplu aktarım — sırayla TransferToLogoAsync çağırır, sonuçları toplar
    public async Task<BatchTransferResult> TransferBatchAsync(IEnumerable<int> draftIds)
    {
        var result = new BatchTransferResult();
        foreach (var id in draftIds)
        {
            var (ok, error, newId) = await TransferToLogoAsync(id);
            if (ok) result.Basarili.Add(new TransferOk { DraftId = id, InvoiceId = newId!.Value });
            else result.Basarisiz.Add(new TransferFail { DraftId = id, Hata = error ?? "Bilinmeyen hata" });
        }
        return result;
    }

    // ── private helpers ──
    private static async Task InsertLinesAsync(
        SqlConnection connection, IDbTransaction tx, int draftId, List<InvoiceDraftLine> lines)
    {
        if (lines.Count == 0) return;

        const string sql = @"
            INSERT INTO dbo.InvoiceDraftLines
                (DraftId, [LineNo], LineType,
                 StockRef, StockCode, StockName,
                 UomRef, UomCode,
                 Amount, Price, VatRate, Discount,
                 Total, VatAmount, LineNet, LineDescription)
            VALUES
                (@DraftId, @LineNo, @LineType,
                 @StockRef, @StockCode, @StockName,
                 @UomRef, @UomCode,
                 @Amount, @Price, @VatRate, @Discount,
                 @Total, @VatAmount, @LineNet, @LineDescription)";

        var lineNo = 1;
        foreach (var ln in lines)
        {
            ln.DraftId = draftId;
            ln.LineNo = lineNo++;
            await connection.ExecuteAsync(sql, ln, tx);
        }
    }
}

public class BatchTransferResult
{
    public List<TransferOk> Basarili { get; set; } = new();
    public List<TransferFail> Basarisiz { get; set; } = new();
}

public class TransferOk
{
    public int DraftId { get; set; }
    public int InvoiceId { get; set; }
}

public class TransferFail
{
    public int DraftId { get; set; }
    public string Hata { get; set; } = "";
}
