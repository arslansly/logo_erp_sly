﻿namespace LogoMobileApi.Services;

public static class TrCodeMapper
{
    private static readonly Dictionary<int, string> _names = new()
    {
        // ── CH İşlemleri (Cari Hesap Fişleri) ──
        { 1,  "Nakit Tahsilat" },
        { 2,  "Nakit Ödeme" },
        { 3,  "Borç Dekontu" },
        { 4,  "Alacak Dekontu" },
        { 5,  "Virman İşlemi" },
        { 6,  "Kur Farkı İşlemi" },
        { 12, "Özel İşlem" },
        { 14, "Açılış İşlemi" },

        // ── Banka Fişleri ──
        { 20, "Gelen Havale" },
        { 21, "Gönderilen Havale" },
        { 24, "Döviz Alış Belgesi" },
        { 25, "Döviz Satış Belgesi" },
        { 28, "Alınan Hizmet Faturası (Banka)" },
        { 29, "Verilen Hizmet Faturası (Banka)" },
        { 30, "Müstahsil Makbuzu (Banka)" },

        // ── Faturalar ──
        { 31, "Satınalma Faturası" },
        { 32, "Perakende Satış İade Faturası" },
        { 33, "Toptan Satış İade Faturası" },
        { 34, "Alınan Hizmet Faturası" },
        { 36, "Satınalma İade Faturası" },
        { 37, "Perakende Satış Faturası" },
        { 38, "Toptan Satış Faturası" },
        { 39, "Verilen Hizmet Faturası" },
        { 43, "Satınalma Fiyat Farkı Faturası" },
        { 44, "Satış Fiyat Farkı Faturası" },
        { 56, "Müstahsil Makbuzu" },

        // ── CH İşlemleri (Vade Farkı / Serbest Meslek) ──
        { 41, "Verilen Vade Farkı Faturası" },
        { 42, "Alınan Vade Farkı Faturası" },
        { 45, "Verilen Serbest Meslek Makbuzu" },
        { 46, "Alınan Serbest Meslek Makbuzu" },

        // ── Bordrolar (Çek/Senet) ──
        { 61, "Çek Girişi" },
        { 62, "Senet Girişi" },
        { 63, "Çek Çıkışı (Cari Hesaba)" },
        { 64, "Senet Çıkışı (Cari Hesaba)" },
        { 65, "İşyerleri Arası İ. Bord. (Müşteri Çeki)" },
        { 66, "İşyerleri Arası İ. Bord. (Müşteri Senedi)" },

        // ── Kredi Kartı ──
        { 70, "Kredi Kartı Fişi" },
        { 71, "Kredi Kartı İade Fişi" },
        { 72, "Firma Kredi Kartı Fişi" },
        { 73, "Firma Kredi Kartı İade Fişi" }
    };

    public static string GetName(int trCode)
    {
        return _names.TryGetValue(trCode, out var name) ? name : $"Bilinmeyen ({trCode})";
    }

    // ── Fatura yardımcıları (LG_xxx_yy_INVOICE.TRCODE filtreleri) ──

    // Fatura TRCODE aralığı: 31-44 + 56 (Müstahsil)
    private static readonly HashSet<int> _invoiceCodes =
        new() { 31, 32, 33, 34, 36, 37, 38, 39, 41, 42, 43, 44, 56 };

    // Satış tarafı: perakende/toptan satış, satış iade, verilen hizmet, satış fiyat farkı
    private static readonly HashSet<int> _satisCodes =
        new() { 32, 33, 37, 38, 39, 41, 44 };

    // İade faturaları
    private static readonly HashSet<int> _iadeCodes =
        new() { 32, 33, 36 };

    public static bool IsInvoice(int trCode) => _invoiceCodes.Contains(trCode);
    public static bool IsSatisFaturasi(int trCode) => _satisCodes.Contains(trCode);
    public static bool IsSatinalmaFaturasi(int trCode) =>
        IsInvoice(trCode) && !IsSatisFaturasi(trCode);
    public static bool IsIade(int trCode) => _iadeCodes.Contains(trCode);

    // Fatura kategori adı — UI gruplaması için
    public static string GetKategori(int trCode)
    {
        if (!IsInvoice(trCode)) return "Diğer";
        if (IsIade(trCode))     return "İade";
        if (IsSatisFaturasi(trCode))     return "Satış";
        return "Satınalma";
    }
}