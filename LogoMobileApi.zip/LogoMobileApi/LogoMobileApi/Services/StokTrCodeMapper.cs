namespace LogoMobileApi.Services;

// STLINE.TRCODE → görünür ad. STFICHE ve INVOICE TRCODE'ları aynı sayılarda
// farklı anlamlara gelebildiği için (örn. 4 = irsaliyede Konsinye Çıkış,
// faturada Alınan Hizmet) bağlam isInvoice ile belirlenir.
public static class StokTrCodeMapper
{
    public static string GetName(int trCode, bool isInvoice) => trCode switch
    {
        1  => isInvoice ? "Satınalma Faturası"             : "Satınalma İrsaliyesi",
        2  => isInvoice ? "Perakende Satış İade Faturası"  : "Perakende Satış İade İrsaliyesi",
        3  => isInvoice ? "Toptan Satış İade Faturası"     : "Toptan Satış İade İrsaliyesi",
        4  => isInvoice ? "Alınan Hizmet Faturası"         : "Konsinye Çıkış İrsaliyesi",
        5  => isInvoice ? "Alınan Proforma Fatura"         : "Konsinye Giriş İrsaliyesi",
        6  => isInvoice ? "Satınalma İade Faturası"        : "Satınalma İade İrsaliyesi",
        7  => isInvoice ? "Perakende Satış Faturası"       : "Perakende Satış İrsaliyesi",
        8  => isInvoice ? "Toptan Satış Faturası"          : "Toptan Satış İrsaliyesi",
        9  => isInvoice ? "Verilen Hizmet Faturası"        : "Konsinye Çıkış İrsaliyesi",
        10 => isInvoice ? "Verilen Proforma Fatura"        : "Konsinye Giriş İade İrsaliyesi",
        11 => "Fire Fişi",
        12 => "Sarf Fişi",
        13 => "Üretimden Giriş Fişi",
        14 => "Devir Fişi",
        25 => "Ambar Transferi Fişi",
        26 => "Müstahsil İrsaliyesi",
        50 => "Sayım Fazlası Fişi",
        51 => "Sayım Eksiği Fişi",
        _  => $"İşlem ({trCode})"
    };
}
