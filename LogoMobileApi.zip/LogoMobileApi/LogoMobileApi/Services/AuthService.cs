﻿using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

public class AuthService
{
    private readonly string _connectionString;
    private readonly JwtTokenService _jwtService;

    public AuthService(IConfiguration configuration, JwtTokenService jwtService)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _jwtService = jwtService;
    }

    /// <summary>
    /// Kullanıcı adı + şifre kontrolü. Doğruysa LoginResponse döner, yanlışsa null.
    /// </summary>
    public async Task<LoginResponse?> LoginAsync(
        string username, string password, string? firmaNo = null, string? donemNo = null)
    {
        using var connection = new SqlConnection(_connectionString);

        // 1) Kullanıcıyı bul
        var user = await connection.QueryFirstOrDefaultAsync<AppUser>(
            "SELECT * FROM AppUsers WHERE Username = @Username AND IsActive = 1",
            new { Username = username });

        if (user == null) return null;

        // 2) Şifreyi karşılaştır (BCrypt zaman-sabit doğrulama yapar, timing attack korumalı)
        bool isValid;
        try
        {
            isValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
        }
        catch
        {
            return null; // Hash bozuksa
        }

        if (!isValid) return null;

        // 3) Son giriş zamanını güncelle (fire-and-forget, hata olursa umursamayız)
        try
        {
            await connection.ExecuteAsync(
                "UPDATE AppUsers SET LastLoginAt = GETDATE() WHERE Id = @Id",
                new { user.Id });
        }
        catch { /* yok say */ }

        // 4) Effective yetkiler (rol varsayılanı + override) + JWT
        var overrides = await ReadOverridesAsync(connection, user.Id);
        var effective = ComputeEffective(user.Role, overrides);
        var (token, expiresAt) =
            _jwtService.GenerateToken(user, firmaNo, donemNo, effective);

        return new LoginResponse
        {
            Token = token,
            ExpiresAt = expiresAt,
            User = new AppUserInfo
            {
                Id = user.Id,
                Username = user.Username,
                FullName = user.FullName,
                Email = user.Email,
                Role = user.Role,
                Permissions = effective.ToArray(),
            }
        };
    }

    /// <summary>
    /// Yeni kullanıcı yaratır (admin için kullanılabilir, ya da seed için)
    /// </summary>
    public async Task<int> CreateUserAsync(
        string username, string password, string fullName,
        string email = "", string role = RoleHelper.Satisci)
    {
        using var connection = new SqlConnection(_connectionString);

        // Geçersiz/bilinmeyen rolü en az yetkili role indir (güvenlik).
        role = RoleHelper.Normalize(role);

        // Kullanıcı zaten var mı?
        var exists = await connection.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM AppUsers WHERE Username = @Username",
            new { Username = username });

        if (exists > 0)
            throw new InvalidOperationException("Bu kullanıcı adı zaten kullanımda");

        // Şifreyi hash'le
        var hash = BCrypt.Net.BCrypt.HashPassword(password, workFactor: 11);

        var id = await connection.ExecuteScalarAsync<int>(@"
            INSERT INTO AppUsers (Username, PasswordHash, FullName, Email, Role)
            OUTPUT INSERTED.Id
            VALUES (@Username, @PasswordHash, @FullName, @Email, @Role)",
            new
            {
                Username = username,
                PasswordHash = hash,
                FullName = fullName,
                Email = email,
                Role = role,
            });

        return id;
    }

    // ─── Kullanıcı listesi (Admin) — PasswordHash dışarı verilmez ───
    public async Task<IEnumerable<UserListItem>> ListUsersAsync()
    {
        using var connection = new SqlConnection(_connectionString);
        return await connection.QueryAsync<UserListItem>(@"
            SELECT Id, Username, FullName, Email, Role, IsActive, LastLoginAt, CreatedAt
            FROM AppUsers
            ORDER BY Username");
    }

    // ─── Kullanıcı güncelle (Admin). Şifre boşsa değiştirilmez ───
    public async Task<bool> UpdateUserAsync(int id, UpdateUserRequest request)
    {
        using var connection = new SqlConnection(_connectionString);

        var newRole = RoleHelper.Normalize(request.Role);

        // ─── Son yönetici koruması (effective manage_users bazlı) ───
        // Bu güncelleme kullanıcının "Kullanıcı Yönetimi" yetkisini kaldırıyorsa
        // (rol düşürme/pasife alma — mevcut override'lar dahil) ve sistemde başka
        // aktif yönetici kalmıyorsa engelle; aksi halde sistem kilitlenir.
        var existingOverrides = await ReadOverridesAsync(connection, id);
        var effAfter = ComputeEffective(newRole, existingOverrides);
        bool willManage = request.IsActive && effAfter.Contains(AppPermissions.ManageUsers);
        if (!willManage && !await AnyOtherActiveManagerAsync(connection, id))
        {
            throw new InvalidOperationException(
                "Sistemde Kullanıcı Yönetimi yetkisi olan en az bir aktif kullanıcı kalmalı — "
                + "son yöneticinin rolünü/erişimini kaldıramazsınız. Önce başka bir kullanıcıya "
                + "bu yetkiyi verin.");
        }

        string? passwordHash = null;
        if (!string.IsNullOrWhiteSpace(request.Password))
            passwordHash = BCrypt.Net.BCrypt.HashPassword(request.Password, workFactor: 11);

        var affected = await connection.ExecuteAsync(@"
            UPDATE AppUsers SET
                FullName     = @FullName,
                Email        = @Email,
                Role         = @Role,
                IsActive     = @IsActive,
                PasswordHash = COALESCE(@PasswordHash, PasswordHash)
            WHERE Id = @Id",
            new
            {
                Id = id,
                request.FullName,
                request.Email,
                Role = newRole,
                request.IsActive,
                PasswordHash = passwordHash,
            });

        return affected > 0;
    }

    // ─── Kullanıcı sil (Admin) ───
    public async Task<bool> DeleteUserAsync(int id)
    {
        using var connection = new SqlConnection(_connectionString);
        var affected = await connection.ExecuteAsync(
            "DELETE FROM AppUsers WHERE Id = @Id", new { Id = id });
        return affected > 0;
    }

    // ════════════════════════ İnce yetki (hibrit) ════════════════════════

    // Effective = rolün varsayılan seti + kullanıcı override'ları.
    private static HashSet<string> ComputeEffective(
        string role, IEnumerable<PermissionOverrideDto> overrides)
    {
        var eff = AppPermissions.DefaultsFor(role);
        foreach (var o in overrides)
        {
            if (!AppPermissions.IsValid(o.Key)) continue;
            if (o.Granted) eff.Add(o.Key);
            else eff.Remove(o.Key);
        }
        return eff;
    }

    private async Task<List<PermissionOverrideDto>> ReadOverridesAsync(
        SqlConnection connection, int userId, SqlTransaction? tx = null)
    {
        var rows = await connection.QueryAsync<PermissionOverrideDto>(
            "SELECT PermissionKey AS [Key], Granted FROM UserPermissions WHERE UserId = @UserId",
            new { UserId = userId }, tx);
        return rows.ToList();
    }

    // Verilen kullanıcı HARİÇ, effective "manage_users" yetkisi olan aktif kullanıcı var mı?
    private async Task<bool> AnyOtherActiveManagerAsync(
        SqlConnection connection, int excludeId, SqlTransaction? tx = null)
    {
        var users = await connection.QueryAsync<AppUser>(
            "SELECT * FROM AppUsers WHERE IsActive = 1 AND Id <> @Id",
            new { Id = excludeId }, tx);
        var rows = await connection.QueryAsync<UserPermRow>(
            "SELECT UserId, PermissionKey AS [Key], Granted FROM UserPermissions",
            transaction: tx);
        var byUser = rows.GroupBy(r => r.UserId).ToDictionary(g => g.Key, g => g.ToList());

        foreach (var u in users)
        {
            var ovs = byUser.TryGetValue(u.Id, out var list)
                ? list.Select(x => new PermissionOverrideDto { Key = x.Key, Granted = x.Granted })
                : Enumerable.Empty<PermissionOverrideDto>();
            if (ComputeEffective(u.Role, ovs).Contains(AppPermissions.ManageUsers))
                return true;
        }
        return false;
    }

    // ─── Kullanıcının yetki tablosu: rol varsayılanı + override + effective ───
    public async Task<UserPermissionsResponse?> GetUserPermissionsAsync(int id)
    {
        using var connection = new SqlConnection(_connectionString);
        var user = await connection.QueryFirstOrDefaultAsync<AppUser>(
            "SELECT * FROM AppUsers WHERE Id = @Id", new { Id = id });
        if (user == null) return null;

        var overrides = await ReadOverridesAsync(connection, id);
        var ovMap = overrides.ToDictionary(o => o.Key, o => o.Granted);
        var defaults = AppPermissions.DefaultsFor(user.Role);

        var items = AppPermissions.All.Select(key =>
        {
            bool def = defaults.Contains(key);
            bool? ov = ovMap.TryGetValue(key, out var g) ? g : (bool?)null;
            return new PermissionItem
            {
                Key = key,
                Default = def,
                Override = ov,
                Effective = ov ?? def,
            };
        }).ToList();

        return new UserPermissionsResponse { Role = user.Role, Items = items };
    }

    // ─── Kullanıcının override'larını topluca ayarla (rol varsayılanı sabit) ───
    public async Task<bool> SetUserPermissionsAsync(int id, SetUserPermissionsRequest request)
    {
        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();

        var user = await connection.QueryFirstOrDefaultAsync<AppUser>(
            "SELECT * FROM AppUsers WHERE Id = @Id", new { Id = id });
        if (user == null) return false;

        // Geçerli anahtar + rol varsayılanından FARKLI kararları sakla (gerisi gereksiz).
        var defaults = AppPermissions.DefaultsFor(user.Role);
        var cleaned = request.Overrides
            .Where(o => AppPermissions.IsValid(o.Key))
            .GroupBy(o => o.Key).Select(g => g.Last())
            .Where(o => defaults.Contains(o.Key) != o.Granted)
            .ToList();

        // Son yönetici koruması: bu değişiklik son manage_users'ı kaldırıyorsa engelle.
        var eff = ComputeEffective(user.Role, cleaned);
        bool willManage = user.IsActive && eff.Contains(AppPermissions.ManageUsers);
        if (!willManage && !await AnyOtherActiveManagerAsync(connection, id))
        {
            throw new InvalidOperationException(
                "Bu değişiklik sistemdeki son Kullanıcı Yönetimi yetkisini kaldırır — "
                + "önce başka bir kullanıcıya bu yetkiyi verin.");
        }

        using var tx = connection.BeginTransaction();
        await connection.ExecuteAsync(
            "DELETE FROM UserPermissions WHERE UserId = @Id", new { Id = id }, tx);
        if (cleaned.Count > 0)
        {
            await connection.ExecuteAsync(
                @"INSERT INTO UserPermissions (UserId, PermissionKey, Granted)
                  VALUES (@UserId, @Key, @Granted)",
                cleaned.Select(o => new { UserId = id, o.Key, o.Granted }), tx);
        }
        tx.Commit();
        return true;
    }

    private class UserPermRow
    {
        public int UserId { get; set; }
        public string Key { get; set; } = "";
        public bool Granted { get; set; }
    }
}