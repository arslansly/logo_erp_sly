using System.Data;
using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// Taslak irsaliye CRUD'u — dbo.ShipmentDrafts + dbo.ShipmentDraftLines.
// LOGO STFICHE'ye aktarım stub (TODO: gerçek transfer mantığı kullanıcı LOGO
// entegrasyon stratejisini belirleyince yazılır). InvoiceDraftService ile paralel.
public class ShipmentDraftService
{
    private readonly string _connectionString;

    public ShipmentDraftService(IConfiguration configuration)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
    }

    // Taslak listesi — sadece durum + arama + sayfalama. Irsaliye DTO'su döner
    // (IsDraft=true, DraftStatus dolu) — liste ekranı LOGO irsaliyesiyle aynı kartı kullanır.
    public async Task<IEnumerable<Irsaliye>> GetAllAsync(
        string? status = null,
        int offset = 0,
        int limit = 50,
        string? search = null)
    {
        var sql = @"
            SELECT
                d.Id, d.FicheNo, d.DocCode, d.[Date], d.TrCode,
                d.ClientRef, d.ClientCode, d.ClientTitle AS ClientTitle,
                d.NetTotal,
                CAST(NULL AS INT)       AS InvoiceRef,
                ''                      AS InvNo,
                0                       AS Billed,
                0                       AS Cancelled,
                d.[Status]              AS DraftStatus,
                d.LastError             AS LastError,
                d.ApprovalStatus        AS ApprovalStatus
            FROM dbo.ShipmentDrafts d
            WHERE (@Status IS NULL OR d.[Status] = @Status)
              AND (@Search IS NULL
                   OR d.FicheNo    LIKE '%' + @Search + '%'
                   OR d.DocCode    LIKE '%' + @Search + '%'
                   OR d.ClientCode LIKE '%' + @Search + '%'
                   OR d.ClientTitle LIKE '%' + @Search + '%')
            ORDER BY d.CreatedAt DESC, d.Id DESC
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var taslaklar = (await connection.QueryAsync<Irsaliye>(sql, new
            {
                Status = status,
                Search = search,
                Offset = offset,
                Limit = limit
            })).ToList();

            foreach (var t in taslaklar)
            {
                t.TrCodeName = StokTrCodeMapper.GetName(t.TrCode, isInvoice: false);
                t.IsDraft = true;
            }
            return taslaklar;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[ShipmentDraftService.GetAllAsync] HATA: {ex}");
            throw new Exception($"Taslak listesi alınamadı: {ex.Message}");
        }
    }

    // Tek taslak — header + satırlar
    public async Task<ShipmentDraft?> GetByIdAsync(int id)
    {
        var headerSql = "SELECT * FROM dbo.ShipmentDrafts WHERE Id = @Id";
        var linesSql = @"SELECT * FROM dbo.ShipmentDraftLines
                         WHERE DraftId = @Id ORDER BY [LineNo]";

        using var connection = new SqlConnection(_connectionString);
        using var multi = await connection.QueryMultipleAsync(
            headerSql + "; " + linesSql, new { Id = id });

        var draft = await multi.ReadFirstOrDefaultAsync<ShipmentDraft>();
        if (draft == null) return null;
        draft.Lines = (await multi.ReadAsync<ShipmentDraftLine>()).ToList();
        return draft;
    }

    // Yeni taslak — header + satırlar tek transaction
    public async Task<int> CreateAsync(ShipmentDraft draft, string createdBy)
    {
        draft.CreatedBy = createdBy;
        draft.Status = "Draft";
        draft.CreatedAt = DateTime.Now;
        draft.UpdatedAt = DateTime.Now;

        var headerSql = @"
            INSERT INTO dbo.ShipmentDrafts
                (TrCode, FicheNo, DocCode, [Date],
                 ClientRef, ClientCode, ClientTitle,
                 SourceIndex, DestIndex, ShipInfoCode,
                 GrossTotal, TotalDiscounts, TotalVat, NetTotal,
                 CurrencyType, ExchangeRate,
                 GenExp1, GenExp2,
                 [Status], CreatedBy, CreatedAt, UpdatedAt)
            VALUES
                (@TrCode, @FicheNo, @DocCode, @Date,
                 @ClientRef, @ClientCode, @ClientTitle,
                 @SourceIndex, @DestIndex, @ShipInfoCode,
                 @GrossTotal, @TotalDiscounts, @TotalVat, @NetTotal,
                 @CurrencyType, @ExchangeRate,
                 @GenExp1, @GenExp2,
                 @Status, @CreatedBy, @CreatedAt, @UpdatedAt);
            SELECT CAST(SCOPE_IDENTITY() AS INT);";

        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        using var tx = connection.BeginTransaction();
        try
        {
            var newId = await connection.QuerySingleAsync<int>(headerSql, draft, tx);
            await InsertLinesAsync(connection, tx, newId, draft.Lines);
            tx.Commit();
            return newId;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    // Güncelle — basit yaklaşım: tüm satırları sil + yeniden ekle
    public async Task<bool> UpdateAsync(int id, ShipmentDraft draft)
    {
        var existing = await GetByIdAsync(id);
        if (existing == null) return false;
        if (existing.Status == "Transferred")
            throw new InvalidOperationException("Aktarılmış taslak düzenlenemez");

        draft.UpdatedAt = DateTime.Now;

        var headerSql = @"
            UPDATE dbo.ShipmentDrafts SET
                TrCode = @TrCode,
                FicheNo = @FicheNo,
                DocCode = @DocCode,
                [Date] = @Date,
                ClientRef = @ClientRef,
                ClientCode = @ClientCode,
                ClientTitle = @ClientTitle,
                SourceIndex = @SourceIndex,
                DestIndex = @DestIndex,
                ShipInfoCode = @ShipInfoCode,
                GrossTotal = @GrossTotal,
                TotalDiscounts = @TotalDiscounts,
                TotalVat = @TotalVat,
                NetTotal = @NetTotal,
                CurrencyType = @CurrencyType,
                ExchangeRate = @ExchangeRate,
                GenExp1 = @GenExp1,
                GenExp2 = @GenExp2,
                [Status] = 'Draft',
                LastError = NULL,
                UpdatedAt = @UpdatedAt
            WHERE Id = @Id";

        using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        using var tx = connection.BeginTransaction();
        try
        {
            await connection.ExecuteAsync(headerSql, new
            {
                draft.TrCode, draft.FicheNo, draft.DocCode, draft.Date,
                draft.ClientRef, draft.ClientCode, draft.ClientTitle,
                draft.SourceIndex, draft.DestIndex, draft.ShipInfoCode,
                draft.GrossTotal, draft.TotalDiscounts, draft.TotalVat, draft.NetTotal,
                draft.CurrencyType, draft.ExchangeRate,
                draft.GenExp1, draft.GenExp2,
                draft.UpdatedAt,
                Id = id
            }, tx);

            await connection.ExecuteAsync(
                "DELETE FROM dbo.ShipmentDraftLines WHERE DraftId = @Id",
                new { Id = id }, tx);
            await InsertLinesAsync(connection, tx, id, draft.Lines);

            tx.Commit();
            return true;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    // Sil — satırlar CASCADE ile gider
    public async Task<bool> DeleteAsync(int id)
    {
        using var connection = new SqlConnection(_connectionString);
        var affected = await connection.ExecuteAsync(
            "DELETE FROM dbo.ShipmentDrafts WHERE Id = @Id AND [Status] != 'Transferred'",
            new { Id = id });
        return affected > 0;
    }

    // -----------------------------------------------------------------------
    // LOGO'YA AKTARIM (TODO)
    //
    // Bu metod şu an STUB. LOGO STFICHE/STLINE'a doğru ve güvenli yazma yöntemi
    // netleşince gerçek implementasyon eklenecek (InvoiceDraftService ile aynı strateji).
    // Şu an: durum 'Failed', LastError doldurulur. Mobil UI bunu Hatalı sekmesinde
    // gösterir, kullanıcı taslağı düzenleyip tekrar deneyebilir.
    // -----------------------------------------------------------------------
    public async Task<(bool ok, string? error, int? newShipmentId)> TransferToLogoAsync(int draftId)
    {
        var draft = await GetByIdAsync(draftId);
        if (draft == null)
            return (false, "Taslak bulunamadı", null);
        if (draft.Status == "Transferred")
            return (false, "Bu taslak zaten LOGO'ya aktarılmış", draft.TransferredShipmentId);

        const string error = "LOGO aktarım modülü henüz aktif değil. " +
            "Taslak kaydedildi, aktarım stratejisi (REST API / SP / manuel INSERT) belirlenince devreye girecek.";

        using var connection = new SqlConnection(_connectionString);
        await connection.ExecuteAsync(@"
            UPDATE dbo.ShipmentDrafts SET
                [Status] = 'Failed',
                LastError = @Error,
                UpdatedAt = GETDATE()
            WHERE Id = @Id",
            new { Id = draftId, Error = error });

        return (false, error, null);
    }

    // Toplu aktarım — sırayla TransferToLogoAsync çağırır, sonuçları toplar
    public async Task<BatchTransferResult> TransferBatchAsync(IEnumerable<int> draftIds)
    {
        var result = new BatchTransferResult();
        foreach (var id in draftIds)
        {
            var (ok, error, newId) = await TransferToLogoAsync(id);
            if (ok) result.Basarili.Add(new TransferOk { DraftId = id, InvoiceId = newId!.Value });
            else result.Basarisiz.Add(new TransferFail { DraftId = id, Hata = error ?? "Bilinmeyen hata" });
        }
        return result;
    }

    // ── private helpers ──
    private static async Task InsertLinesAsync(
        SqlConnection connection, IDbTransaction tx, int draftId, List<ShipmentDraftLine> lines)
    {
        if (lines.Count == 0) return;

        const string sql = @"
            INSERT INTO dbo.ShipmentDraftLines
                (DraftId, [LineNo], LineType,
                 StockRef, StockCode, StockName,
                 UomRef, UomCode,
                 Amount, Price, VatRate, Discount,
                 Total, VatAmount, LineNet, LineDescription)
            VALUES
                (@DraftId, @LineNo, @LineType,
                 @StockRef, @StockCode, @StockName,
                 @UomRef, @UomCode,
                 @Amount, @Price, @VatRate, @Discount,
                 @Total, @VatAmount, @LineNet, @LineDescription)";

        var lineNo = 1;
        foreach (var ln in lines)
        {
            ln.DraftId = draftId;
            ln.LineNo = lineNo++;
            await connection.ExecuteAsync(sql, ln, tx);
        }
    }
}
