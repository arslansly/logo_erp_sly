using System.Globalization;
using System.Text;
using System.Text.Json;
using LogoMobileApi.Models;

namespace LogoMobileApi.Services;

/// <summary>
/// Yapay zeka asistanı. Anthropic Claude Messages API'sini "tool use" (function
/// calling) ile çağırır. Model gerekli tool'ları çağırır; backend bu tool'ları
/// mevcut LOGO servisleriyle çalıştırır ve sonucu modele geri verir. Model nihai
/// Türkçe cevabı üretir. "Fatura/sipariş hazırla" tool'ları YAN ETKİSİZDİR —
/// kayıt oluşturmaz, sadece formu ön-doldurmak için AiAction döndürür.
/// </summary>
public class AiService
{
    private readonly HttpClient _http;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly int _maxTokens;

    private readonly CariService _cariService;
    private readonly MalzemeService _malzemeService;
    private readonly RaporService _raporService;
    private readonly DashboardService _dashboardService;

    // Sonsuz döngü koruması — model en fazla bu kadar tur tool çağırabilir.
    private const int MaxTurns = 6;

    private const string AnthropicVersion = "2023-06-01";
    private const string ApiUrl = "https://api.anthropic.com/v1/messages";

    public AiService(
        HttpClient http,
        IConfiguration configuration,
        CariService cariService,
        MalzemeService malzemeService,
        RaporService raporService,
        DashboardService dashboardService)
    {
        _http = http;
        _apiKey = configuration["AiSettings:ApiKey"] ?? "";
        _model = configuration["AiSettings:Model"] ?? "claude-sonnet-4-6";
        _maxTokens = int.TryParse(configuration["AiSettings:MaxTokens"], out var mt) ? mt : 1024;

        _cariService = cariService;
        _malzemeService = malzemeService;
        _raporService = raporService;
        _dashboardService = dashboardService;
    }

    public async Task<AiChatResponse> ChatAsync(AiChatRequest request)
    {
        if (string.IsNullOrWhiteSpace(_apiKey))
        {
            return new AiChatResponse
            {
                Reply = "Yapay zeka servisi yapılandırılmamış (API anahtarı eksik). " +
                        "Lütfen sistem yöneticisiyle görüşün."
            };
        }

        // ─── Mesaj geçmişini Anthropic formatına çevir ───
        var messages = new List<object>();
        foreach (var m in request.History)
        {
            var role = m.Role == "assistant" ? "assistant" : "user";
            messages.Add(new { role, content = m.Text });
        }
        messages.Add(new { role = "user", content = request.Message });

        AiAction? pendingAction = null;

        // ─── Tool-use döngüsü ───
        for (var turn = 0; turn < MaxTurns; turn++)
        {
            using var doc = await CallAnthropicAsync(messages);
            var root = doc.RootElement;

            var stopReason = root.TryGetProperty("stop_reason", out var sr) ? sr.GetString() : null;
            var contentArr = root.GetProperty("content");

            // Modelin bu turdaki içeriğini (metin + tool_use blokları) assistant mesajı
            // olarak geçmişe ekle — bir sonraki tura aynen geri göndereceğiz.
            var assistantContent = new List<object>();
            var toolUses = new List<(string id, string name, JsonElement input)>();
            var textBuf = new StringBuilder();

            foreach (var block in contentArr.EnumerateArray())
            {
                var type = block.GetProperty("type").GetString();
                if (type == "text")
                {
                    var t = block.GetProperty("text").GetString() ?? "";
                    textBuf.Append(t);
                    assistantContent.Add(new { type = "text", text = t });
                }
                else if (type == "tool_use")
                {
                    var id = block.GetProperty("id").GetString()!;
                    var name = block.GetProperty("name").GetString()!;
                    var input = block.GetProperty("input");
                    toolUses.Add((id, name, input));
                    assistantContent.Add(new
                    {
                        type = "tool_use",
                        id,
                        name,
                        input = JsonSerializer.Deserialize<object>(input.GetRawText())
                    });
                }
            }

            messages.Add(new { role = "assistant", content = assistantContent });

            // Tool çağrısı yoksa → bu nihai cevap.
            if (stopReason != "tool_use" || toolUses.Count == 0)
            {
                return new AiChatResponse
                {
                    Reply = textBuf.ToString().Trim(),
                    Action = pendingAction
                };
            }

            // Tool'ları çalıştır ve sonuçları tek bir user mesajında topla.
            var toolResults = new List<object>();
            foreach (var (id, name, input) in toolUses)
            {
                string resultJson;
                try
                {
                    resultJson = await ExecuteToolAsync(name, input, a => pendingAction = a);
                }
                catch (Exception ex)
                {
                    resultJson = JsonSerializer.Serialize(new { hata = ex.Message });
                }

                toolResults.Add(new
                {
                    type = "tool_result",
                    tool_use_id = id,
                    content = resultJson
                });
            }

            messages.Add(new { role = "user", content = toolResults });
        }

        // Tur limiti aşıldı.
        return new AiChatResponse
        {
            Reply = "İşlemi tamamlayamadım, lütfen isteğinizi biraz daha basit ifade edin.",
            Action = pendingAction
        };
    }

    // ─── Anthropic API çağrısı ───
    private async Task<JsonDocument> CallAnthropicAsync(List<object> messages)
    {
        var body = new
        {
            model = _model,
            max_tokens = _maxTokens,
            system = SystemPrompt(),
            tools = ToolDefinitions(),
            messages
        };

        var json = JsonSerializer.Serialize(body);
        using var req = new HttpRequestMessage(HttpMethod.Post, ApiUrl)
        {
            Content = new StringContent(json, Encoding.UTF8, "application/json")
        };
        req.Headers.Add("x-api-key", _apiKey);
        req.Headers.Add("anthropic-version", AnthropicVersion);

        var resp = await _http.SendAsync(req);
        var respBody = await resp.Content.ReadAsStringAsync();

        if (!resp.IsSuccessStatusCode)
        {
            Console.WriteLine($"[AiService] Anthropic hata {(int)resp.StatusCode}: {respBody}");
            throw new Exception("Yapay zeka servisine ulaşılamadı.");
        }

        return JsonDocument.Parse(respBody);
    }

    // ─── Tool yürütme ───
    private async Task<string> ExecuteToolAsync(string name, JsonElement input, Action<AiAction> setAction)
    {
        switch (name)
        {
            case "cari_ara":
            {
                var search = GetString(input, "search");
                var list = await _cariService.GetAllAsync(0, 10, search);
                var sonuc = list.Select(c => new
                {
                    id = c.Id,
                    kod = c.Code,
                    unvan = c.Title,
                    bakiye = c.Balance
                });
                return JsonSerializer.Serialize(new { sonuclar = sonuc });
            }

            case "cari_bakiye":
            {
                var id = GetInt(input, "cariId");
                var cari = await _cariService.GetByIdAsync(id);
                if (cari == null) return JsonSerializer.Serialize(new { hata = "Cari bulunamadı." });
                return JsonSerializer.Serialize(new
                {
                    id = cari.Id,
                    kod = cari.Code,
                    unvan = cari.Title,
                    bakiye = cari.Balance,
                    // Pozitif = müşteri bize borçlu (alacağımız), negatif = biz borçluyuz.
                    durum = cari.Balance >= 0 ? "borçlu (bizim alacağımız)" : "alacaklı (bizim borcumuz)"
                });
            }

            case "malzeme_ara":
            {
                var search = GetString(input, "search");
                var list = await _malzemeService.GetAllAsync(0, 10, search);
                var sonuc = list.Select(m => new
                {
                    id = m.Id,
                    kod = m.Kod,
                    ad = m.Ad,
                    birim = m.Birim,
                    fiiliStok = m.FiiliStok
                });
                return JsonSerializer.Serialize(new { sonuclar = sonuc });
            }

            case "malzeme_detay":
            {
                var id = GetInt(input, "malzemeId");
                var m = await _malzemeService.GetByIdAsync(id);
                if (m == null) return JsonSerializer.Serialize(new { hata = "Malzeme bulunamadı." });
                return JsonSerializer.Serialize(new
                {
                    id = m.Id,
                    kod = m.Kod,
                    ad = m.Ad,
                    birim = m.Birim,
                    fiiliStok = m.FiiliStok,
                    gercekStok = m.GercekStok,
                    satisFiyati = m.SatisFiyati,
                    satinalmaFiyati = m.SatinalmaFiyati
                });
            }

            case "stok_durumu":
            {
                var search = GetString(input, "search");
                var stokDurumu = GetString(input, "stokDurumu");
                var list = await _raporService.GetStokAsync(search, null, stokDurumu);
                var sonuc = list.Take(25).Select(s => new
                {
                    kod = s.Kod,
                    ad = s.Ad,
                    birim = s.Birim,
                    fiiliStok = s.FiiliStok,
                    gercekStok = s.GercekStok
                });
                return JsonSerializer.Serialize(new { sonuclar = sonuc });
            }

            case "dashboard_ozet":
            {
                var o = await _dashboardService.GetOzetAsync();
                return JsonSerializer.Serialize(new
                {
                    toplamAlacak = o.ToplamAlacak,
                    vadesiGecen = o.VadesiGecen,
                    bugunTahsilat = o.BugunTahsilat,
                    vadesiGecenCariSayisi = o.VadesiGecenCariSayisi
                });
            }

            case "fatura_hazirla":
                return await PrepareBelgeAsync("fatura", input, setAction);

            case "siparis_hazirla":
                return await PrepareBelgeAsync("siparis", input, setAction);

            default:
                return JsonSerializer.Serialize(new { hata = $"Bilinmeyen araç: {name}" });
        }
    }

    // fatura_hazirla / siparis_hazirla — ortak hazırlama mantığı (YAN ETKİSİZ).
    private async Task<string> PrepareBelgeAsync(string type, JsonElement input, Action<AiAction> setAction)
    {
        var cariId = GetInt(input, "cariId");
        var cari = await _cariService.GetByIdAsync(cariId);
        if (cari == null)
            return JsonSerializer.Serialize(new { hata = "Cari bulunamadı. Önce cari_ara ile doğru cariyi bulun." });

        // tip: "satis" | "satinalma" → LOGO TRCODE. Belirtilmezse satış varsay.
        var tip = (GetString(input, "tip") ?? "satis").ToLowerInvariant();
        var alis = tip.Contains("satinal") || tip.Contains("satınal") ||
                   tip.Contains("alis") || tip.Contains("alış") || tip == "al";
        int trCode = type == "fatura"
            ? (alis ? 31 : 38)   // fatura: 31=Satınalma, 38=Toptan Satış
            : (alis ? 2 : 1);    // sipariş: 2=Satınalma, 1=Satış

        var action = new AiAction
        {
            Type = type,
            TrCode = trCode,
            Cari = new AiCariRef { Id = cari.Id, Kod = cari.Code, Unvan = cari.Title }
        };

        if (type == "siparis")
        {
            var vade = GetString(input, "vade");
            if (!string.IsNullOrWhiteSpace(vade) &&
                DateTime.TryParse(vade, CultureInfo.InvariantCulture, DateTimeStyles.None, out var v))
            {
                action.Vade = v;
            }
        }

        var ozetSatirlar = new List<object>();
        if (input.TryGetProperty("satirlar", out var satirlar) && satirlar.ValueKind == JsonValueKind.Array)
        {
            foreach (var s in satirlar.EnumerateArray())
            {
                var stokRef = GetInt(s, "stokRef");
                if (stokRef <= 0) continue;

                var m = await _malzemeService.GetByIdAsync(stokRef);
                if (m == null) continue;

                var miktar = GetDecimal(s, "miktar") ?? 1m;
                var fiyat = GetDecimal(s, "fiyat"); // null → form tanımlı fiyatı kullanır

                action.Lines.Add(new AiLine
                {
                    StokRef = m.Id,
                    Kod = m.Kod,
                    Ad = m.Ad,
                    Birim = m.Birim,
                    Miktar = miktar,
                    Fiyat = fiyat
                });

                ozetSatirlar.Add(new
                {
                    kod = m.Kod,
                    ad = m.Ad,
                    miktar,
                    fiyat = fiyat,
                    fiiliStok = m.FiiliStok
                });
            }
        }

        setAction(action);

        // Modele özet dön — kayıt oluşturulmadığını net belirt.
        return JsonSerializer.Serialize(new
        {
            durum = "hazirlandi",
            not = "Kayıt OLUŞTURULMADI. Form kullanıcıya ön-dolu açılacak; kullanıcı onaylayıp kaydedecek.",
            belgeTuru = type,
            tip = alis ? "satinalma" : "satis",
            cari = new { kod = cari.Code, unvan = cari.Title },
            satirlar = ozetSatirlar
        });
    }

    // ─── Sistem promptu ───
    private static string SystemPrompt()
    {
        var bugun = DateTime.Today.ToString("yyyy-MM-dd");
        return $@"Sen bir Logo ERP mobil uygulamasının Türkçe yapay zeka asistanısın.
Bugünün tarihi: {bugun}. Kullanıcı bir muhasebe/satış kullanıcısıdır.

GÖREVİN: Kullanıcının doğal dildeki isteğini anla ve uygun araçları (tool) kullanarak
ya bilgi getir ya da bir belge (fatura/sipariş) hazırla.

ARAÇLAR:
- cari_ara: müşteri/tedarikçi (cari) ismi veya koduyla arar.
- cari_bakiye: bir carinin güncel bakiyesini getirir.
- malzeme_ara: ürün/malzeme (stok) ismi veya koduyla arar.
- malzeme_detay: bir malzemenin stok ve fiyat detayını getirir.
- stok_durumu: stok raporu (isteğe bağlı arama / 'var'/'yok' filtresi).
- dashboard_ozet: toplam alacak, vadesi geçen, bugünkü tahsilat özeti.
- fatura_hazirla: SATIŞ FATURASI formunu ön-doldurur. KAYIT OLUŞTURMAZ.
- siparis_hazirla: SİPARİŞ formunu ön-doldurur. KAYIT OLUŞTURMAZ.

KURALLAR:
1. Bir cariye fatura/sipariş hazırlamadan ÖNCE cari_ara ile cariyi bul (cariId'yi öğren).
   Ürün satırı varsa malzeme_ara ile stokRef'i bul.
2. Arama birden fazla sonuç döndürürse KULLANICIYA hangisini kastettiğini SOR; tahmin etme.
   Hiç sonuç yoksa kullanıcıya bulunamadığını söyle.
3. BELGE TÜRÜ (tip): fatura/sipariş hazırlarken 'tip' alanını mutlaka belirle:
   - 'sat', 'satış', 'fatura kes', 'müşteriye' → tip='satis' (biz satıyoruz).
   - 'al', 'alış', 'satınalma', 'tedarikçiden', 'sipariş ver' → tip='satinalma' (biz alıyoruz).
   - Hangisi olduğu CÜMLEDEN AÇIKÇA anlaşılMIYORSA aracı çağırmadan ÖNCE kullanıcıya
     ""Satış mı satınalma mı?"" diye SOR. Belliyse sorma, doğrudan o tiple devam et.
4. fatura_hazirla/siparis_hazirla SADECE formu ön-doldurur; kaydı kullanıcı yapar.
   Bu araçları çağırdıktan sonra kullanıcıya kısa bir onay mesajı ver (ör.
   ""Doğrunet için 5 adet X içeren satış faturası hazırladım, açmak için butona dokunun"").
5. Fiyat belirtilmemişse fatura/sipariş satırında fiyatı boş bırak (form tanımlı fiyatı getirir).
6. Cevapların KISA, net ve Türkçe olsun. Para ve miktarları okunur biçimde yaz.
7. Sadece eldeki araçlarla yapılabilecek işleri yap; emin değilsen kullanıcıya sor.";
    }

    // ─── Tool tanımları (Anthropic input_schema) ───
    private static object[] ToolDefinitions() => new object[]
    {
        new
        {
            name = "cari_ara",
            description = "Müşteri/tedarikçi (cari) ismi veya koduyla arar. Sonuç olarak id, kod, ünvan ve bakiye döner.",
            input_schema = new
            {
                type = "object",
                properties = new { search = new { type = "string", description = "Cari ismi veya kodu" } },
                required = new[] { "search" }
            }
        },
        new
        {
            name = "cari_bakiye",
            description = "Bir carinin güncel bakiyesini getirir. Önce cari_ara ile id öğrenilmelidir.",
            input_schema = new
            {
                type = "object",
                properties = new { cariId = new { type = "integer", description = "Cari id (LOGICALREF)" } },
                required = new[] { "cariId" }
            }
        },
        new
        {
            name = "malzeme_ara",
            description = "Ürün/malzeme (stok) ismi veya koduyla arar. Sonuç olarak id, kod, ad, birim ve fiili stok döner.",
            input_schema = new
            {
                type = "object",
                properties = new { search = new { type = "string", description = "Malzeme ismi veya kodu" } },
                required = new[] { "search" }
            }
        },
        new
        {
            name = "malzeme_detay",
            description = "Bir malzemenin stok ve fiyat detayını getirir. Önce malzeme_ara ile id öğrenilmelidir.",
            input_schema = new
            {
                type = "object",
                properties = new { malzemeId = new { type = "integer", description = "Malzeme id (LOGICALREF)" } },
                required = new[] { "malzemeId" }
            }
        },
        new
        {
            name = "stok_durumu",
            description = "Stok durum raporu. İsteğe bağlı arama metni ve stok filtresi alır.",
            input_schema = new
            {
                type = "object",
                properties = new
                {
                    search = new { type = "string", description = "Opsiyonel: ürün ismi/kodu" },
                    stokDurumu = new { type = "string", description = "Opsiyonel: 'var' (stoğu olanlar) veya 'yok'" }
                },
                required = Array.Empty<string>()
            }
        },
        new
        {
            name = "dashboard_ozet",
            description = "Genel özet: toplam alacak, vadesi geçen tutar, bugünkü tahsilat, vadesi geçen cari sayısı.",
            input_schema = new
            {
                type = "object",
                properties = new { },
                required = Array.Empty<string>()
            }
        },
        new
        {
            name = "fatura_hazirla",
            description = "FATURA formunu ön-doldurur (kayıt OLUŞTURMAZ). cariId, tip (satis/satinalma) ve satırlar (stokRef + miktar, opsiyonel fiyat) alır.",
            input_schema = new
            {
                type = "object",
                properties = new
                {
                    cariId = new { type = "integer", description = "Cari id (cari_ara'dan)" },
                    tip = new
                    {
                        type = "string",
                        @enum = new[] { "satis", "satinalma" },
                        description = "Fatura türü: 'satis' (biz satıyoruz) veya 'satinalma' (biz alıyoruz). Belirsizse kullanıcıya SOR."
                    },
                    satirlar = new
                    {
                        type = "array",
                        description = "Fatura satırları",
                        items = new
                        {
                            type = "object",
                            properties = new
                            {
                                stokRef = new { type = "integer", description = "Malzeme id (malzeme_ara'dan)" },
                                miktar = new { type = "number", description = "Miktar (varsayılan 1)" },
                                fiyat = new { type = "number", description = "Opsiyonel birim fiyat; boşsa tanımlı fiyat kullanılır" }
                            },
                            required = new[] { "stokRef" }
                        }
                    }
                },
                required = new[] { "cariId" }
            }
        },
        new
        {
            name = "siparis_hazirla",
            description = "SİPARİŞ formunu ön-doldurur (kayıt OLUŞTURMAZ). cariId, tip (satis/satinalma), satırlar ve opsiyonel vade alır.",
            input_schema = new
            {
                type = "object",
                properties = new
                {
                    cariId = new { type = "integer", description = "Cari id (cari_ara'dan)" },
                    tip = new
                    {
                        type = "string",
                        @enum = new[] { "satis", "satinalma" },
                        description = "Sipariş türü: 'satis' (müşteri siparişi) veya 'satinalma' (tedarikçiye sipariş). Belirsizse kullanıcıya SOR."
                    },
                    vade = new { type = "string", description = "Opsiyonel vade tarihi (yyyy-MM-dd)" },
                    satirlar = new
                    {
                        type = "array",
                        description = "Sipariş satırları",
                        items = new
                        {
                            type = "object",
                            properties = new
                            {
                                stokRef = new { type = "integer", description = "Malzeme id (malzeme_ara'dan)" },
                                miktar = new { type = "number", description = "Miktar (varsayılan 1)" },
                                fiyat = new { type = "number", description = "Opsiyonel birim fiyat; boşsa tanımlı fiyat kullanılır" }
                            },
                            required = new[] { "stokRef" }
                        }
                    }
                },
                required = new[] { "cariId" }
            }
        }
    };

    // ─── JSON yardımcıları ───
    private static string? GetString(JsonElement el, string prop) =>
        el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static int GetInt(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return 0;
        return v.ValueKind switch
        {
            JsonValueKind.Number => v.TryGetInt32(out var i) ? i : 0,
            JsonValueKind.String => int.TryParse(v.GetString(), out var i) ? i : 0,
            _ => 0
        };
    }

    private static decimal? GetDecimal(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return null;
        return v.ValueKind switch
        {
            JsonValueKind.Number => v.TryGetDecimal(out var d) ? d : null,
            JsonValueKind.String => decimal.TryParse(v.GetString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : null,
            _ => null
        };
    }
}
