﻿using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

public class CariService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public CariService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // Tüm carileri getir + bakiye (GNTOTCL view'ından) — sayfalı + aranabilir
    public async Task<IEnumerable<Cari>> GetAllAsync(int offset = 0, int limit = 50, string? search = null)
    {
        var sql = $@"
            SELECT
                clc.LOGICALREF   AS Id,
                clc.CODE         AS Code,
                clc.DEFINITION_  AS Title,
                clc.CITY         AS City,
                clc.TELNRS1      AS Phone,
                -- ISPERSCOMP=1 → şahıs şirketi → e-Arşiv mükellefi (2). Aksi 0.
                CASE WHEN ISNULL(clc.ISPERSCOMP, 0) = 1 THEN 2 ELSE 1 END AS EInvoiceType,
                ISNULL((
                    SELECT SUM(gt.DEBIT - gt.CREDIT)
                    FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL gt WITH(NOLOCK)
                    WHERE gt.CARDREF = clc.LOGICALREF
                      AND gt.TOTTYP IN (1)
                ), 0) AS Balance
            FROM LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
            WHERE clc.ACTIVE = 0
              -- Logo'nun sistemsel boş cari kaydı (LOGICALREF=1, CODE=CHAR(255)='ÿ') gerçek cari değil
              AND clc.LOGICALREF <> 1
              AND clc.CODE <> CHAR(255)
              AND (@Search IS NULL
                   OR clc.CODE LIKE '%' + @Search + '%'
                   OR clc.DEFINITION_ LIKE '%' + @Search + '%'
                   OR clc.CITY LIKE '%' + @Search + '%')
            ORDER BY clc.DEFINITION_
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryAsync<Cari>(sql, new { Search = search, Offset = offset, Limit = limit });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[CariService.GetAllAsync] Hata: {ex.Message}");
            throw new Exception("Cari listesi alınamadı");
        }
    }

    // Tek bir cari + bakiye
    public async Task<Cari?> GetByIdAsync(int id)
    {
        var sql = $@"
        SELECT
            clc.LOGICALREF                AS Id,
            clc.CODE                      AS Code,
            clc.DEFINITION_               AS Title,
            clc.CITY                      AS City,
            clc.TELNRS1                   AS Phone,
            ISNULL(clc.TAXNR, '')         AS TaxNumber,
            ISNULL(clc.ADDR1, '')         AS Address,
            ISNULL(clc.EMAILADDR, '')     AS Email,
            ISNULL(clc.COUNTRY, '')       AS Country,
            CASE WHEN ISNULL(clc.ISPERSCOMP, 0) = 1 THEN 2 ELSE 1 END AS EInvoiceType,
            ISNULL((
                SELECT SUM(gt.DEBIT - gt.CREDIT)
                FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL gt WITH(NOLOCK)
                WHERE gt.CARDREF = clc.LOGICALREF
                  AND gt.TOTTYP = 1
            ), 0) AS Balance,
            -- Açık (sevk bekleyen) satış siparişi tutarı — risk göstergesi
            ISNULL((
                SELECT SUM(CASE WHEN l.CLOSED = 0 THEN l.LINENET ELSE 0 END)
                FROM LG_{_firmaNo}_{_donemNo}_ORFICHE o WITH(NOLOCK)
                JOIN LG_{_firmaNo}_{_donemNo}_ORFLINE l WITH(NOLOCK)
                    ON l.ORDFICHEREF = o.LOGICALREF AND l.LINETYPE = 0
                WHERE o.CLIENTREF = clc.LOGICALREF
                  AND o.CANCELLED = 0 AND o.TRCODE = 1 AND o.STATUS IN (3, 4)
            ), 0) AS AcikSiparis,
            -- Kredi/risk limiti (DBSLIMIT1..7 en yükseği) — firma kullanmıyorsa 0 = ""tanımsız""
            CAST((SELECT MAX(v) FROM (VALUES
                (clc.DBSLIMIT1),(clc.DBSLIMIT2),(clc.DBSLIMIT3),(clc.DBSLIMIT4),
                (clc.DBSLIMIT5),(clc.DBSLIMIT6),(clc.DBSLIMIT7)) t(v)) AS decimal(18,2)) AS KrediLimiti,
            CAST(CASE WHEN (clc.DBSRISKCNTRL1 + clc.DBSRISKCNTRL2 + clc.DBSRISKCNTRL3
                          + clc.DBSRISKCNTRL4 + clc.DBSRISKCNTRL5 + clc.DBSRISKCNTRL6
                          + clc.DBSRISKCNTRL7) > 0 THEN 1 ELSE 0 END AS bit) AS RiskKontrolVar
        FROM LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
        WHERE clc.LOGICALREF = @Id";

        using var connection = new SqlConnection(_connectionString);
        var cari = await connection.QueryFirstOrDefaultAsync<Cari>(sql, new { Id = id });
        return cari;
    }
    public async Task<IEnumerable<CariHareket>> GetHareketlerAsync(int cariId)
    {
        var sql = $@"
        SELECT
            f.LOGICALREF                                       AS Id,
            f.DATE_                                            AS Date,
            f.TRCODE                                           AS TransactionType,
            f.LINEEXP                                          AS Description,
            CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE 0 END      AS Debit,
            CASE WHEN f.SIGN = 1 THEN f.AMOUNT ELSE 0 END      AS Credit,
            f.DOCODE                                           AS DocumentNo,
            f.TRANNO                                           AS TransactionNo
        FROM LG_{_firmaNo}_{_donemNo}_CLFLINE f WITH(NOLOCK)
        WHERE f.CLIENTREF = @CariId
          AND f.CANCELLED = 0
        ORDER BY f.DATE_ DESC, f.LOGICALREF DESC";

        using var connection = new SqlConnection(_connectionString);
        var hareketler = await connection.QueryAsync<CariHareket>(sql, new { CariId = cariId });

        foreach (var h in hareketler)
        {
            h.TransactionTypeName = TrCodeMapper.GetName(h.TransactionType);
        }

        return hareketler;
    }

    public async Task<CariVadeAnalizi> GetVadeAnaliziAsync(int cariId)
    {
        var sql = $@"
        SELECT
            @CariId AS CariId,

            -- Vadesi gelmemiş (bugünden ileri)
            ISNULL(SUM(CASE 
                WHEN pt.DATE_ >= CONVERT(date, GETDATE()) 
                THEN (pt.TOTAL - pt.PAID) ELSE 0 
            END), 0) AS VadesiGelmemis,

            -- 1-30 gün geçti
            ISNULL(SUM(CASE 
                WHEN DATEDIFF(day, pt.DATE_, CONVERT(date, GETDATE())) BETWEEN 1 AND 30
                THEN (pt.TOTAL - pt.PAID) ELSE 0 
            END), 0) AS Vadesi_0_30,

            -- 31-60 gün
            ISNULL(SUM(CASE 
                WHEN DATEDIFF(day, pt.DATE_, CONVERT(date, GETDATE())) BETWEEN 31 AND 60
                THEN (pt.TOTAL - pt.PAID) ELSE 0 
            END), 0) AS Vadesi_31_60,

            -- 61-90 gün
            ISNULL(SUM(CASE 
                WHEN DATEDIFF(day, pt.DATE_, CONVERT(date, GETDATE())) BETWEEN 61 AND 90
                THEN (pt.TOTAL - pt.PAID) ELSE 0 
            END), 0) AS Vadesi_61_90,

            -- 90+ gün (kritik)
            ISNULL(SUM(CASE 
                WHEN DATEDIFF(day, pt.DATE_, CONVERT(date, GETDATE())) > 90
                THEN (pt.TOTAL - pt.PAID) ELSE 0 
            END), 0) AS Vadesi_90Plus,

            -- En eski geçen vade tarihi
            MIN(CASE 
                WHEN pt.DATE_ < CONVERT(date, GETDATE()) AND pt.TOTAL > pt.PAID 
                THEN pt.DATE_ 
            END) AS EnEskiVadeTarihi,

            -- En son tahsilat tarihi
            MAX(CASE 
                WHEN pt.SIGN = 1 AND pt.PAID > 0 
                THEN pt.PROCDATE 
            END) AS SonTahsilatTarihi

        FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
        WHERE pt.CARDREF = @CariId
          AND pt.CANCELLED = 0
          AND pt.SIGN = 0          -- müşterinin bize borç satırları
          AND pt.TOTAL > pt.PAID";  // henüz tam ödenmemiş

        using var connection = new SqlConnection(_connectionString);
        var analiz = await connection.QueryFirstOrDefaultAsync<CariVadeAnalizi>(
            sql, new { CariId = cariId });

        if (analiz != null && analiz.EnEskiVadeTarihi.HasValue)
        {
            analiz.EnEskiVadeGunFarki =
                (DateTime.Today - analiz.EnEskiVadeTarihi.Value.Date).Days;
        }

        return analiz ?? new CariVadeAnalizi { CariId = cariId };
    }

    // Cari hesap ekstresi — tarih aralığına göre devir bakiyesi + hareketler + kapanış
    public async Task<CariEkstre> GetEkstreAsync(int cariId, DateTime? baslangic, DateTime? bitis)
    {
        var bas = baslangic?.Date ?? new DateTime(DateTime.Today.Year, 1, 1);
        var bit = bitis?.Date ?? DateTime.Today;
        // bitis tarihini gün sonuna çek ki o günün hareketleri dahil olsun
        var bitInc = bit.AddDays(1).AddTicks(-1);

        var sql = $@"
        -- 1) Devir bakiyesi (başlangıçtan önceki tüm hareketler)
        SELECT ISNULL(SUM(
            CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE -f.AMOUNT END
        ), 0) AS Devir
        FROM LG_{_firmaNo}_{_donemNo}_CLFLINE f WITH(NOLOCK)
        WHERE f.CLIENTREF = @CariId
          AND f.CANCELLED = 0
          AND f.DATE_ < @Baslangic;

        -- 2) Dönem hareketleri
        SELECT
            f.LOGICALREF                                       AS Id,
            f.DATE_                                            AS Tarih,
            f.TRCODE                                           AS IslemTipi,
            ISNULL(f.LINEEXP, '')                              AS Aciklama,
            CASE WHEN f.SIGN = 0 THEN f.AMOUNT ELSE 0 END      AS Borc,
            CASE WHEN f.SIGN = 1 THEN f.AMOUNT ELSE 0 END      AS Alacak,
            ISNULL(f.DOCODE, '')                               AS DocumentNo
        FROM LG_{_firmaNo}_{_donemNo}_CLFLINE f WITH(NOLOCK)
        WHERE f.CLIENTREF = @CariId
          AND f.CANCELLED = 0
          AND f.DATE_ >= @Baslangic
          AND f.DATE_ <= @Bitis
        ORDER BY f.DATE_, f.LOGICALREF;";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            using var multi = await connection.QueryMultipleAsync(
                sql, new { CariId = cariId, Baslangic = bas, Bitis = bitInc });

            var devir = await multi.ReadFirstAsync<decimal>();
            var satirlar = (await multi.ReadAsync<CariEkstreSatir>()).ToList();

            decimal toplamBorc = 0;
            decimal toplamAlacak = 0;
            decimal yuruyen = devir;
            foreach (var s in satirlar)
            {
                s.IslemTipiAdi = TrCodeMapper.GetName(s.IslemTipi);
                yuruyen += s.Borc - s.Alacak;
                s.YurutulenBakiye = yuruyen;
                toplamBorc += s.Borc;
                toplamAlacak += s.Alacak;
            }

            return new CariEkstre
            {
                CariId = cariId,
                BaslangicTarihi = bas,
                BitisTarihi = bit,
                DevirBakiyesi = devir,
                ToplamBorc = toplamBorc,
                ToplamAlacak = toplamAlacak,
                KapanisBakiyesi = devir + toplamBorc - toplamAlacak,
                Hareketler = satirlar,
            };
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[CariService.GetEkstreAsync] Hata: {ex.Message}");
            throw new Exception("Cari ekstresi alınamadı");
        }
    }

    public async Task<VadeOzeti> GetVadeOzetiAsync()
    {
        var sql = $@"
        SELECT
            -- Toplam alacak (tüm cariler net)
            ISNULL((
                SELECT SUM(gt.DEBIT - gt.CREDIT)
                FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL gt WITH(NOLOCK)
                WHERE gt.TOTTYP = 1
            ), 0) AS ToplamAlacak,

            -- Toplam vadesi geçmiş
            ISNULL((
                SELECT SUM(pt.TOTAL - pt.PAID)
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                WHERE pt.CANCELLED = 0
                  AND pt.SIGN = 0
                  AND pt.TOTAL > pt.PAID
                  AND pt.DATE_ < CONVERT(date, GETDATE())
            ), 0) AS ToplamVadesiGecen,

            -- Vadesi geçen cari sayısı (distinct CARDREF)
            ISNULL((
                SELECT COUNT(DISTINCT pt.CARDREF)
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                WHERE pt.CANCELLED = 0
                  AND pt.SIGN = 0
                  AND pt.TOTAL > pt.PAID
                  AND pt.DATE_ < CONVERT(date, GETDATE())
            ), 0) AS VadesiGecenCariSayisi";

        using var connection = new SqlConnection(_connectionString);
        var ozet = await connection.QueryFirstOrDefaultAsync<VadeOzeti>(sql);
        return ozet ?? new VadeOzeti();
    }

}