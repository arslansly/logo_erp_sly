using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// LOGO ORFICHE + ORFLINE üstünden sipariş okuma servisi.
// Yazma akışı (taslak + LOGO'ya aktarım) faz 2'de gelecek — OrderDraftService.
public class SiparisService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public SiparisService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // Sipariş listesi — sayfalama + arama + tarih/cari/tür filtresi.
    // STATUS != 0 (gerçek siparişler), CANCELLED = 0.
    public async Task<IEnumerable<Siparis>> GetAllAsync(
        int offset = 0,
        int limit = 50,
        string? search = null,
        DateTime? baslangic = null,
        DateTime? bitis = null,
        int? trCode = null,
        int? status = null,
        int? cariId = null)
    {
        var sql = $@"
            SELECT
                orf.LOGICALREF                  AS Id,
                ISNULL(orf.FICHENO, '')         AS FicheNo,
                ISNULL(orf.DOCODE, '')          AS DocCode,
                orf.DATE_                       AS Date,
                orf.TRCODE                      AS TrCode,
                orf.CLIENTREF                   AS ClientRef,
                ISNULL(clc.CODE, '')            AS ClientCode,
                ISNULL(clc.DEFINITION_, '')     AS ClientTitle,
                ISNULL(orf.NETTOTAL, 0)         AS NetTotal,
                orf.STATUS                      AS Status,
                orf.CANCELLED                   AS Cancelled,
                0                               AS Closed,  -- ORFICHE'de CLOSED kolonu yok; kapanış satır bazlı (ORFLINE.CLOSED)
                ISNULL(agg.ToplamMiktar, 0)     AS ToplamMiktar,
                ISNULL(agg.SevkMiktar, 0)       AS SevkMiktar,
                ISNULL(agg.BekleyenMiktar, 0)   AS BekleyenMiktar
            FROM LG_{_firmaNo}_{_donemNo}_ORFICHE orf WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = orf.CLIENTREF
            LEFT JOIN (
                SELECT orl.ORDFICHEREF,
                       SUM(orl.AMOUNT) AS ToplamMiktar,
                       SUM(CASE WHEN orl.CLOSED = 1 THEN orl.AMOUNT ELSE orl.SHIPPEDAMOUNT END) AS SevkMiktar,
                       SUM(CASE WHEN orl.CLOSED = 1 THEN 0
                                WHEN (orl.AMOUNT - orl.SHIPPEDAMOUNT) > 0 THEN (orl.AMOUNT - orl.SHIPPEDAMOUNT)
                                ELSE 0 END) AS BekleyenMiktar
                FROM LG_{_firmaNo}_{_donemNo}_ORFLINE orl WITH(NOLOCK)
                WHERE orl.LINETYPE = 0
                GROUP BY orl.ORDFICHEREF
            ) agg ON agg.ORDFICHEREF = orf.LOGICALREF
            WHERE orf.CANCELLED = 0
              AND orf.TRCODE IN (1,2)
              AND (@TrCode IS NULL OR orf.TRCODE = @TrCode)
              AND (@Status IS NULL OR orf.STATUS = @Status)
              AND (@CariId IS NULL OR orf.CLIENTREF = @CariId)
              AND (@Baslangic IS NULL OR orf.DATE_ >= @Baslangic)
              AND (@Bitis     IS NULL OR orf.DATE_ <= @Bitis)
              AND (@Search IS NULL
                   OR orf.FICHENO LIKE '%' + @Search + '%'
                   OR orf.DOCODE  LIKE '%' + @Search + '%'
                   OR clc.CODE    LIKE '%' + @Search + '%'
                   OR clc.DEFINITION_ LIKE '%' + @Search + '%')
            ORDER BY orf.DATE_ DESC, orf.LOGICALREF DESC
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var list = (await connection.QueryAsync<Siparis>(sql, new
            {
                Search = search,
                Baslangic = baslangic?.Date,
                Bitis = bitis?.Date.AddDays(1).AddTicks(-1),
                TrCode = trCode,
                Status = status,
                CariId = cariId,
                Offset = offset,
                Limit = limit
            })).ToList();

            foreach (var s in list)
            {
                s.TrCodeName = OrderCodeMapper.GetTrCodeName(s.TrCode);
                s.StatusName = OrderCodeMapper.GetStatusName(s.Status);
            }
            return list;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[SiparisService.GetAllAsync] Hata: {ex}");
            throw new Exception("Sipariş listesi alınamadı");
        }
    }

    public async Task<Siparis?> GetByIdAsync(int id)
    {
        var sql = $@"
            SELECT
                orf.LOGICALREF                  AS Id,
                ISNULL(orf.FICHENO, '')         AS FicheNo,
                ISNULL(orf.DOCODE, '')          AS DocCode,
                orf.DATE_                       AS Date,
                orf.TRCODE                      AS TrCode,
                orf.CLIENTREF                   AS ClientRef,
                ISNULL(clc.CODE, '')            AS ClientCode,
                ISNULL(clc.DEFINITION_, '')     AS ClientTitle,
                ISNULL(orf.NETTOTAL, 0)         AS NetTotal,
                orf.STATUS                      AS Status,
                orf.CANCELLED                   AS Cancelled,
                0                               AS Closed,  -- ORFICHE'de CLOSED kolonu yok; kapanış satır bazlı (ORFLINE.CLOSED)
                ISNULL(agg.ToplamMiktar, 0)     AS ToplamMiktar,
                ISNULL(agg.SevkMiktar, 0)       AS SevkMiktar,
                ISNULL(agg.BekleyenMiktar, 0)   AS BekleyenMiktar
            FROM LG_{_firmaNo}_{_donemNo}_ORFICHE orf WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = orf.CLIENTREF
            LEFT JOIN (
                SELECT orl.ORDFICHEREF,
                       SUM(orl.AMOUNT) AS ToplamMiktar,
                       SUM(CASE WHEN orl.CLOSED = 1 THEN orl.AMOUNT ELSE orl.SHIPPEDAMOUNT END) AS SevkMiktar,
                       SUM(CASE WHEN orl.CLOSED = 1 THEN 0
                                WHEN (orl.AMOUNT - orl.SHIPPEDAMOUNT) > 0 THEN (orl.AMOUNT - orl.SHIPPEDAMOUNT)
                                ELSE 0 END) AS BekleyenMiktar
                FROM LG_{_firmaNo}_{_donemNo}_ORFLINE orl WITH(NOLOCK)
                WHERE orl.LINETYPE = 0
                GROUP BY orl.ORDFICHEREF
            ) agg ON agg.ORDFICHEREF = orf.LOGICALREF
            WHERE orf.LOGICALREF = @Id";

        using var connection = new SqlConnection(_connectionString);
        var s = await connection.QueryFirstOrDefaultAsync<Siparis>(sql, new { Id = id });
        if (s != null)
        {
            s.TrCodeName = OrderCodeMapper.GetTrCodeName(s.TrCode);
            s.StatusName = OrderCodeMapper.GetStatusName(s.Status);
        }
        return s;
    }

    public async Task<IEnumerable<SiparisSatir>> GetSatirlarAsync(int orderId)
    {
        var sql = $@"
            SELECT
                orl.LOGICALREF                  AS Id,
                ISNULL(orl.LINENO_, 0)          AS [LineNo],
                orl.LINETYPE                    AS LineType,
                orl.STOCKREF                    AS StockRef,
                ISNULL(itm.CODE, '')            AS StockCode,
                ISNULL(itm.NAME, '')            AS StockName,
                ISNULL(usl.CODE, '')            AS UomCode,
                ISNULL(orl.AMOUNT, 0)           AS Amount,
                ISNULL(orl.SHIPPEDAMOUNT, 0)    AS ShippedAmount,
                ISNULL(orl.PRICE, 0)            AS Price,
                ISNULL(orl.VAT, 0)              AS VatRate,
                ISNULL(orl.TOTAL, 0)            AS Total,
                ISNULL(orl.VATAMNT, 0)          AS VatAmount,
                ISNULL(orl.LINENET, 0)          AS LineNet,
                ISNULL(orl.DISTDISC, 0)         AS Discount,
                orl.DUEDATE                     AS DueDate,
                ISNULL(orl.CLOSED, 0)           AS Closed,
                ISNULL(orl.STATUS, 0)           AS Status,
                ISNULL(orl.LINEEXP, '')         AS LineDescription
            FROM LG_{_firmaNo}_{_donemNo}_ORFLINE orl WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_ITEMS itm WITH(NOLOCK)
                ON itm.LOGICALREF = orl.STOCKREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL usl WITH(NOLOCK)
                ON usl.LOGICALREF = orl.UOMREF
            WHERE orl.ORDFICHEREF = @Id
            ORDER BY orl.LINENO_, orl.LOGICALREF";

        using var connection = new SqlConnection(_connectionString);
        var lines = (await connection.QueryAsync<SiparisSatir>(sql, new { Id = orderId })).ToList();
        foreach (var l in lines)
        {
            l.LineTypeName = LineTypeName(l.LineType);
        }
        return lines;
    }

    public async Task<SiparisDetay?> GetDetayAsync(int id)
    {
        var baslik = await GetByIdAsync(id);
        if (baslik == null) return null;

        // GenExp1/GenExp2 ayrı sorgu (Siparis modelinde yok, detayda doldurulur)
        var expSql = $@"
            SELECT ISNULL(GENEXP1, '') AS GenExp1, ISNULL(GENEXP2, '') AS GenExp2
            FROM LG_{_firmaNo}_{_donemNo}_ORFICHE WITH(NOLOCK)
            WHERE LOGICALREF = @Id";
        using var connection = new SqlConnection(_connectionString);
        // Concrete DTO ile oku (Dapper ValueTuple/dynamic mapping kırılgan).
        var exp = await connection.QueryFirstOrDefaultAsync<GenExpRow>(expSql, new { Id = id });

        var satirlar = (await GetSatirlarAsync(id)).ToList();
        var irsaliyeler = (await GetBagliIrsaliyelerAsync(id)).ToList();

        return new SiparisDetay
        {
            Baslik = baslik,
            Satirlar = satirlar,
            Irsaliyeler = irsaliyeler,
            GenExp1 = exp?.GenExp1 ?? "",
            GenExp2 = exp?.GenExp2 ?? "",
        };
    }

    // Bu siparişe bağlı sevkiyatlar (irsaliyeler) — STLINE.ORDFICHEREF üzerinden.
    // Sipariş satırı sevkedildiğinde irsaliye STLINE'ı ORDFICHEREF = ORFICHE.LOGICALREF taşır.
    public async Task<IEnumerable<BagliBelge>> GetBagliIrsaliyelerAsync(int orderId)
    {
        var sql = $@"
            SELECT DISTINCT
                sf.LOGICALREF               AS Id,
                ISNULL(sf.FICHENO, '')      AS FicheNo,
                sf.DATE_                    AS Date,
                sf.TRCODE                   AS TrCode,
                ISNULL(sf.NETTOTAL, 0)      AS Total
            FROM LG_{_firmaNo}_{_donemNo}_STLINE stl WITH(NOLOCK)
            JOIN LG_{_firmaNo}_{_donemNo}_STFICHE sf WITH(NOLOCK)
                ON sf.LOGICALREF = stl.STFICHEREF
            WHERE stl.ORDFICHEREF = @Id
              AND sf.CANCELLED = 0
              AND sf.TRCODE IN (1,2,3,6,7,8)
            ORDER BY sf.DATE_, sf.LOGICALREF";

        using var connection = new SqlConnection(_connectionString);
        var belgeler = (await connection.QueryAsync<BagliBelge>(sql, new { Id = orderId })).ToList();
        foreach (var b in belgeler)
        {
            b.TrCodeName = StokTrCodeMapper.GetName(b.TrCode, isInvoice: false);
        }
        return belgeler;
    }

    // GenExp okuma DTO'su (Dapper concrete mapping).
    private sealed class GenExpRow
    {
        public string? GenExp1 { get; set; }
        public string? GenExp2 { get; set; }
    }

    private static string LineTypeName(int lt) => lt switch
    {
        0 => "Malzeme",
        1 => "Hizmet",
        2 => "Masraf",
        3 => "Promosyon",
        4 => "İskonto",
        _ => $"Tip ({lt})"
    };
}
