using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

/// <summary>
/// Onay iş akışı — satışçının kestiği taslakları (fatura/sipariş/irsaliye) tek
/// birleşik listede toplar; patron/muhasebe onaylar veya reddeder.
/// Onay bekleyen = ApprovalStatus='Pending' AND [Status]='Draft' (henüz aktarılmamış).
/// dbo taslak tablolarında çalışır (LOGO LG_* tablolarına dokunmaz).
/// </summary>
public class OnayService
{
    private readonly string _connectionString;

    public OnayService(IConfiguration configuration)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
    }

    // tip → tablo adı (SQL injection'a karşı yalnızca bilinen değerler kabul edilir).
    private static string? TabloAdi(string tip) => tip switch
    {
        "fatura" => "dbo.InvoiceDrafts",
        "siparis" => "dbo.OrderDrafts",
        "irsaliye" => "dbo.ShipmentDrafts",
        _ => null,
    };

    // ── Onay bekleyen taslaklar (birleşik) ──
    public async Task<IEnumerable<OnayBekleyen>> GetBekleyenlerAsync(string? tip = null)
    {
        // Her tablo için ortak kolonları + sabit Tip string'i seçen bir SELECT.
        string blok(string tablo, string tipAd) => $@"
            SELECT '{tipAd}' AS Tip, d.Id, d.TrCode, d.FicheNo, d.DocCode, d.[Date],
                   d.ClientCode, d.ClientTitle, d.NetTotal, d.CreatedBy, d.CreatedAt
            FROM {tablo} d
            WHERE d.ApprovalStatus = 'Pending' AND d.[Status] = 'Draft'";

        var parcalar = new List<string>();
        if (tip == null || tip == "fatura") parcalar.Add(blok("dbo.InvoiceDrafts", "fatura"));
        if (tip == null || tip == "siparis") parcalar.Add(blok("dbo.OrderDrafts", "siparis"));
        if (tip == null || tip == "irsaliye") parcalar.Add(blok("dbo.ShipmentDrafts", "irsaliye"));
        if (parcalar.Count == 0) return Enumerable.Empty<OnayBekleyen>();

        var sql = string.Join("\nUNION ALL\n", parcalar) + "\nORDER BY CreatedAt DESC;";

        using var connection = new SqlConnection(_connectionString);
        var liste = (await connection.QueryAsync<OnayBekleyen>(sql)).ToList();

        // Tür adını mapper'dan doldur (tip'e göre doğru kodlama).
        foreach (var o in liste)
        {
            o.TrCodeAd = o.Tip switch
            {
                "fatura" => StokTrCodeMapper.GetName(o.TrCode, isInvoice: true),
                "siparis" => OrderCodeMapper.GetTrCodeName(o.TrCode),
                "irsaliye" => StokTrCodeMapper.GetName(o.TrCode, isInvoice: false),
                _ => "",
            };
        }
        return liste;
    }

    // ── Onay bekleyen sayıları (Patron paneli rozeti) ──
    public async Task<OnayOzet> GetOzetAsync()
    {
        const string sql = @"
            SELECT
              (SELECT COUNT(*) FROM dbo.InvoiceDrafts  WHERE ApprovalStatus='Pending' AND [Status]='Draft') AS Fatura,
              (SELECT COUNT(*) FROM dbo.OrderDrafts     WHERE ApprovalStatus='Pending' AND [Status]='Draft') AS Siparis,
              (SELECT COUNT(*) FROM dbo.ShipmentDrafts  WHERE ApprovalStatus='Pending' AND [Status]='Draft') AS Irsaliye;";
        using var connection = new SqlConnection(_connectionString);
        return await connection.QueryFirstAsync<OnayOzet>(sql);
    }

    // ── Onayla ──
    public async Task<bool> OnaylaAsync(string tip, int id, string onaylayan)
    {
        var tablo = TabloAdi(tip);
        if (tablo == null) throw new ArgumentException("Geçersiz belge tipi");

        var sql = $@"
            UPDATE {tablo} SET
                ApprovalStatus = 'Approved',
                ApprovedBy = @Onaylayan,
                ApprovedAt = GETDATE(),
                RejectReason = NULL
            WHERE Id = @Id AND ApprovalStatus = 'Pending' AND [Status] = 'Draft';";
        using var connection = new SqlConnection(_connectionString);
        var affected = await connection.ExecuteAsync(sql, new { Id = id, Onaylayan = onaylayan });
        return affected > 0;
    }

    // ── Reddet ──
    public async Task<bool> ReddetAsync(string tip, int id, string onaylayan, string? gerekce)
    {
        var tablo = TabloAdi(tip);
        if (tablo == null) throw new ArgumentException("Geçersiz belge tipi");

        var sql = $@"
            UPDATE {tablo} SET
                ApprovalStatus = 'Rejected',
                ApprovedBy = @Onaylayan,
                ApprovedAt = GETDATE(),
                RejectReason = @Gerekce
            WHERE Id = @Id AND ApprovalStatus = 'Pending' AND [Status] = 'Draft';";
        using var connection = new SqlConnection(_connectionString);
        var affected = await connection.ExecuteAsync(
            sql, new { Id = id, Onaylayan = onaylayan, Gerekce = gerekce });
        return affected > 0;
    }
}
