﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using LogoMobileApi.Models;
using Microsoft.IdentityModel.Tokens;

namespace LogoMobileApi.Services;

public class JwtTokenService
{
    private readonly string _secret;
    private readonly string _issuer;
    private readonly string _audience;
    private readonly int _expiryDays;
    private readonly string _defaultFirmaNo;
    private readonly string _defaultDonemNo;

    public JwtTokenService(IConfiguration configuration)
    {
        _secret = configuration["JwtSettings:Secret"]
            ?? throw new InvalidOperationException("JWT Secret bulunamadı");
        _issuer = configuration["JwtSettings:Issuer"] ?? "LogoMobileApi";
        _audience = configuration["JwtSettings:Audience"] ?? "LogoMobileApp";
        _expiryDays = int.Parse(configuration["JwtSettings:ExpiryDays"] ?? "7");
        _defaultFirmaNo = configuration["LogoSettings:FirmaNo"] ?? "";
        _defaultDonemNo = configuration["LogoSettings:DonemNo"] ?? "";
    }

    // firmaNo/donemNo: istemcinin seçtiği firma/dönem. Boş/geçersiz (rakam değil)
    // ise appsettings'teki varsayılan claim'e gömülür.
    // permissions: kullanıcının effective yetkileri — her biri "perm" claim'i olarak gömülür;
    // backend policy bazlı [Authorize(Policy=...)] bunları doğrular.
    public (string Token, DateTime ExpiresAt) GenerateToken(
        AppUser user, string? firmaNo = null, string? donemNo = null,
        IEnumerable<string>? permissions = null)
    {
        var firma = IsDigits(firmaNo) ? firmaNo! : _defaultFirmaNo;
        var donem = IsDigits(donemNo) ? donemNo! : _defaultDonemNo;

        var claims = new List<Claim>
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(JwtRegisteredClaimNames.UniqueName, user.Username),
            new Claim("fullName", user.FullName),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim("firmaNo", firma),
            new Claim("donemNo", donem),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        };

        if (permissions != null)
        {
            foreach (var p in permissions)
                claims.Add(new Claim("perm", p));
        }

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_secret));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var expires = DateTime.UtcNow.AddDays(_expiryDays);

        var token = new JwtSecurityToken(
            issuer: _issuer,
            audience: _audience,
            claims: claims,
            expires: expires,
            signingCredentials: creds);

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
        return (tokenString, expires);
    }

    private static bool IsDigits(string? value) =>
        !string.IsNullOrWhiteSpace(value) && Regex.IsMatch(value, @"^\d+$");
}