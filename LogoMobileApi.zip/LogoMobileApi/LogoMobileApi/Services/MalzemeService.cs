using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

public class MalzemeService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public MalzemeService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // stokDurumu: null=hepsi, "var"=fiili stok > 0, "yok"=fiili stok <= 0
    // tur: CARDTYPE değeri (ör. 10=Hammadde, 11=Yarı Mamul, 12=Mamul, 1=Ticari Mal)
    public async Task<IEnumerable<Malzeme>> GetAllAsync(
        int offset = 0, int limit = 50, string? search = null,
        string? stokDurumu = null, int? tur = null)
    {
        var sql = $@"
            SELECT
                it.LOGICALREF                              AS Id,
                it.CODE                                    AS Kod,
                it.NAME                                    AS Ad,
                ISNULL(it.STGRPCODE, '')                   AS GrupKodu,
                ISNULL(ul.CODE, '')                        AS Birim,
                CASE it.CARDTYPE
                    WHEN 1  THEN 'Ticari Mal'
                    WHEN 3  THEN 'Depozitolu Mal'
                    WHEN 4  THEN 'Sabit Kıymet'
                    WHEN 10 THEN 'Hammadde'
                    WHEN 11 THEN 'Yarı Mamul'
                    WHEN 12 THEN 'Mamul'
                    WHEN 13 THEN 'Tüketim Malı'
                    ELSE ''
                END                                        AS Tur,
                ISNULL(st.FiiliStok, 0.0)                  AS FiiliStok,
                ISNULL(st.GercekStok, 0.0)                 AS GercekStok
            FROM LG_{_firmaNo}_ITEMS it WITH(NOLOCK)
            LEFT JOIN (
                SELECT STOCKREF,
                       SUM(ONHAND)              AS FiiliStok,
                       SUM(ONHAND - RESERVED)   AS GercekStok
                FROM LV_{_firmaNo}_{_donemNo}_STINVTOT WITH(NOLOCK)
                WHERE INVENNO = -1
                GROUP BY STOCKREF
            ) st ON st.STOCKREF = it.LOGICALREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL ul WITH(NOLOCK)
                   ON ul.UNITSETREF = it.UNITSETREF AND ul.MAINUNIT = 1
            WHERE it.ACTIVE = 0
              AND it.CARDTYPE NOT IN (20, 21)
              AND (@Search IS NULL OR it.CODE LIKE '%' + @Search + '%' OR it.NAME LIKE '%' + @Search + '%')
              AND (@StokDurumu IS NULL
                   OR (@StokDurumu = 'yok' AND ISNULL(st.FiiliStok, 0.0) <= 0)
                   OR (@StokDurumu = 'var' AND ISNULL(st.FiiliStok, 0.0) > 0))
              AND (@Tur IS NULL OR it.CARDTYPE = @Tur)
            ORDER BY it.CODE
            OFFSET @Offset ROWS FETCH NEXT @Limit ROWS ONLY";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryAsync<Malzeme>(sql, new { Search = search, Offset = offset, Limit = limit, StokDurumu = stokDurumu, Tur = tur });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[MalzemeService.GetAllAsync] Hata: {ex.Message}");
            throw new Exception("Malzeme listesi alınamadı");
        }
    }

    public async Task<MalzemeDetay?> GetByIdAsync(int id)
    {
        var sql = $@"
            SELECT TOP 1
                it.LOGICALREF                              AS Id,
                it.CODE                                    AS Kod,
                it.NAME                                    AS Ad,
                ISNULL(it.NAME3, '')                       AS Aciklama2,
                ISNULL(it.NAME4, '')                       AS Aciklama3,
                ISNULL(it.STGRPCODE, '')                   AS GrupKodu,
                ISNULL(it.SPECODE,  '')                    AS OzelKod1,
                ISNULL(it.SPECODE2, '')                    AS OzelKod2,
                ISNULL(it.SPECODE3, '')                    AS OzelKod3,
                ISNULL(it.SPECODE4, '')                    AS OzelKod4,
                ISNULL(it.SPECODE5, '')                    AS OzelKod5,
             CASE it.CARDTYPE
    WHEN 1  THEN 'Ticari Mal'
    WHEN 2  THEN 'Karma Koli'
    WHEN 3  THEN 'Depozitolu Mal'
    WHEN 4  THEN 'Sabit Kıymet'
    WHEN 10 THEN 'Hammadde'
    WHEN 11 THEN 'Yarı Mamul'
    WHEN 12 THEN 'Mamul'
    WHEN 13 THEN 'Tüketim Malı'
    WHEN 20 THEN 'Malzeme Sınıfı (Genel)'
    WHEN 21 THEN 'Malzeme Sınıfı (T...)'
    ELSE ''
END                                     AS Tur,
                ISNULL(ul.CODE, '')                        AS Birim,
                ISNULL(st.FiiliStok, 0.0)                  AS FiiliStok,
                ISNULL(st.GercekStok, 0.0)                 AS GercekStok,
                ISNULL(SonAlis.PRICE,   0.0)               AS SatinalmaFiyati,
                ISNULL(SonAlis.CURCODE, 'TL')              AS SatinalmaDoviz,
                ISNULL(SonSatis.PRICE,  0.0)               AS SatisFiyati,
                ISNULL(SonSatis.CURCODE,'TL')              AS SatisDoviz,
                ISNULL(SonAlisHar.PRICE,  0.0)             AS SonAlisFiyati,
                ISNULL(SonSatisHar.PRICE, 0.0)             AS SonSatisFiyati
            FROM LG_{_firmaNo}_ITEMS it WITH(NOLOCK)
            LEFT JOIN (
                SELECT STOCKREF,
                       SUM(ONHAND)              AS FiiliStok,
                       SUM(ONHAND - RESERVED)   AS GercekStok
                FROM LV_{_firmaNo}_{_donemNo}_STINVTOT WITH(NOLOCK)
                WHERE INVENNO = -1
                GROUP BY STOCKREF
            ) st ON st.STOCKREF = it.LOGICALREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL ul WITH(NOLOCK)
                   ON ul.UNITSETREF = it.UNITSETREF AND ul.MAINUNIT = 1
            OUTER APPLY (
                SELECT TOP 1 prc.PRICE,
                       ISNULL(
                           (SELECT TOP 1 cl.CURCODE FROM L_CURRENCYLIST cl WITH(NOLOCK)
                            WHERE cl.CURTYPE = prc.CURRENCY AND cl.FIRMNR = {_firmaNo}),
                           'TL'
                       ) AS CURCODE
                FROM LG_{_firmaNo}_PRCLIST prc WITH(NOLOCK)
                WHERE prc.CARDREF = it.LOGICALREF AND prc.PTYPE = 1
                ORDER BY prc.BEGDATE DESC, prc.LOGICALREF DESC
            ) SonAlis
            OUTER APPLY (
                SELECT TOP 1 prc.PRICE,
                       ISNULL(
                           (SELECT TOP 1 cl.CURCODE FROM L_CURRENCYLIST cl WITH(NOLOCK)
                            WHERE cl.CURTYPE = prc.CURRENCY AND cl.FIRMNR = {_firmaNo}),
                           'TL'
                       ) AS CURCODE
                FROM LG_{_firmaNo}_PRCLIST prc WITH(NOLOCK)
                WHERE prc.CARDREF = it.LOGICALREF AND prc.PTYPE = 2
                ORDER BY prc.BEGDATE DESC, prc.LOGICALREF DESC
            ) SonSatis
            OUTER APPLY (
                SELECT TOP 1 sl.PRICE
                FROM LG_{_firmaNo}_{_donemNo}_STLINE sl WITH(NOLOCK)
                WHERE sl.STOCKREF = it.LOGICALREF
                  AND sl.LINETYPE = 0
                  AND sl.TRCODE   = 1
                  AND sl.PRICE    > 0
                ORDER BY sl.DATE_ DESC, sl.LOGICALREF DESC
            ) SonAlisHar
            OUTER APPLY (
                SELECT TOP 1 sl.PRICE
                FROM LG_{_firmaNo}_{_donemNo}_STLINE sl WITH(NOLOCK)
                WHERE sl.STOCKREF = it.LOGICALREF
                  AND sl.LINETYPE = 0
                  AND sl.TRCODE   IN (7, 8)
                  AND sl.PRICE    > 0
                ORDER BY sl.DATE_ DESC, sl.LOGICALREF DESC
            ) SonSatisHar
            WHERE it.LOGICALREF = @Id;

            SELECT
                st.INVENNO AS AmbarNo,
                CASE st.INVENNO
                    WHEN 0  THEN 'Mal Kabul'
                    WHEN 1  THEN 'HM Depo'
                    WHEN 2  THEN 'YM Depo'
                    WHEN 3  THEN 'MM Depo'
                    WHEN 4  THEN 'Üretim Depo'
                    WHEN 5  THEN 'Hurda Depo'
                    WHEN 6  THEN 'Karantina Depo'
                    WHEN 7  THEN 'Fason Depo'
                    WHEN 8  THEN 'Sevkiyat'
                    WHEN 9  THEN 'Sayım Depo'
                    WHEN 10 THEN 'Bakım Depo'
                    WHEN 11 THEN 'Kalıphane Depo'
                    WHEN 12 THEN 'İdari Alanlar'
                    WHEN 13 THEN 'Sevkiyat Fason Depo'
                    WHEN 14 THEN 'Antrepo Depo'
                    WHEN 15 THEN 'YM Ara Depo'
                    WHEN 16 THEN 'MM Ara Depo'
                    WHEN 17 THEN 'Polisaj Depo'
                    WHEN 18 THEN 'Montaj Depo'
                    WHEN 19 THEN 'Fason Geçici İade Depo'
                    ELSE CONCAT('Ambar ', CAST(st.INVENNO AS VARCHAR(10)))
                END AS AmbarAdi,
                SUM(st.ONHAND)                AS FiiliStok,
                SUM(st.ONHAND - st.RESERVED)  AS GercekStok
            FROM LV_{_firmaNo}_{_donemNo}_STINVTOT st WITH(NOLOCK)
            WHERE st.STOCKREF = @Id AND st.INVENNO >= 0
            GROUP BY st.INVENNO
            HAVING SUM(st.ONHAND) <> 0
            ORDER BY st.INVENNO;";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            using var multi = await connection.QueryMultipleAsync(sql, new { Id = id });

            var malzeme = await multi.ReadFirstOrDefaultAsync<MalzemeDetay>();
            if (malzeme == null) return null;

            var ambarlar = await multi.ReadAsync<AmbarStok>();
            malzeme.AmbarStoklar = ambarlar.ToList();

            return malzeme;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[MalzemeService.GetByIdAsync] Hata: {ex.Message}");
            throw new Exception("Malzeme detayı alınamadı");
        }
    }

    public async Task<IEnumerable<MalzemeHareket>> GetHareketlerAsync(
        int malzemeId, DateTime? baslangic, DateTime? bitis, bool? giris = null)
    {
        // Giriş: IOCODE 1,2 → DESTINDEX (giren ambar). Çıkış: IOCODE 3,4 → SOURCEINDEX (çıkan ambar).
        // Planlanan fişler hariç: STFICHE.PRODSTAT = 0 ve STLINE.LPRODSTAT = 0 → planlanan demek.
        var sql = $@"
            SELECT
                sl.LOGICALREF                                                AS Id,
                sl.DATE_                                                     AS Tarih,
                sl.TRCODE                                                    AS IslemTipi,
                COALESCE(sf.FICHENO, i.FICHENO, '')                          AS FisNo,
                ISNULL(c.DEFINITION_, '')                                    AS CariAdi,
                ISNULL(sl.LINEEXP, '')                                       AS Aciklama,
                sl.AMOUNT                                                    AS Miktar,
                sl.PRICE                                                     AS BirimFiyat,
                sl.TOTAL                                                     AS Tutar,
                CASE WHEN sl.IOCODE IN (1, 2) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS Giris,
                CASE WHEN sl.INVOICEREF > 0   THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS Fatura,
                ISNULL(wh.NAME, '')                                          AS Ambar
            FROM LG_{_firmaNo}_{_donemNo}_STLINE sl WITH(NOLOCK)
            LEFT JOIN LG_{_firmaNo}_{_donemNo}_STFICHE sf WITH(NOLOCK)
                   ON sf.LOGICALREF = sl.STFICHEREF
            LEFT JOIN LG_{_firmaNo}_{_donemNo}_INVOICE i WITH(NOLOCK)
                   ON i.LOGICALREF = sl.INVOICEREF
            LEFT JOIN LG_{_firmaNo}_CLCARD c WITH(NOLOCK)
                   ON c.LOGICALREF = sl.CLIENTREF
            LEFT JOIN L_CAPIWHOUSE wh WITH(NOLOCK)
                   ON wh.NR = CASE WHEN sl.IOCODE IN (1, 2) THEN sl.DESTINDEX ELSE sl.SOURCEINDEX END
                  AND wh.FIRMNR = {_firmaNo}
            WHERE sl.STOCKREF = @Id
              AND sl.LINETYPE = 0
              AND COALESCE(i.CANCELLED, sf.CANCELLED, 0) = 0
              -- Planlanan fişler hariç: PRODSTAT/LPRODSTAT = 0 → güncel, 1 → planlanan.
              AND ISNULL(sf.PRODSTAT, 0) = 0
              AND ISNULL(sl.LPRODSTAT, 0) = 0
              AND (@Baslangic IS NULL OR sl.DATE_ >= @Baslangic)
              AND (@Bitis      IS NULL OR sl.DATE_ <= @Bitis)
              AND (@Giris IS NULL
                   OR (@Giris = 1 AND sl.IOCODE IN (1, 2))
                   OR (@Giris = 0 AND sl.IOCODE IN (3, 4)))
            ORDER BY sl.DATE_ DESC, sl.LOGICALREF DESC";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var hareketler = (await connection.QueryAsync<MalzemeHareket>(
                sql, new { Id = malzemeId, Baslangic = baslangic, Bitis = bitis, Giris = giris })).ToList();

            foreach (var h in hareketler)
                h.IslemTipiAdi = StokTrCodeMapper.GetName(h.IslemTipi, h.Fatura);

            return hareketler;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[MalzemeService.GetHareketlerAsync] Hata: {ex.Message}");
            throw new Exception("Malzeme hareketleri alınamadı");
        }
    }

    // Malzeme kart resmini LG_XXX_FIRMDOC tablosundan çeker.
    // LDATA IMAGE tipinde olduğu için ExecuteScalarAsync<byte[]> kullanıyoruz (Dapper bazı sürümlerinde IMAGE'i map edemiyor).
    public async Task<byte[]?> GetResimAsync(int malzemeId)
    {
        var sql = $@"
            SELECT TOP 1 LDATA
            FROM LG_{_firmaNo}_FIRMDOC WITH(NOLOCK)
            WHERE INFOTYP = 20 AND DOCTYP = 0 AND DOCNR = 11 AND INFOREF = @Id";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var result = await connection.ExecuteScalarAsync(sql, new { Id = malzemeId });
            return result as byte[];
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[MalzemeService.GetResimAsync] Hata: {ex.Message}\n{ex.StackTrace}");
            // 400 yerine 404'e düşmek için boş döndürelim — controller NotFound yapacak.
            return null;
        }
    }

    // TEŞHİS: Bir malzeme için FIRMDOC'taki tüm satırları döndürür (LDATA boyutu dahil).
    // INFOTYPE / DOCTYPE / DOCNR değerlerini gerçek datada doğrulamak için.
    public async Task<IEnumerable<dynamic>> GetFirmDocRowsAsync(int malzemeId)
    {
        var sql = $@"
            SELECT INFOTYP, DOCTYP, DOCNR, INFOREF, DATALENGTH(LDATA) AS LDataBoyut
            FROM LG_{_firmaNo}_FIRMDOC WITH(NOLOCK)
            WHERE INFOREF = @Id
            ORDER BY INFOTYP, DOCTYP, DOCNR";

        using var connection = new SqlConnection(_connectionString);
        return await connection.QueryAsync(sql, new { Id = malzemeId });
    }
}
