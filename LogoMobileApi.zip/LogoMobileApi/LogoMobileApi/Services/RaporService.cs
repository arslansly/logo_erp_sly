using Dapper;
using LogoMobileApi.Models;
using Microsoft.Data.SqlClient;

namespace LogoMobileApi.Services;

// Raporlar alanı için toplu sorgular. Mevcut Cari/Malzeme/Dashboard servisleriyle
// aynı kalıbı izler: Dapper + WITH(NOLOCK) + tablo adı interpolasyonu + parametreli WHERE.
public class RaporService
{
    private readonly string _connectionString;
    private readonly string _firmaNo;
    private readonly string _donemNo;

    public RaporService(IConfiguration configuration, FirmaContext firmaCtx)
    {
        _connectionString = configuration["LogoSettings:ConnectionString"]
            ?? throw new InvalidOperationException("Connection string bulunamadı");
        _firmaNo = firmaCtx.FirmaNo;
        _donemNo = firmaCtx.DonemNo;
    }

    // CARDTYPE → Türkçe malzeme türü (MalzemeService ile aynı eşleme)
    private const string MalzemeTurCase = @"
        CASE it.CARDTYPE
            WHEN 1  THEN 'Ticari Mal'
            WHEN 3  THEN 'Depozitolu Mal'
            WHEN 4  THEN 'Sabit Kıymet'
            WHEN 10 THEN 'Hammadde'
            WHEN 11 THEN 'Yarı Mamul'
            WHEN 12 THEN 'Mamul'
            WHEN 13 THEN 'Tüketim Malı'
            ELSE ''
        END";

    // 1) Cari hesap/bakiye raporu — kod, ad, şehir, ülke, telefon, borç, alacak, bakiye
    // tur: CLCARD.CARDTYPE (1=Alıcı, 2=Satıcı, 3=Alıcı/Satıcı). bakiyeDurumu: 'borclu' / 'alacakli' / null
    public async Task<IEnumerable<CariBakiyeRapor>> GetCariBakiyeAsync(
        string? search = null, int? tur = null, string? bakiyeDurumu = null)
    {
        var sql = $@"
            SELECT
                clc.LOGICALREF              AS Id,
                clc.CODE                    AS Code,
                clc.DEFINITION_             AS Title,
                ISNULL(clc.CITY, '')        AS City,
                ISNULL(clc.COUNTRY, '')     AS Country,
                ISNULL(clc.TELNRS1, '')     AS Phone,
                ISNULL(gt.ToplamBorc, 0)    AS ToplamBorc,
                ISNULL(gt.ToplamAlacak, 0)  AS ToplamAlacak,
                ISNULL(gt.Bakiye, 0)        AS Bakiye
            FROM LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
            LEFT JOIN (
                SELECT CARDREF,
                       SUM(DEBIT)          AS ToplamBorc,
                       SUM(CREDIT)         AS ToplamAlacak,
                       SUM(DEBIT - CREDIT) AS Bakiye
                FROM LV_{_firmaNo}_{_donemNo}_GNTOTCL WITH(NOLOCK)
                WHERE TOTTYP = 1
                GROUP BY CARDREF
            ) gt ON gt.CARDREF = clc.LOGICALREF
            WHERE clc.ACTIVE = 0
              AND (@Search IS NULL
                   OR clc.CODE LIKE '%' + @Search + '%'
                   OR clc.DEFINITION_ LIKE '%' + @Search + '%'
                   OR clc.CITY LIKE '%' + @Search + '%')
              AND (@Tur IS NULL OR clc.CARDTYPE = @Tur)
              AND (@BakiyeDurumu IS NULL
                   OR (@BakiyeDurumu = 'borclu'   AND ISNULL(gt.Bakiye, 0) > 0)
                   OR (@BakiyeDurumu = 'alacakli' AND ISNULL(gt.Bakiye, 0) < 0))
            ORDER BY clc.DEFINITION_";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryAsync<CariBakiyeRapor>(
                sql, new { Search = search, Tur = tur, BakiyeDurumu = bakiyeDurumu });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[RaporService.GetCariBakiyeAsync] Hata: {ex.Message}");
            throw new Exception("Cari bakiye raporu alınamadı");
        }
    }

    // 2) Vade raporu — vadesi geçmiş bakiyesi olan cariler + yaşlandırma kovaları
    // minGun: sadece en eski gecikmesi minGun gün ve üzeri olanlar (null = hepsi)
    public async Task<IEnumerable<VadeRapor>> GetVadeAsync(int? minGun = null)
    {
        var sql = $@"
            SELECT
                clc.LOGICALREF       AS Id,
                clc.CODE             AS Code,
                clc.DEFINITION_      AS Title,
                ISNULL(clc.CITY, '') AS City,
                ISNULL(clc.TELNRS1, '') AS Phone,
                ozet.ToplamVadesiGecen,
                ozet.EnEskiVadeTarihi,
                DATEDIFF(DAY, ozet.EnEskiVadeTarihi, CAST(GETDATE() AS DATE)) AS EnEskiGunFarki,
                ozet.VadeSayisi,
                ozet.Vadesi_0_30,
                ozet.Vadesi_31_60,
                ozet.Vadesi_61_90,
                ozet.Vadesi_90Plus
            FROM (
                SELECT
                    pt.CARDREF,
                    SUM(pt.TOTAL - pt.PAID)        AS ToplamVadesiGecen,
                    MIN(pt.DATE_)                  AS EnEskiVadeTarihi,
                    COUNT(*)                       AS VadeSayisi,
                    SUM(CASE WHEN DATEDIFF(day, pt.DATE_, CAST(GETDATE() AS DATE)) BETWEEN 1 AND 30
                             THEN pt.TOTAL - pt.PAID ELSE 0 END) AS Vadesi_0_30,
                    SUM(CASE WHEN DATEDIFF(day, pt.DATE_, CAST(GETDATE() AS DATE)) BETWEEN 31 AND 60
                             THEN pt.TOTAL - pt.PAID ELSE 0 END) AS Vadesi_31_60,
                    SUM(CASE WHEN DATEDIFF(day, pt.DATE_, CAST(GETDATE() AS DATE)) BETWEEN 61 AND 90
                             THEN pt.TOTAL - pt.PAID ELSE 0 END) AS Vadesi_61_90,
                    SUM(CASE WHEN DATEDIFF(day, pt.DATE_, CAST(GETDATE() AS DATE)) > 90
                             THEN pt.TOTAL - pt.PAID ELSE 0 END) AS Vadesi_90Plus
                FROM LG_{_firmaNo}_{_donemNo}_PAYTRANS pt WITH(NOLOCK)
                WHERE pt.CANCELLED = 0
                  AND pt.SIGN = 0
                  AND pt.TOTAL > pt.PAID
                  AND pt.DATE_ < CAST(GETDATE() AS DATE)
                GROUP BY pt.CARDREF
            ) ozet
            INNER JOIN LG_{_firmaNo}_CLCARD clc WITH(NOLOCK)
                ON clc.LOGICALREF = ozet.CARDREF
            WHERE (@MinGun IS NULL
                   OR DATEDIFF(DAY, ozet.EnEskiVadeTarihi, CAST(GETDATE() AS DATE)) >= @MinGun)
            ORDER BY ozet.EnEskiVadeTarihi ASC";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();
            return (await connection.QueryAsync<VadeRapor>(
                new CommandDefinition(sql, new { MinGun = minGun }, commandTimeout: 30))).ToList();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[RaporService.GetVadeAsync] Hata: {ex.Message}");
            throw new Exception("Vade raporu alınamadı");
        }
    }

    // 3) Stok durum raporu — malzeme ad/açıklama + fiili/gerçek stok
    // stokDurumu: 'var' / 'yok' / null. tur: ITEMS.CARDTYPE
    public async Task<IEnumerable<StokRapor>> GetStokAsync(
        string? search = null, int? tur = null, string? stokDurumu = null)
    {
        var sql = $@"
            SELECT
                it.LOGICALREF                AS Id,
                it.CODE                      AS Kod,
                it.NAME                      AS Ad,
                ISNULL(it.NAME2, '')         AS Aciklama,
                ISNULL(ul.CODE, '')          AS Birim,
                {MalzemeTurCase}             AS Tur,
                ISNULL(st.FiiliStok, 0.0)    AS FiiliStok,
                ISNULL(st.GercekStok, 0.0)   AS GercekStok
            FROM LG_{_firmaNo}_ITEMS it WITH(NOLOCK)
            LEFT JOIN (
                SELECT STOCKREF,
                       SUM(ONHAND)              AS FiiliStok,
                       SUM(ONHAND - RESERVED)   AS GercekStok
                FROM LV_{_firmaNo}_{_donemNo}_STINVTOT WITH(NOLOCK)
                WHERE INVENNO = -1
                GROUP BY STOCKREF
            ) st ON st.STOCKREF = it.LOGICALREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL ul WITH(NOLOCK)
                   ON ul.UNITSETREF = it.UNITSETREF AND ul.MAINUNIT = 1
            WHERE it.ACTIVE = 0
              AND it.CARDTYPE NOT IN (4, 20, 21)
              AND (@Search IS NULL OR it.CODE LIKE '%' + @Search + '%' OR it.NAME LIKE '%' + @Search + '%')
              AND (@StokDurumu IS NULL
                   OR (@StokDurumu = 'yok' AND ISNULL(st.FiiliStok, 0.0) <= 0)
                   OR (@StokDurumu = 'var' AND ISNULL(st.FiiliStok, 0.0) > 0))
              AND (@Tur IS NULL OR it.CARDTYPE = @Tur)
            ORDER BY it.CODE";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryAsync<StokRapor>(
                sql, new { Search = search, Tur = tur, StokDurumu = stokDurumu });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[RaporService.GetStokAsync] Hata: {ex.Message}");
            throw new Exception("Stok durum raporu alınamadı");
        }
    }

    // Ayrıntılı stok raporu için düz (malzeme x ambar) satır
    private class StokAmbarFlat
    {
        public int Id { get; set; }
        public string Kod { get; set; } = "";
        public string Ad { get; set; } = "";
        public string Birim { get; set; } = "";
        public string Tur { get; set; } = "";
        public int AmbarNo { get; set; }
        public string AmbarAdi { get; set; } = "";
        public double FiiliStok { get; set; }
        public double GercekStok { get; set; }
    }

    // 4) Ayrıntılı stok raporu — malzeme bazında ambar dökümü (ambar adı L_CAPIWHOUSE'tan dinamik)
    public async Task<IEnumerable<StokAmbarRapor>> GetStokAmbarAsync(
        string? search = null, int? tur = null)
    {
        var sql = $@"
            SELECT
                it.LOGICALREF                AS Id,
                it.CODE                      AS Kod,
                it.NAME                      AS Ad,
                ISNULL(ul.CODE, '')          AS Birim,
                {MalzemeTurCase}             AS Tur,
                st.INVENNO                   AS AmbarNo,
                ISNULL(wh.NAME, CONCAT('Ambar ', CAST(st.INVENNO AS VARCHAR(10)))) AS AmbarAdi,
                st.FiiliStok                 AS FiiliStok,
                st.GercekStok                AS GercekStok
            FROM LG_{_firmaNo}_ITEMS it WITH(NOLOCK)
            INNER JOIN (
                SELECT STOCKREF, INVENNO,
                       SUM(ONHAND)              AS FiiliStok,
                       SUM(ONHAND - RESERVED)   AS GercekStok
                FROM LV_{_firmaNo}_{_donemNo}_STINVTOT WITH(NOLOCK)
                WHERE INVENNO >= 0
                GROUP BY STOCKREF, INVENNO
                HAVING SUM(ONHAND) <> 0
            ) st ON st.STOCKREF = it.LOGICALREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL ul WITH(NOLOCK)
                   ON ul.UNITSETREF = it.UNITSETREF AND ul.MAINUNIT = 1
            LEFT JOIN L_CAPIWHOUSE wh WITH(NOLOCK)
                   ON wh.NR = st.INVENNO AND wh.FIRMNR = {_firmaNo}
            WHERE it.ACTIVE = 0
              AND it.CARDTYPE NOT IN (4, 20, 21)
              AND (@Search IS NULL OR it.CODE LIKE '%' + @Search + '%' OR it.NAME LIKE '%' + @Search + '%')
              AND (@Tur IS NULL OR it.CARDTYPE = @Tur)
            ORDER BY it.CODE, st.INVENNO";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            var flat = await connection.QueryAsync<StokAmbarFlat>(
                sql, new { Search = search, Tur = tur });

            // Malzeme bazında grupla → iç içe model
            return flat
                .GroupBy(f => new { f.Id, f.Kod, f.Ad, f.Birim, f.Tur })
                .Select(g => new StokAmbarRapor
                {
                    Id = g.Key.Id,
                    Kod = g.Key.Kod,
                    Ad = g.Key.Ad,
                    Birim = g.Key.Birim,
                    Tur = g.Key.Tur,
                    ToplamFiili = g.Sum(x => x.FiiliStok),
                    ToplamGercek = g.Sum(x => x.GercekStok),
                    Ambarlar = g.Select(x => new AmbarStok
                    {
                        AmbarNo = x.AmbarNo,
                        AmbarAdi = x.AmbarAdi,
                        FiiliStok = x.FiiliStok,
                        GercekStok = x.GercekStok,
                    }).ToList(),
                })
                .ToList();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[RaporService.GetStokAmbarAsync] Hata: {ex.Message}");
            throw new Exception("Ayrıntılı stok raporu alınamadı");
        }
    }

    // 5) Kritik stok raporu — fiili stoğu asgari (MINLEVEL) altında kalan malzemeler
    // MINLEVELCTRL'e güvenilmez (DB referansı Hata 9); sadece MINLEVEL > 0 dikkate alınır.
    public async Task<IEnumerable<KritikStokRapor>> GetKritikStokAsync(
        string? search = null, int? tur = null)
    {
        var sql = $@"
            SELECT
                it.LOGICALREF                AS Id,
                it.CODE                      AS Kod,
                it.NAME                      AS Ad,
                ISNULL(ul.CODE, '')          AS Birim,
                ISNULL(st.FiiliStok, 0.0)    AS FiiliStok,
                inv.AsgariStok               AS AsgariStok,
                ISNULL(st.FiiliStok, 0.0) - inv.AsgariStok AS Fark
            FROM LG_{_firmaNo}_ITEMS it WITH(NOLOCK)
            INNER JOIN (
                SELECT ITEMREF, SUM(MINLEVEL) AS AsgariStok
                FROM LG_{_firmaNo}_INVDEF WITH(NOLOCK)
                WHERE MINLEVEL > 0
                GROUP BY ITEMREF
                HAVING SUM(MINLEVEL) > 0
            ) inv ON inv.ITEMREF = it.LOGICALREF
            LEFT JOIN (
                SELECT STOCKREF, SUM(ONHAND) AS FiiliStok
                FROM LV_{_firmaNo}_{_donemNo}_STINVTOT WITH(NOLOCK)
                WHERE INVENNO = -1
                GROUP BY STOCKREF
            ) st ON st.STOCKREF = it.LOGICALREF
            LEFT JOIN LG_{_firmaNo}_UNITSETL ul WITH(NOLOCK)
                   ON ul.UNITSETREF = it.UNITSETREF AND ul.MAINUNIT = 1
            WHERE it.ACTIVE = 0
              AND it.CARDTYPE NOT IN (4, 20, 21)
              AND ISNULL(st.FiiliStok, 0.0) < inv.AsgariStok
              AND (@Search IS NULL OR it.CODE LIKE '%' + @Search + '%' OR it.NAME LIKE '%' + @Search + '%')
              AND (@Tur IS NULL OR it.CARDTYPE = @Tur)
            ORDER BY (ISNULL(st.FiiliStok, 0.0) - inv.AsgariStok) ASC";

        try
        {
            using var connection = new SqlConnection(_connectionString);
            return await connection.QueryAsync<KritikStokRapor>(
                sql, new { Search = search, Tur = tur });
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[RaporService.GetKritikStokAsync] Hata: {ex.Message}");
            throw new Exception("Kritik stok raporu alınamadı");
        }
    }

    // 6) Satış performans / ciro raporu — özet + aylık trend + satışçı + top müşteri.
    // Satış faturası = INVOICE.TRCODE IN (7,8,9), CANCELLED=0. Ciro = NETTOTAL - TOTALVAT (KDV hariç).
    // Tarih aralığı opsiyonel; verilmezse tüm satışlar. satisciRef verilirse o satışçıya daraltılır.
    // PatronService/SahaService kalıbı: her bölüm ayrı try/catch — biri patlasa rapor yine döner.
    public async Task<SatisPerformansRapor> GetSatisPerformansAsync(
        DateTime? baslangic = null, DateTime? bitis = null, int? satisciRef = null)
    {
        var rapor = new SatisPerformansRapor();
        using var connection = new SqlConnection(_connectionString);

        // Ortak WHERE — satış faturaları + tarih aralığı + (opsiyonel) satışçı.
        const string whereCommon = @"
            inv.CANCELLED = 0 AND inv.TRCODE IN (7, 8, 9)
            AND (@Bas IS NULL OR inv.DATE_ >= @Bas)
            AND (@Bit IS NULL OR inv.DATE_ <= @Bit)
            AND (@Ref IS NULL OR inv.SALESMANREF = @Ref)";
        var p = new
        {
            Bas = baslangic?.Date,
            Bit = bitis?.Date.AddDays(1).AddTicks(-1),
            Ref = satisciRef,
        };

        // 1) Özet — toplam ciro + fatura sayısı
        try
        {
            var sql = $@"
                SELECT CAST(ISNULL(SUM(ISNULL(inv.NETTOTAL,0) - ISNULL(inv.TOTALVAT,0)), 0) AS decimal(18,2)) AS ToplamCiro,
                       COUNT(*) AS FaturaSayisi
                FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
                WHERE {whereCommon};";
            var row = await connection.QueryFirstAsync(sql, p);
            rapor.ToplamCiro = (decimal)row.ToplamCiro;
            rapor.FaturaSayisi = (int)row.FaturaSayisi;
            rapor.OrtalamaFatura = rapor.FaturaSayisi > 0
                ? rapor.ToplamCiro / rapor.FaturaSayisi
                : 0;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Satis.Ozet: {ex.Message}"); }

        // 2) Aylık ciro trendi — en güncel 12 ay (kronolojik döndürülür)
        try
        {
            var sql = $@"
                SELECT TOP 12
                    YEAR(inv.DATE_)  AS Yil,
                    MONTH(inv.DATE_) AS Ay,
                    CAST(ISNULL(SUM(ISNULL(inv.NETTOTAL,0) - ISNULL(inv.TOTALVAT,0)), 0) AS decimal(18,2)) AS Ciro,
                    COUNT(*) AS Adet
                FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
                WHERE {whereCommon}
                GROUP BY YEAR(inv.DATE_), MONTH(inv.DATE_)
                ORDER BY Yil DESC, Ay DESC;";
            var aylar = (await connection.QueryAsync<AylikCiro>(sql, p)).ToList();
            aylar.Reverse(); // en eskiden en yeniye (grafik soldan sağa)
            rapor.AylikTrend = aylar;
        }
        catch (Exception ex) { Console.WriteLine($"❌ Satis.AylikTrend: {ex.Message}"); }

        // 3) Satışçı performansı — cirosu azalan (LG_SLSMAN global, FIRMNR şart)
        try
        {
            var sql = $@"
                SELECT s.LOGICALREF AS Id,
                       s.CODE        AS Kod,
                       s.DEFINITION_ AS Ad,
                       CAST(ISNULL(SUM(ISNULL(inv.NETTOTAL,0) - ISNULL(inv.TOTALVAT,0)), 0) AS decimal(18,2)) AS Ciro,
                       COUNT(*) AS Adet
                FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
                JOIN LG_SLSMAN s WITH(NOLOCK)
                    ON s.LOGICALREF = inv.SALESMANREF AND s.FIRMNR = {_firmaNo}
                WHERE {whereCommon}
                GROUP BY s.LOGICALREF, s.CODE, s.DEFINITION_
                ORDER BY Ciro DESC;";
            rapor.Satiscilar = (await connection.QueryAsync<SatisciPerformans>(sql, p)).ToList();
        }
        catch (Exception ex) { Console.WriteLine($"❌ Satis.Satiscilar: {ex.Message}"); }

        // 4) En çok satış yapılan ilk 10 müşteri
        try
        {
            var sql = $@"
                SELECT TOP 10
                    c.LOGICALREF  AS CariId,
                    c.CODE         AS Kod,
                    c.DEFINITION_  AS Ad,
                    CAST(ISNULL(SUM(ISNULL(inv.NETTOTAL,0) - ISNULL(inv.TOTALVAT,0)), 0) AS decimal(18,2)) AS Ciro,
                    COUNT(*) AS Adet
                FROM LG_{_firmaNo}_{_donemNo}_INVOICE inv WITH(NOLOCK)
                JOIN LG_{_firmaNo}_CLCARD c WITH(NOLOCK)
                    ON c.LOGICALREF = inv.CLIENTREF AND c.LOGICALREF <> 1
                WHERE {whereCommon}
                GROUP BY c.LOGICALREF, c.CODE, c.DEFINITION_
                ORDER BY Ciro DESC;";
            rapor.TopMusteriler = (await connection.QueryAsync<MusteriCiro>(sql, p)).ToList();
        }
        catch (Exception ex) { Console.WriteLine($"❌ Satis.TopMusteriler: {ex.Message}"); }

        return rapor;
    }
}
