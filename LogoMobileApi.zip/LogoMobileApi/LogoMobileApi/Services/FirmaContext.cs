using System.Text.RegularExpressions;

namespace LogoMobileApi.Services;

/// <summary>
/// İstek bazlı (scoped) firma/dönem bağlamı.
/// Firma/dönem önce giriş yapan kullanıcının JWT claim'lerinden okunur;
/// claim yoksa veya geçersizse appsettings'teki varsayılana düşülür.
///
/// GÜVENLİK: Firma/dönem değerleri SQL'e tablo adı olarak gömülür
/// (örn. LG_{firma}_CLCARD) ve parametrize EDİLEMEZ. Bu yüzden yalnızca
/// rakamlardan oluşan değerler kabul edilir; aksi halde varsayılan kullanılır.
/// </summary>
public class FirmaContext
{
    public string FirmaNo { get; }
    public string DonemNo { get; }

    public FirmaContext(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
    {
        var user = httpContextAccessor.HttpContext?.User;
        var firmaClaim = user?.FindFirst("firmaNo")?.Value;
        var donemClaim = user?.FindFirst("donemNo")?.Value;

        var defaultFirma = configuration["LogoSettings:FirmaNo"]
            ?? throw new InvalidOperationException("Firma no bulunamadı");
        var defaultDonem = configuration["LogoSettings:DonemNo"]
            ?? throw new InvalidOperationException("Dönem no bulunamadı");

        FirmaNo = IsSafe(firmaClaim) ? firmaClaim! : defaultFirma;
        DonemNo = IsSafe(donemClaim) ? donemClaim! : defaultDonem;
    }

    // Sadece rakamlardan oluşuyorsa güvenli (SQL tablo adına gömülecek).
    private static bool IsSafe(string? value) =>
        !string.IsNullOrWhiteSpace(value) && Regex.IsMatch(value, @"^\d+$");
}
