namespace LogoMobileApi.Services;

/// <summary>
/// Uygulama rolleri — Flutter tarafındaki AppRole ile birebir aynı kanonik
/// (ASCII) değerler. JWT role claim'i ve [Authorize(Roles=...)] bu değerleri kullanır.
/// </summary>
public static class RoleHelper
{
    public const string Admin = "Admin";
    public const string Patron = "Patron";
    public const string Muhasebe = "Muhasebe";
    public const string Satisci = "Satisci";

    public static readonly string[] All = { Admin, Patron, Muhasebe, Satisci };

    /// <summary>
    /// Kullanıcı yönetimi yapabilen roller (Admin/Patron). "Son yönetici"
    /// korumasında kullanılır — sistemin yönetimsiz/kilitli kalmasını önler.
    /// </summary>
    public static bool IsManager(string? role)
    {
        var r = Normalize(role);
        return r == Admin || r == Patron;
    }

    /// <summary>
    /// Geçersiz/bilinmeyen ya da eski ("User") rolü en az yetkili role (Satisci)
    /// indirger. Böylece istemci hatalı/elle bir rol gönderse bile fazla yetki sızmaz.
    /// </summary>
    public static string Normalize(string? role)
    {
        if (string.IsNullOrWhiteSpace(role)) return Satisci;
        foreach (var r in All)
        {
            if (string.Equals(r, role.Trim(), StringComparison.OrdinalIgnoreCase))
                return r;
        }
        return Satisci;
    }
}
