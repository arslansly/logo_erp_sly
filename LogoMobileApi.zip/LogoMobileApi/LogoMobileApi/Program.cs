﻿using LogoMobileApi.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Filters;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// ─── Temel servisler ───
builder.Services.AddControllers();

// ─── İstek bazlı firma/dönem bağlamı (JWT claim → SQL tablo öneki) ───
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<FirmaContext>();

// ─── LOGO servisleri ───
builder.Services.AddScoped<CariService>();
builder.Services.AddScoped<DashboardService>();
builder.Services.AddScoped<PatronService>();
builder.Services.AddScoped<SahaService>();
builder.Services.AddScoped<MalzemeService>();
builder.Services.AddScoped<FaturaService>();
builder.Services.AddScoped<InvoiceDraftService>();
builder.Services.AddScoped<OrderDraftService>();
builder.Services.AddScoped<ShipmentDraftService>();
builder.Services.AddScoped<SiparisService>();
builder.Services.AddScoped<IrsaliyeService>();
builder.Services.AddScoped<LookupService>();
builder.Services.AddScoped<RaporService>();
builder.Services.AddScoped<OnayService>();

// ─── Yapay zeka asistanı (Anthropic Claude tool-use) ───
builder.Services.AddHttpClient<AiService>();

// ─── Auth servisleri ───
builder.Services.AddScoped<JwtTokenService>();
builder.Services.AddScoped<AuthService>();

// ─── Swagger + JWT Authorize butonu ───
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Logo Mobil API", Version = "v1" });

    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
    {
        Description = "JWT Bearer token. Örnek: Bearer eyJhbGc...",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.OperationFilter<SecurityRequirementsOperationFilter>();
});
builder.Services.AddSwaggerExamplesFromAssemblyOf<Program>();

// ─── JWT Authentication ───
var jwtSecret = builder.Configuration["JwtSettings:Secret"]!;
var jwtIssuer = builder.Configuration["JwtSettings:Issuer"];
var jwtAudience = builder.Configuration["JwtSettings:Audience"];

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtIssuer,
            ValidAudience = jwtAudience,
            IssuerSigningKey = new SymmetricSecurityKey(
                                           Encoding.UTF8.GetBytes(jwtSecret)),
            ClockSkew = TimeSpan.Zero
        };
    });

// Her yetki anahtarı için bir policy — token'daki "perm" claim'ini doğrular.
// [Authorize(Policy = AppPermissions.X)] bu policy'leri kullanır.
builder.Services.AddAuthorization(options =>
{
    foreach (var perm in AppPermissions.All)
    {
        options.AddPolicy(perm, policy => policy.RequireClaim("perm", perm));
    }
});

var app = builder.Build();

// ─── Pipeline ───
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// app.UseHttpsRedirection(); // Mobil dev için kapalı

app.UseAuthentication();   // ← UseAuthorization'dan ÖNCE — şart
app.UseAuthorization();    // ← Sadece bir kez

app.MapControllers();

app.Run();